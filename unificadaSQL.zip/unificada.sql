-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.1.29-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win32
-- HeidiSQL Versión:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para unificada
CREATE DATABASE IF NOT EXISTS `unificada` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `unificada`;

-- Volcando estructura para tabla unificada.180
CREATE TABLE IF NOT EXISTS `180` (
  `Identificacion` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.actualiza asesores
CREATE TABLE IF NOT EXISTS `actualiza asesores` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Pagare` varchar(255) DEFAULT NULL,
  `Cedula Ejecutivo` varchar(255) DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `Segmento` varchar(255) DEFAULT NULL,
  `Asignacion` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.asignacion
CREATE TABLE IF NOT EXISTS `asignacion` (
  `Pagare` varchar(50) DEFAULT NULL,
  `NumeroCredito` double DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `CasadeCobro` varchar(255) DEFAULT NULL,
  `Ejecutivo` varchar(255) DEFAULT NULL,
  `FechaAsignacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para procedimiento unificada.Califica PP
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `Califica PP`()
BEGIN

-- Elimina PP
DELETE FROM `estado pp por dia`
	WHERE `Identificacion` = `Identificacion`;
	
-- Elimina PP2
DELETE FROM `estado pp por dia12` 
	WHERE `Identificacion` = `Identificacion`;
	
-- 08 Califica PP
INSERT INTO `estado pp por dia12` 
	( `Producto`, 
	`Identificacion`, 
	`NUM_Obligacion`, 
	`Credito`, 
	`Llave SL`, 
	`Fecha_Promesa`, 
	`Valor Acuerdo`, 
	`Valor Recaudo Total`, 
	`Fecha_Para_Calificar`)
		SELECT 
			`07`.`Producto`, 
			`07`.`Identificacion`, 
			`07`.`NUM_Obligacion`, 
			`07`.`Cred`, 
			`07`.`Llave SL`, 
			`07`.`Fecha_Promesa`, 
			`07`.`Valor_Acuerdo`, 
			`cs`.`VALOR RECAUDO TOTAL`, 
			`07`.`Fecha_Promesa` AS `Fecha a Calificar` 
			FROM 
				(SELECT 
					`00gpp1`.`Producto_1` AS `Producto`, 
					`00gpp1`.`Identificacion`, 
					`00gpp1`.`NUM_Obligacion`, 
					`00gpp1`.`Cred`, 
					`00gpp1`.`Llave SL`, 
					`00gpp1`.`Fecha_Promesa`, 
					`00gpp1`.`Valor_Acuerdo` 
					FROM 
						(SELECT 
							`ge`.`FechaLlamada` AS `Fecha Gestion`, 
							`ge`.`Identificacion`, 
							`ge`.`Producto` AS `Producto_1`, 
							'' AS `NUM_Obligacion`, 
							`ge`.`Credito` AS `Cred`, 
							'' AS `Llave SL`, 
							`ge`.`FechaDePromesa` AS `Fecha_Promesa`, 
							`ge`.`valorPromesa` AS `Valor_Acuerdo` 
							FROM 
								(SELECT 
									FechaLlamada, 
									Identificacion, 
									Producto, 
									NroProductoCredito AS `Credito`, 
									FechaDePromesa, 
									ValorPromesa
									FROM `gestion externa` 
										UNION 
											SELECT 
												'FechaLlamada', 
												Identificacion, 
												Producto, 
												NUM_Obligacion AS `Credito`, 
												FechaPromesa, 
												'ValorPromesa'
												FROM `gestion interna`) AS `ge` 
					) AS `00gpp1` 
					WHERE `00gpp1`.`Fecha_Promesa` IS NOT NULL) AS `07`
				INNER JOIN `cruce segmento` AS `cs` 
				ON `07`.`Producto` = `cs`.`Producto` 
				AND `07`.`Cred` = `cs`.`Credito` 
					GROUP BY 
					`07`.`Producto`, 
					`07`.`Identificacion`, 
					`07`.`NUM_Obligacion`, 
					`07`.`Cred`, 
					`07`.`Llave SL`, 
					`07`.`Valor_Acuerdo`, 
					`cs`.`VALOR RECAUDO TOTAL`, 
					`07`.`Fecha_Promesa` 
					HAVING 
						`07`.PRODUCTO = "TC" 
						Or `07`.PRODUCTO = "CF" 
						Or `07`.PRODUCTO = "VE" 
						Or `07`.PRODUCTO = "MC";
						
-- 08 califica pp opend
INSERT INTO `estado pp por dia12` 
	(`Producto`, 
	`Identificacion`, 
	`NUM_Obligacion`, 
	`Credito`, 
	`Llave SL`, 
	`Fecha_Promesa`, 
	`Valor Acuerdo`, 
	`Valor Recaudo Total`, 
	`Fecha_Para_Calificar`)
		SELECT 
			`07`.`Producto`, 
			`07`.`Identificacion`, 
			`07`.`NUM_Obligacion`, 
			`07`.`Cred`, 
			`07`.`Llave SL`, 
			`07`.`Fecha_Promesa`, 
			`07`.`Valor_Acuerdo`, 
			`cs`.`VALOR RECAUDO TOTAL`, 
			`07`.`Fecha_Promesa` AS `Fecha_Para_Calificar` 
			FROM 
				(SELECT 
					`00gpp1`.`Producto_1` AS `Producto`, 
					`00gpp1`.`Identificacion`, 
					`00gpp1`.`NUM_Obligacion`, 
					`00gpp1`.`Cred`, 
					`00gpp1`.`Llave SL`, 
					`00gpp1`.`Fecha_Promesa`, 
					`00gpp1`.`Valor_Acuerdo` 
					FROM 
						(SELECT 
							`ge`.`FechaLlamada` AS `Fecha Gestion`, 
							`ge`.`Identificacion`, 
							`ge`.`Producto` AS `Producto_1`, 
							'' AS `NUM_Obligacion`, 
							`ge`.`Credito` AS `Cred`, 
							'' AS `Llave SL`, 
							`ge`.`FechaDePromesa` AS `Fecha_Promesa`, 
							`ge`.`valorPromesa` AS `Valor_Acuerdo` 
							FROM 
								(SELECT 
									FechaLlamada, 
									Identificacion, 
									Producto, 
									NroProductoCredito AS `Credito`, 
									FechaDePromesa, 
									ValorPromesa
									FROM `gestion externa` 
										UNION 
											SELECT 
												'FechaLlamada', 
												Identificacion, 
												Producto, 
												NUM_Obligacion AS `Credito`, 
												FechaPromesa, 
												'ValorPromesa'
												FROM `gestion interna`) AS `ge` 
					) AS `00gpp1` 
					WHERE `00gpp1`.`Fecha_Promesa` IS NOT NULL) AS `07` 
			INNER JOIN `cruce segmento` AS `cs`
				ON `07`.`Identificacion` = `cs`.`IDENTIFICACION TXT` 
				AND `07`.`Producto` = `cs`.`Producto` 
				GROUP BY 
				`07`.`Producto`, 
				`07`.`Identificacion`, 
				`07`.`NUM_Obligacion`, 
				`07`.`Cred`, 
				`07`.`Llave SL`, 
				`07`.`Valor_Acuerdo`, 
				`cs`.`VALOR RECAUDO TOTAL`, 
				`07`.`Fecha_Promesa` 
					HAVING 
						`07`.`Producto` = "C1" 
						OR `07`.`Producto` = "TG" 
						OR `07`.`Producto` ="CP";
						
-- pp libranza
INSERT INTO `estado pp por dia` 
	(`Producto`, 
	`Identificacion`, 
	`Credito`, `Fecha_Promesa`, 
	`Fecha_Para_Calificar`, 
	`Valor Acuerdo`, 
	`Valor Recaudo Total`, 
	`Estado PP`)
	SELECT 
		`h`.`Producto`, 
		`h`.`Identificacion`, 
		`h`.`Credito`, 
		`h`.`MaxDeFecha_Promesa`, 
		`eppd12`.`Fecha_Para_Calificar`, 
		`eppd12`.`Valor Acuerdo`, 
		`eppd12`.`Valor Recaudo Total`, 
		`eppd12`.`Estado PP`
		FROM (
			SELECT 
				`Producto`, 
				`Identificacion`, 
				`Credito`, 
				MAX(`Fecha_Promesa`) AS `MaxDeFecha_Promesa` 
				FROM `estado pp por dia12` 
					GROUP BY `Producto`, 
					`Identificacion`, 
					`Credito`) AS `h`
			INNER JOIN `Estado pp por dia12` AS `eppd12`
				ON `h`.`Producto` = `eppd12`.`Producto` 
				AND `h`.`Identificacion` = `eppd12`.`Identificacion` 
				AND `h`.`Credito` = `eppd12`.`Credito` 
				AND `h`.`MaxDeFecha_Promesa` = `eppd12`.`Fecha_Promesa` 
				WHERE `h`.`Producto` ='CF'
				Or `h`.`Producto`='TC';
				
-- pp <> libranza
INSERT INTO `estado pp por dia` 
	(`Producto`, 
	`Identificacion`, 
	`Credito`, 
	`Fecha_Promesa`, 
	`Fecha_Para_Calificar`, 
	`Valor Acuerdo`, 
	`Valor Recaudo Total`, 
	`Estado PP`)
		SELECT 
			`ho`.`Producto`, 
			`ho`.`Identificacion`, 
			`ho`.`Credito`, 
			`ho`.`MaxDeFecha_Promesa`, 
			`eppd12`.`Fecha_Para_Calificar`, 
			`eppd12`.`Valor Acuerdo`, 
			`eppd12`.`Valor Recaudo Total`, 
			`eppd12`.`Estado PP` 
			FROM 
				(SELECT 
					`Producto`, 
					`Identificacion`, 
					`Credito`, 
					MAX(`Fecha_Promesa`) AS `MaxDeFecha_Promesa` 
					FROM `estado pp por dia12` 
						GROUP BY 
						`Producto`, 
						`Identificacion`, 
						`Credito` 
						HAVING 
						`Producto` = 'CP' 
						OR `Producto` = 'C1' 
						OR `Producto` = 'TG')AS `ho` 
				INNER JOIN `estado pp por dia12` AS `eppd12`
					ON `ho`.`MaxDeFecha_Promesa` = `eppd12`.FECHA_PROMESA 
					AND `ho`.`Identificacion` = `eppd12`.`Identificacion` 
					AND `ho`.`Producto` = `eppd12`.`Producto`;
					
-- 08 actualiza estado pp

END//
DELIMITER ;

-- Volcando estructura para tabla unificada.casas
CREATE TABLE IF NOT EXISTS `casas` (
  `Casa de Cobro` varchar(255) DEFAULT NULL,
  `Mejor Tipificacion Final` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.casos
CREATE TABLE IF NOT EXISTS `casos` (
  `Mes` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `CreditoSL` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Pagare` varchar(255) DEFAULT NULL,
  `Tarjeta` varchar(255) DEFAULT NULL,
  `FechaDesembolso` date DEFAULT NULL,
  `DiaDeFacturacion` int(11) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `Segmento` varchar(255) DEFAULT NULL,
  `CasaDeCobro` varchar(255) DEFAULT NULL,
  `Ejecutivo` varchar(255) DEFAULT NULL,
  `ValorCuota` double DEFAULT NULL,
  `SaldoCapital` double DEFAULT NULL,
  `CapitalEnMillones` varchar(255) DEFAULT NULL,
  `FranjaMora` varchar(255) DEFAULT NULL,
  `FranjaDelta` varchar(255) DEFAULT NULL,
  `FranjaDeltaBrujula` varchar(255) DEFAULT NULL,
  `DiasMoraHoy` int(11) DEFAULT NULL,
  `FechaUltimoPago` date DEFAULT NULL,
  `ValorRecaudo` double DEFAULT NULL,
  `TipoAplicado` varchar(255) DEFAULT NULL,
  `FechaPagoEfecty` date DEFAULT NULL,
  `ValorRecaudoEfecty` double DEFAULT NULL,
  `ValorRecaudoTotal` double DEFAULT NULL,
  `DiasMoraProy` int(11) DEFAULT NULL,
  `EstadoDelta` varchar(255) DEFAULT NULL,
  `Prioridad` varchar(255) DEFAULT NULL,
  `BloqueoU` varchar(255) DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `ConvenioHomologadoCorto` varchar(255) DEFAULT NULL,
  `ESP` varchar(255) DEFAULT NULL,
  `Medio` varchar(255) DEFAULT NULL,
  `Tipificacion` varchar(255) DEFAULT NULL,
  `Caso` varchar(255) DEFAULT NULL,
  `FechaAsesor` date DEFAULT NULL,
  `FechaEnvio` date DEFAULT NULL,
  `FechaDia` date DEFAULT NULL,
  `DiasDeEnvio` varchar(255) DEFAULT NULL,
  `Rango` varchar(255) DEFAULT NULL,
  `EscaladoA` varchar(255) DEFAULT NULL,
  `Solucion` varchar(255) DEFAULT NULL,
  `Validacion` varchar(255) DEFAULT NULL,
  `NumPQR` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.ciclos
CREATE TABLE IF NOT EXISTS `ciclos` (
  `CicloFacturacionCore` varchar(50) DEFAULT NULL,
  `FechaLimDePago` varchar(50) DEFAULT NULL,
  `DiaFacturacion` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.condonaciones
CREATE TABLE IF NOT EXISTS `condonaciones` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.consolida efecty
CREATE TABLE IF NOT EXISTS `consolida efecty` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` double DEFAULT NULL,
  `Numero_Credito` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `VLR_Pago` double DEFAULT NULL,
  `Fecha_Aplica_Pago` date DEFAULT NULL,
  `TRX` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.consolida recaudo
CREATE TABLE IF NOT EXISTS `consolida recaudo` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` double DEFAULT NULL,
  `Numero_Credito` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `VLR_Pago` double DEFAULT NULL,
  `Fecha_Aplica_Pago` date DEFAULT NULL,
  `TRX` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.consolidado_recaudo_tg
CREATE TABLE IF NOT EXISTS `consolidado_recaudo_tg` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Tarjeta` varchar(255) DEFAULT NULL,
  `Recaudo` double DEFAULT NULL,
  `Capital` double DEFAULT NULL,
  `Franja Mora` varchar(255) DEFAULT NULL,
  `Franja_Mora_Bu` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Mes` varchar(255) DEFAULT NULL,
  `Bloqueo_U` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.consulta3
CREATE TABLE IF NOT EXISTS `consulta3` (
  `Fecha Llamada` date DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `ANT` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.cruce
CREATE TABLE IF NOT EXISTS `cruce` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Casa` varchar(255) DEFAULT NULL,
  `Ejecutivo` varchar(255) DEFAULT NULL,
  `CC` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.cruce segmento
CREATE TABLE IF NOT EXISTS `cruce segmento` (
  `FILTRO CARTERA` varchar(255) DEFAULT NULL,
  `FILTRO CARTERA MODF` varchar(255) DEFAULT NULL,
  `FILTRO CARTERA HOY` varchar(255) DEFAULT NULL,
  `GRUPO` varchar(255) DEFAULT NULL,
  `PRODUCTO` varchar(255) DEFAULT NULL,
  `UNIDAD` varchar(255) DEFAULT NULL,
  `PRODUCTO_HOMOL` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` varchar(255) DEFAULT NULL,
  `TARJETA` varchar(255) DEFAULT NULL,
  `NUMERO_CREDITO` varchar(255) DEFAULT NULL,
  `CREDITO SL` varchar(255) DEFAULT NULL,
  `LLAVE` varchar(255) DEFAULT NULL,
  `LLAVE_TC` varchar(255) DEFAULT NULL,
  `LLAVE SL` varchar(255) DEFAULT NULL,
  `FECHA_DESEMBOLSO` varchar(255) DEFAULT NULL,
  `FECHA_PRIMERA_CUOTA` varchar(255) DEFAULT NULL,
  `FECHA_PROXIMO_PAGO` varchar(255) DEFAULT NULL,
  `FECHA_VENCIMIENTO_CREDITO` varchar(255) DEFAULT NULL,
  `FECHA_ULTIMA_PARADA` varchar(255) DEFAULT NULL,
  `FECHA_ULTIMA_CORRIDA` varchar(255) DEFAULT NULL,
  `ESTADO_ESCINDIDO` varchar(255) DEFAULT NULL,
  `COD_PRODUCTO` double DEFAULT NULL,
  `DIA DE FACTURACION` double DEFAULT NULL,
  `IDENTIFICACION` double DEFAULT NULL,
  `IDENTIFICACION TXT` varchar(255) DEFAULT NULL,
  `NOMBRE_COMPLETO` varchar(255) DEFAULT NULL,
  `PROM PAGO 3M` double DEFAULT NULL,
  `SEGMENTO X PAGO` varchar(255) DEFAULT NULL,
  `SEGMENTO ESPECIAL` varchar(255) DEFAULT NULL,
  `SEGMENTO` varchar(255) DEFAULT NULL,
  `SEGMENTO 2` varchar(255) DEFAULT NULL,
  `SEGMENTO_OPERATIVO` varchar(255) DEFAULT NULL,
  `SEGMENTO_RIESGOS` varchar(255) DEFAULT NULL,
  `SEGMENTO_MARCA` varchar(255) DEFAULT NULL,
  `CASA DE COBRO` varchar(255) DEFAULT NULL,
  `CASA DE COBRO 2` varchar(255) DEFAULT NULL,
  `EJECUTIVO` varchar(255) DEFAULT NULL,
  `CC EJECUTIVO` varchar(255) DEFAULT NULL,
  `PAGO MINIMO HOY` double DEFAULT NULL,
  `PAGO MINIMO` double DEFAULT NULL,
  `VALOR CUOTA` double DEFAULT NULL,
  `SALDO CAPITAL` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` double DEFAULT NULL,
  `PAGO TOTAL` double DEFAULT NULL,
  `CAPITAL_PENDIENTE` int(11) DEFAULT NULL,
  `SALDO_CREDITO` int(11) DEFAULT NULL,
  `CAPITAL_VIGENTE` int(11) DEFAULT NULL,
  `INTERES_Y_OTROS_TOTALES` double DEFAULT NULL,
  `INTERES_Y_OTROS_PENDIENTES` double DEFAULT NULL,
  `INTERES_PENDIENTE` int(11) DEFAULT NULL,
  `INTERES_PROYECTADO` int(11) DEFAULT NULL,
  `MORA_PENDIENTE` int(11) DEFAULT NULL,
  `MORA_PROYECTADA` int(11) DEFAULT NULL,
  `CARGOS_FIJOS_PROYECTADOS` int(11) DEFAULT NULL,
  `CARGOS_FIJOS_PENDIENTES` int(11) DEFAULT NULL,
  `CAPITAL_PROYECTADO` int(11) DEFAULT NULL,
  `DIAS MORA` double DEFAULT NULL,
  `FRANJA MORA` varchar(255) DEFAULT NULL,
  `PERFIL_RIESGO` varchar(255) DEFAULT NULL,
  `VALOR VENCIDO` double DEFAULT NULL,
  `EMPRESA` varchar(255) DEFAULT NULL,
  `CONVENIO_HOMOLOGADO` varchar(255) DEFAULT NULL,
  `CONVENIO_HOMOLOGADO_CORTO` varchar(255) DEFAULT NULL,
  `CONVENIO_ASEGURADORA` varchar(255) DEFAULT NULL,
  `ESP` varchar(255) DEFAULT NULL,
  `ESTADO_EMPRESA` varchar(255) DEFAULT NULL,
  `ULTIMO_MOTIVO_DE_NO_PAGO` varchar(255) DEFAULT NULL,
  `ULTIMO_MOTIVO_DE_NO_PAGO_HOMOLOGADO` varchar(255) DEFAULT NULL,
  `FECHA_ULTIMO_MOTIVO_DE_NO_PAGO` varchar(255) DEFAULT NULL,
  `DESTINO_ECONOMICO` varchar(255) DEFAULT NULL,
  `DESTINO_ECONOMICO_HOY` varchar(255) DEFAULT NULL,
  `CIUDAD_AGENCIA` varchar(255) DEFAULT NULL,
  `CIUDAD` varchar(255) DEFAULT NULL,
  `CIUDAD_DIRECCION` varchar(255) DEFAULT NULL,
  `DIRECCION` varchar(255) DEFAULT NULL,
  `TELEFONO` varchar(255) DEFAULT NULL,
  `CELULAR` varchar(255) DEFAULT NULL,
  `CIUDAD_CREDITO` varchar(255) DEFAULT NULL,
  `FRANJA DELTA` varchar(255) DEFAULT NULL,
  `FRANJA DELTA BRUJULA` varchar(255) DEFAULT NULL,
  `ULTIMA TIPIFICACION` varchar(255) DEFAULT NULL,
  `FECHA ULTIMA GESTION` date DEFAULT NULL,
  `CUENTA TOTAL TIPIFICACIONES` varchar(255) DEFAULT NULL,
  `ANTIGUEDAD ULTIMA TIPF` varchar(255) DEFAULT NULL,
  `FECHA MEJOR GESTION` date DEFAULT NULL,
  `FECHA MEJOR GESTION EXT` date DEFAULT NULL,
  `MEJOR TIPIFICACION` varchar(255) DEFAULT NULL,
  `MEJOR TIPIFICACION EXT` varchar(255) DEFAULT NULL,
  `ESTADO PROMESA` varchar(255) DEFAULT NULL,
  `MEJOR TIPIFICACION FINAL` varchar(255) DEFAULT NULL,
  `MEJOR TIPIFICACION FINAL EXT` varchar(255) DEFAULT NULL,
  `MEJOR TIPIF FINAL MES ANT` varchar(255) DEFAULT NULL,
  `CUENTA MEJOR TIPF` varchar(255) DEFAULT NULL,
  `FECHA PROMESA` date DEFAULT NULL,
  `VALOR ACUERDO` varchar(255) DEFAULT NULL,
  `FECHA MEJOR RAZON MORA` date DEFAULT NULL,
  `MEJOR RAZON MORA` varchar(255) DEFAULT NULL,
  `CUENTA MEJOR RAZON MORA` varchar(255) DEFAULT NULL,
  `ANTIGUEDAD HOMOLOGADA` varchar(255) DEFAULT NULL,
  `CUENTA TIPF HOMOLOGADA` varchar(255) DEFAULT NULL,
  `FRANJA DELTA HOY` varchar(255) DEFAULT NULL,
  `FRANJA DELTA MES ANT` varchar(255) DEFAULT NULL,
  `FRANJA_MORA_HOY` varchar(255) DEFAULT NULL,
  `DIAS_MORA_HOY` double DEFAULT NULL,
  `FECHA ULTIMO PAGO` varchar(255) DEFAULT NULL,
  `VALOR RECAUDO` double DEFAULT NULL,
  `TIPO APLICADO` varchar(255) DEFAULT NULL,
  `FECHA_PAGO EFECTY` date DEFAULT NULL,
  `VALOR RECAUDO EFECTY` double DEFAULT NULL,
  `VALOR RECAUDO TOTAL` double DEFAULT NULL,
  `VALOR RECAUDO EXTERNO` double DEFAULT NULL,
  `VALOR RECAUDO TOTAL_MES ANTERIOR` int(11) DEFAULT NULL,
  `DIAS PAR EL CORTE` int(11) DEFAULT NULL,
  `DIAS MORA PROY` int(11) DEFAULT NULL,
  `FRANJA MORA PROY` varchar(255) DEFAULT NULL,
  `FRANJA DELTA PROY` varchar(255) DEFAULT NULL,
  `ESTADO_CREDITO` varchar(255) DEFAULT NULL,
  `ESTADO GERENCIAL` varchar(255) DEFAULT NULL,
  `ESTADO DELTA` varchar(255) DEFAULT NULL,
  `ESTADO DELTA 30` varchar(255) DEFAULT NULL,
  `ESTADO DELTA 90` varchar(255) DEFAULT NULL,
  `ESTADO DELTA CICLO 5` varchar(255) DEFAULT NULL,
  `ESTADO DELTA SIN RED - FGA` varchar(255) DEFAULT NULL,
  `ESTADO DELTA MES ANT` varchar(255) DEFAULT NULL,
  `ESTADO DELTA MES ANT RED - FGA` varchar(255) DEFAULT NULL,
  `VALOR MÍNIMO` double DEFAULT NULL,
  `ESTADO GERENCIAL PAGOS` varchar(255) DEFAULT NULL,
  `ESTADO DELTA PAGOS` varchar(255) DEFAULT NULL,
  `ESTADO GERENCIAL SIN NORM` varchar(255) DEFAULT NULL,
  `ESTADO DELTA SIN NORM` varchar(255) DEFAULT NULL,
  `TIPIFICACION` varchar(255) DEFAULT NULL,
  `% PAGO VS CUOTA` double DEFAULT NULL,
  `RECAUDO_NOMINA_NUMERO` int(11) DEFAULT NULL,
  `RECAUDO_NOMINA_MES_ACTUAL` int(11) DEFAULT NULL,
  `GAG_APLICADO_MES` int(11) DEFAULT NULL,
  `RECAUDO_NOMINA_SIN_GAG` int(11) DEFAULT NULL,
  `RECAUDO_NOMINA_VS_CUOTA` double DEFAULT NULL,
  `RECUADO_NOMINA_TOTAL_VS_CUOTA` double DEFAULT NULL,
  `TASA NMV` varchar(255) DEFAULT NULL,
  `VALOR DESEMBOLSO` varchar(255) DEFAULT NULL,
  `NOMBRES` varchar(255) DEFAULT NULL,
  `APELLIDOS` varchar(255) DEFAULT NULL,
  `UNIDAD DEL CREDITO` varchar(255) DEFAULT NULL,
  `RECAUDO NOMINA MESES 1` double DEFAULT NULL,
  `RECAUDO NOMINA MESES 2` double DEFAULT NULL,
  `NIT CONVENIO` varchar(255) DEFAULT NULL,
  `CODIGO EMPRESA` varchar(255) DEFAULT NULL,
  `ENTIDAD_PROPIETARIA_CREDITO` varchar(255) DEFAULT NULL,
  `PLAZO` varchar(255) DEFAULT NULL,
  `CUOTAS PAGAS` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `MARCA ESPECIAL` varchar(255) DEFAULT NULL,
  `REDIFERIDO` varchar(255) DEFAULT NULL,
  `ZONA` varchar(255) DEFAULT NULL,
  `ASESOR` varchar(255) DEFAULT NULL,
  `REGIONAL` varchar(255) DEFAULT NULL,
  `ORIGINACION_CARTERA` varchar(255) DEFAULT NULL,
  `FECHA_INICIO_VIGENCIA` date DEFAULT NULL,
  `FECHA_FIN_VIGENCIA` date DEFAULT NULL,
  `ESTADO DE MARCAS` varchar(255) DEFAULT NULL,
  `TIPO CASOS` varchar(255) DEFAULT NULL,
  `SOLUCION CASOS` varchar(255) DEFAULT NULL,
  `Ciudad_Origen` varchar(255) DEFAULT NULL,
  `Ciudad_Ubicacion_Cliente` varchar(255) DEFAULT NULL,
  `POTENCIAL` varchar(255) DEFAULT NULL,
  `aseguradora_bizagi` varchar(255) DEFAULT NULL,
  `NOMBRE_CONVENIO_BIZAGI` varchar(255) DEFAULT NULL,
  `FECHA_LIMITE_PAGO_ESP` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.cuentas
CREATE TABLE IF NOT EXISTS `cuentas` (
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Pagare` varchar(255) DEFAULT NULL,
  `Numero_Tarjeta` varchar(255) DEFAULT NULL,
  `Saldo_Capital_Cartera` double DEFAULT NULL,
  `Capital_En_Millones` varchar(255) DEFAULT NULL,
  `Valor_Cuota` double DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `Convenio_Homologado` varchar(255) DEFAULT NULL,
  `Convenio_Homologado_Corto` varchar(255) DEFAULT NULL,
  `Fecha_Desembolso` date DEFAULT NULL,
  `Ciudad_Origen` varchar(255) DEFAULT NULL,
  `Plano_ESP_Agrupado` varchar(255) DEFAULT NULL,
  `Nombre_Cliente` varchar(255) DEFAULT NULL,
  `Tipo_De_Identificacion` varchar(255) DEFAULT NULL,
  `Valor_Cuota_Fija` varchar(255) DEFAULT NULL,
  `Plazo` int(11) DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `Zona` varchar(255) DEFAULT NULL,
  `Numero_Credito` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.diario
CREATE TABLE IF NOT EXISTS `diario` (
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `FILTRO_CARTERA_HOY` varchar(255) DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Dias_Mora_Hoy` int(11) DEFAULT NULL,
  `DIAS_MORA_PROY` int(11) DEFAULT NULL,
  `Franja_Mora_Hoy` varchar(255) DEFAULT NULL,
  `Estado_Delta` varchar(255) DEFAULT NULL,
  `Estado_Delta_30` varchar(255) DEFAULT NULL,
  `Estado_Delta_90` varchar(255) DEFAULT NULL,
  `Estado_Delta_CP_Ciclo5` varchar(255) DEFAULT NULL,
  `NUMERO_CREDITO` varchar(255) DEFAULT NULL,
  `CAPITAL_VIGENTE` double DEFAULT NULL,
  `SALDO_CAPITAL_HOY` double DEFAULT NULL,
  `TOTAL_INTERES` double DEFAULT NULL,
  `SALDO_TOTAL` double DEFAULT NULL,
  `FECHA_ULTIMA_CORRIDA_OPERATIVA` date DEFAULT NULL,
  `FECHA_ULTIMA_CORRIDA_COBRANZAS` date DEFAULT NULL,
  `Fecha_Corte` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.efecty cf
CREATE TABLE IF NOT EXISTS `efecty cf` (
  `NumeroOrden` varchar(255) DEFAULT NULL,
  `OficinaOrigen` varchar(255) DEFAULT NULL,
  `DESCOficinaOrigen` varchar(255) DEFAULT NULL,
  `Proyecto` varchar(255) DEFAULT NULL,
  `ValorMovilizado` double DEFAULT NULL,
  `ValorComision` double DEFAULT NULL,
  `FechaFacturacion` datetime DEFAULT NULL,
  `OficinaDestino` varchar(255) DEFAULT NULL,
  `ValorIVA` double DEFAULT NULL,
  `FechaCreps` datetime DEFAULT NULL,
  `Documento` varchar(255) DEFAULT NULL,
  `TipoDoc` varchar(255) DEFAULT NULL,
  `Nombres` varchar(255) DEFAULT NULL,
  `Apellido1` varchar(255) DEFAULT NULL,
  `Apellido2` varchar(255) DEFAULT NULL,
  `Saldo` varchar(255) DEFAULT NULL,
  `NumCred` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.efecty tc
CREATE TABLE IF NOT EXISTS `efecty tc` (
  `Documento` varchar(255) DEFAULT NULL,
  `NumeroOrden` varchar(255) DEFAULT NULL,
  `TipoDoc` varchar(255) DEFAULT NULL,
  `OficinaOrigen` varchar(255) DEFAULT NULL,
  `DESCOficinaOrigen` varchar(255) DEFAULT NULL,
  `Nombres` varchar(255) DEFAULT NULL,
  `Apellido1` varchar(255) DEFAULT NULL,
  `Proyecto` varchar(255) DEFAULT NULL,
  `ValorMovilizado` double DEFAULT NULL,
  `Apellido2` varchar(255) DEFAULT NULL,
  `DiasMora` varchar(255) DEFAULT NULL,
  `ValorComision` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `FechaFacturacion` datetime DEFAULT NULL,
  `OficinaDestino` varchar(255) DEFAULT NULL,
  `ValorIVA` double DEFAULT NULL,
  `FechaCreps` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.estado pp por dia
CREATE TABLE IF NOT EXISTS `estado pp por dia` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Fecha_Promesa` date DEFAULT NULL,
  `Fecha_Para_Calificar` date DEFAULT NULL,
  `Valor Acuerdo` double DEFAULT NULL,
  `Valor Recaudo Total` double DEFAULT NULL,
  `Estado PP` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.estado pp por dia12
CREATE TABLE IF NOT EXISTS `estado pp por dia12` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NUM_Obligacion` varchar(255) DEFAULT NULL,
  `Llave SL` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Fecha_Promesa` date DEFAULT NULL,
  `Fecha_Para_Calificar` date DEFAULT NULL,
  `Valor Acuerdo` double DEFAULT NULL,
  `Valor Recaudo Total` double DEFAULT NULL,
  `Estado PP` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.franjamorafoto_c1
CREATE TABLE IF NOT EXISTS `franjamorafoto_c1` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` double DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `Franja_Delta_Brujula` varchar(255) DEFAULT NULL,
  `Franja_Delta` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.gestion
CREATE TABLE IF NOT EXISTS `gestion` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.gestion externa
CREATE TABLE IF NOT EXISTS `gestion externa` (
  `FechaReporte` date DEFAULT NULL,
  `FechaLlamada` date DEFAULT NULL,
  `HoraGestionInicial` time DEFAULT NULL,
  `HoraGestionFinal` time DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NroProductoCredito` varchar(255) DEFAULT NULL,
  `NumeroMarcado` double DEFAULT NULL,
  `Tipificacion` varchar(255) DEFAULT NULL,
  `RazonMora` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `Franja` double DEFAULT NULL,
  `FechaDePromesa` date DEFAULT NULL,
  `ValorPromesa` double DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `MesAsignado` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Caso` double DEFAULT NULL,
  `Rediferido` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.gestion externa_no
CREATE TABLE IF NOT EXISTS `gestion externa_no` (
  `FechaReporte` date DEFAULT NULL,
  `FechaLlamada` date DEFAULT NULL,
  `HoraGestionInicial` time DEFAULT NULL,
  `HoraGestionFinal` time DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `NroProductoCredito` varchar(255) DEFAULT NULL,
  `NumeroMarcado` double DEFAULT NULL,
  `Tipificacion` varchar(255) DEFAULT NULL,
  `RazonMora` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `Franja` double DEFAULT NULL,
  `FechaDePromesa` date DEFAULT NULL,
  `ValorPromesa` double DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `MesAsignado` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `TipoGestion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.gestion interna
CREATE TABLE IF NOT EXISTS `gestion interna` (
  `Login` int(11) DEFAULT NULL,
  `FechaGestion` datetime DEFAULT NULL,
  `Usuario` varchar(255) DEFAULT NULL,
  `Station` int(11) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `AsesorAsignado` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NUM_Obligacion` varchar(255) DEFAULT NULL,
  `NumeroPoliza` varchar(255) DEFAULT NULL,
  `Campana` varchar(255) DEFAULT NULL,
  `Placa` varchar(255) DEFAULT NULL,
  `Grupo` int(11) DEFAULT NULL,
  `Corte` int(11) DEFAULT NULL,
  `TIPCodigo_Accion` varchar(255) DEFAULT NULL,
  `TIPTipo_Contacto` varchar(255) DEFAULT NULL,
  `TIPResultadoContacto` varchar(255) DEFAULT NULL,
  `TipoRazon` varchar(255) DEFAULT NULL,
  `TIPRazon_Mora` varchar(255) DEFAULT NULL,
  `TIPDetalle_Gestion` varchar(255) DEFAULT NULL,
  `FechaPromesa` date DEFAULT NULL,
  `ValorAcuerdo` double DEFAULT NULL,
  `MedioPago` varchar(255) DEFAULT NULL,
  `PAGNCuotas` varchar(255) DEFAULT NULL,
  `ValorTotal` double DEFAULT NULL,
  `PAGFechaPrimerPago` varchar(255) DEFAULT NULL,
  `TelefonoContacto` bigint(20) DEFAULT NULL,
  `ACTDireccion` varchar(255) DEFAULT NULL,
  `ACTCiudad` varchar(255) DEFAULT NULL,
  `ACTDepto` varchar(255) DEFAULT NULL,
  `ACTCelular` varchar(255) DEFAULT NULL,
  `ACTTelefono` varchar(255) DEFAULT NULL,
  `ACTEmail` varchar(255) DEFAULT NULL,
  `FechaVisita` varchar(255) DEFAULT NULL,
  `NUMNIEComprometido` varchar(255) DEFAULT NULL,
  `NombreTercero` varchar(255) DEFAULT NULL,
  `ParentescoTercero` varchar(255) DEFAULT NULL,
  `DepartamentoTercero` varchar(255) DEFAULT NULL,
  `CiudadTercero` varchar(255) DEFAULT NULL,
  `TelFijoTercero` varchar(255) DEFAULT NULL,
  `CelularTercero` varchar(255) DEFAULT NULL,
  `Ocupacion` varchar(255) DEFAULT NULL,
  `DESCOcupacion` varchar(255) DEFAULT NULL,
  `Plazo` int(11) DEFAULT NULL,
  `Tasa` int(11) DEFAULT NULL,
  `Cuota` int(11) DEFAULT NULL,
  `Negociacion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.gestion interna_no
CREATE TABLE IF NOT EXISTS `gestion interna_no` (
  `FechaReporte` date DEFAULT NULL,
  `FechaLlamada` date DEFAULT NULL,
  `HoraGestionInicial` time DEFAULT NULL,
  `HoraGestionFinal` time DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `NroProductoCredito` varchar(255) DEFAULT NULL,
  `NumeroMarcado` double DEFAULT NULL,
  `Tipificacion` varchar(255) DEFAULT NULL,
  `RazonMora` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `Franja` double DEFAULT NULL,
  `FechadePromesa` date DEFAULT NULL,
  `ValorPromesa` double DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `MesAsignado` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `TipoGestion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para procedimiento unificada.Gestion Solo Externa
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `Gestion Solo Externa`()
BEGIN

-- 05 anexa mejor gestion ext
SELECT 
	`05mge`.`FechaLlamada` AS `Fecha Llamada`, 
	`05mge`.`Identificacion`, 
	`p`.`Tipificacion Homologada`, 
	`05mge`.`Producto`, 
	`g`.`# Gestiones` AS `Numero de Gestiones`, 
	`05mge`.`Credito` AS `Nro Producto/Credito`, 
	/*`ae`.`Credito` AS `Credito`, */
	`c3`.`ANT` AS `Antiguedad de la Gestion` 
	FROM 
		(SELECT 
			Max(`ge`.`FechaLlamada`) AS `FechaLlamada`, 
			`ge`.`Identificacion`, 
			Max(`ge`.`NumeroMarcado`) AS `MaxDeNumeroMarcado`, 
			`ge`.`Credito`, 
			`ge`.`Producto`, 
			Min(`p`.`Ponderacion`) AS `Ponderacion` 
			FROM 
				(SELECT 
					FechaLlamada, 
					Identificacion, 
					NumeroMarcado, 
					NroProductoCredito AS `Credito`, 
					Producto, 
					Tipificacion
					FROM `gestion externa` 
						UNION 
							SELECT 
								'', 
								Identificacion, 
								'', 
								NUM_Obligacion AS `Credito`, 
								Producto, 
								''
								FROM `gestion interna`) AS `ge` 
								INNER JOIN 
									`ponderacion` AS `p` ON 
									`ge`.`Tipificacion` = `p`.`TIP ResultadoContacto` 
								GROUP BY 
									`ge`.`Identificacion`, 
									`ge`.`Credito`, 
									`ge`.`Producto`
			) AS `05mge`
			/*INNER JOIN 
				(SELECT 
					`d`.`IDENTIFICACION` AS `Identificacion TXT`, 
					`d`.`PRODUCTO` AS `Producto`, 
					`ge2`.`Credito` AS `Credito`, 
					LEFT(`d`.`CREDITO`,16) AS `Credito_2`, 
					`d`.`SALDO_CAPITAL_CARTERA` AS `Saldo Capital` 
						FROM 
							`inicio_dic` AS `d` 
						INNER JOIN 
							(SELECT 
								Identificacion,  
								NroProductoCredito AS `Credito`, 
								Producto 
									FROM `gestion externa` 
										UNION 
											SELECT 
												Identificacion, 
												NUM_Obligacion AS `Credito`, 
												Producto 
												FROM `gestion interna`) AS `ge2` 
							ON `d`.`Producto` = `ge2`.`Producto` 
							AND `d`.`IDENTIFICACION` = `ge2`.`Identificacion` 
						WHERE 
							`d`.`PRODUCTO` ="TC" 
							AND `d`.`CREDITO` LIKE '%s' 
							OR `d`.`CREDITO` LIKE '%e' 
							OR `d`.`CREDITO` LIKE '%p' 
							AND `d`.`SALDO_CAPITAL_CARTERA` > 0) AS `ae`*/
			INNER JOIN 
				`ponderacion` AS `p` 
				ON `05mge`.`Ponderacion` = `p`.`Ponderacion` 
			INNER JOIN 
				`consulta3` AS `c3` 
					ON `c3`.`Producto` = `05mge`.`Producto` 
					AND `05mge`.`Identificacion` = `c3`.`Identificacion` 
			LEFT JOIN 
				(SELECT 
					`Identificacion`, 
					COUNT(`Tipificacion`) AS `# Gestiones`, 
					`Producto`, 
					`Credito` 
					FROM 
						(SELECT 
							 Identificacion, 
							 `Tipificacion`, 
							 `Producto`,
							 NroProductoCredito AS `Credito`
							 FROM `gestion externa` 
							 	UNION 
								 SELECT 
									Identificacion, 
									'', 
									`Producto`, 
									NUM_Obligacion AS `Credito` 
									FROM `gestion interna`) AS `ge` 
					GROUP BY 
						`Identificacion`, 
						`Producto`, 
						`Credito`) AS `g`
				ON `05mge`.`Identificacion` = `g`.`Identificacion` 
				AND `05mge`.`Producto` = `g`.`Producto` 
				GROUP BY 
					`05mge`.`FechaLlamada`, 
					`05mge`.`Identificacion`, 
					`p`.`Tipificacion Homologada`, 
					`05mge`.`Producto`, 
					`g`.`# Gestiones`, 
					`05mge`.`Credito`;
		
-- 06 anexa mejor razon de mora
/*INSERT INTO `razon de mora`
	SELECT 
	`mrm`.`Identificacion`, 
	`mrm`.`Producto`, 
	`prm`.`Tipificacion Homologada` 
	FROM 
	(SELECT 
		Max(`ge`.`FechaLlamada`) AS `FechaLlamada`, 
		`ge`.`Identificacion`, 
		Max(`ge`.`NumeroMarcado`) AS `MaxDeNumeroMarcado`, 
		`ge`.`Credito`, 
		`ge`.`Producto`, 
		Min(`prm`.`Ponderacion`) AS `Ponderacion` 
		FROM 
		(SELECT 
			FechaLlamada, 
			`Identificacion`, 
			`NumeroMarcado`,
			NroProductoCredito AS `Credito`,
			Producto, 
			RazonMora
			FROM `gestion externa` 
				UNION 
					SELECT 
						'', 
						`Identificacion`, 
						'', 
						NUM_Obligacion AS `Credito`, 
						Producto, 
						''
						FROM `gestion interna`) AS `ge` 
		INNER JOIN `ponderacion razon mora` AS `prm` 
		ON `ge`.`RazonMora` = `prm`.`TIP ResultadoContacto` 
		GROUP BY 
			`ge`.`Identificacion`, 
			`ge`.`Credito`, 
			`ge`.`Producto`) AS `mrm` 
	INNER JOIN `ponderacion razon mora` AS `prm` 
	ON `mrm`.`Ponderacion` = `prm`.`Ponderacion` 
	GROUP BY 
		`mrm`.`Identificacion`, 
		`mrm`.`Producto`, 
		`prm`.`Tipificacion Homologada`;

-- consulta4
INSERT INTO `consulta3`
	SELECT 
	`FechaLlamada`, 
	`Identificacion`, 
	DATEDIFF(CURDATE(), `FechaLlamada`) AS `ANT`, 
	`Producto`, 
	`Credito` 
	FROM 
	(SELECT 
		Max(`FechaLlamada`) AS `FechaLlamada`, 
		`Identificacion`, 
		`Producto`, 
		`Credito` 
		FROM 
		(SELECT 
			FechaLlamada, 
			`Identificacion`, 
			NroProductoCredito AS `Credito`,
			Producto 
			FROM `gestion externa` 
				UNION 
					SELECT 
						'', 
						`Identificacion`, 
						NUM_Obligacion AS `Credito`, 
						Producto 
						FROM `gestion interna`) AS `ge`
		GROUP BY 
			`Identificacion`, 
			`Producto`, 
			`Credito`) AS `c1`;

-- 06 actualiza razon de mora
UPDATE `mejor gestion ext` AS `mge` 
	INNER JOIN `razon de mora` AS `rm` 
	ON `rm`.`Producto` = `mge`.`Producto` 
	AND `rm`.`Identificacion` = `mge`.`Identificacion` 
	SET `mge`.`Razon Mora` = `rm`.`Tipificacion Homologada`;*/

END//
DELIMITER ;

-- Volcando estructura para procedimiento unificada.Gestion Solo Interno
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `Gestion Solo Interno`()
BEGIN

-- actualiza producto tg
UPDATE `gestion externa` AS `ge` 
	INNER JOIN `gestion interna` AS `gi` 
	INNER JOIN `usuarios tigo` AS `ut` 
		ON `ge`.`Asesor` = `ut`.`Asesor` 
		AND `gi`.`Usuario` = `ut`.`Asesor`
		SET `ge`.`Producto` = `ut`.`Producto`, 
		`gi`.`Producto` = `ut`.`Producto`;
		
-- 05 anexa mejor gestion ext
SELECT 
	`05mge`.`FechaLlamada` AS `Fecha Llamada`, 
	`05mge`.`Identificacion`, 
	`p`.`Tipificacion Homologada`, 
	`05mge`.`Producto`, 
	`g`.`# Gestiones` AS `Numero de Gestiones`, 
	`05mge`.`Credito` AS `N° Producto/Credito`, 
	`ae`.`Credito` AS `Credito Cruce Segmento`, 
	`c3`.`ANT` AS `Antiguedad de la Gestion` 
	FROM 
		(SELECT 
			Max(`ge`.`FechaLlamada`) AS `FechaLlamada`, 
			`ge`.`Identificacion`, 
			Max(`ge`.`NumeroMarcado`) AS `MaxDeNumeroMarcado`, 
			`ge`.`Credito`, 
			`ge`.`Producto`, 
			Min(`p`.`Ponderacion`) AS `Ponderacion` 
			FROM 
				(SELECT 
					FechaLlamada, 
					Identificacion, 
					NumeroMarcado, 
					NroProductoCredito AS `Credito`, 
					Producto, 
					Tipificacion
					FROM `gestion externa` 
						UNION 
							SELECT 
								'', 
								Identificacion, 
								'', 
								NUM_Obligacion AS `Credito`, 
								Producto, 
								''
								FROM `gestion interna`) AS `ge` 
								INNER JOIN 
									`ponderacion` AS `p` ON 
									`ge`.`Tipificacion` = `p`.`TIP ResultadoContacto` 
								GROUP BY 
									`ge`.`Identificacion`, 
									`ge`.`Credito`, 
									`ge`.`Producto`
			) AS `05mge`
			INNER JOIN 
				(SELECT 
					`cs`.`IDENTIFICACION TXT` AS `Identificacion TXT`, 
					`cs`.`PRODUCTO` AS `Producto`, 
					`ge2`.`Credito` AS `Credito`, 
					LEFT(`cs`.`CREDITO`,16) AS `Credito_2`, 
					`cs`.`SALDO CAPITAL` AS `Saldo Capital` 
						FROM 
							`cruce segmento` AS `cs` 
						INNER JOIN 
							(SELECT 
								Identificacion,  
								NroProductoCredito AS `Credito`, 
								Producto 
									FROM `gestion externa` 
										UNION 
											SELECT 
												Identificacion, 
												NUM_Obligacion AS `Credito`, 
												Producto 
												FROM `gestion interna`) AS `ge2` 
							ON `cs`.`Producto` = `ge2`.`Producto` 
							AND `cs`.`Identificacion TXT` = `ge2`.`Identificacion` 
						WHERE 
							`cs`.`PRODUCTO` ="TC" 
							AND `cs`.`CREDITO` LIKE '%s' 
							OR `cs`.`CREDITO` LIKE '%e' 
							OR `cs`.`CREDITO` LIKE '%p' 
							AND `cs`.`SALDO CAPITAL` > 0) AS `ae`
			INNER JOIN 
				`ponderacion` AS `p` 
				ON `05mge`.`Ponderacion` = `p`.`Ponderacion` 
			INNER JOIN 
				`consulta3` AS `c3` 
					ON `c3`.`Producto` = `05mge`.`Producto` 
					AND `05mge`.`Identificacion` = `c3`.`Identificacion` 
			LEFT JOIN 
				(SELECT 
					`Identificacion`, 
					COUNT(`Tipificacion`) AS `# Gestiones`, 
					`Producto`, 
					`Credito` 
					FROM 
						(SELECT 
							 Identificacion, 
							 `Tipificacion`, 
							 `Producto`,
							 NroProductoCredito AS `Credito`
							 FROM `gestion externa` 
							 	UNION 
								 SELECT 
									Identificacion, 
									'', 
									`Producto`, 
									NUM_Obligacion AS `Credito` 
									FROM `gestion interna`) AS `ge` 
					GROUP BY 
						`Identificacion`, 
						`Producto`, 
						`Credito`) AS `g`
				ON `05mge`.`Identificacion` = `g`.`Identificacion` 
				AND `05mge`.`Producto` = `g`.`Producto` 
				GROUP BY 
					`05mge`.`FechaLlamada`, 
					`05mge`.`Identificacion`, 
					`p`.`Tipificacion Homologada`, 
					`05mge`.`Producto`, 
					`g`.`# Gestiones`, 
					`05mge`.`Credito`;
					
-- consulta4
INSERT INTO `consulta3`
	SELECT 
	`FechaLlamada`, 
	`Identificacion`, 
	DATEDIFF(CURDATE(), `FechaLlamada`) AS `ANT`, 
	`Producto`, 
	`Credito` 
	FROM 
	(SELECT 
		Max(`FechaLlamada`) AS `FechaLlamada`, 
		`Identificacion`, 
		`Producto`, 
		`Credito` 
		FROM 
		(SELECT 
			FechaLlamada, 
			`Identificacion`, 
			NroProductoCredito AS `Credito`,
			Producto 
			FROM `gestion externa` 
				UNION 
					SELECT 
						'', 
						`Identificacion`, 
						NUM_Obligacion AS `Credito`, 
						Producto 
						FROM `gestion interna`) AS `ge`
		GROUP BY 
			`Identificacion`, 
			`Producto`, 
			`Credito`) AS `c1`;

END//
DELIMITER ;

-- Volcando estructura para tabla unificada.hoja1
CREATE TABLE IF NOT EXISTS `hoja1` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_abr
CREATE TABLE IF NOT EXISTS `inicio_abr` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_ago
CREATE TABLE IF NOT EXISTS `inicio_ago` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_dic
CREATE TABLE IF NOT EXISTS `inicio_dic` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL,
  `Año` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_ene
CREATE TABLE IF NOT EXISTS `inicio_ene` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_feb
CREATE TABLE IF NOT EXISTS `inicio_feb` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_jul
CREATE TABLE IF NOT EXISTS `inicio_jul` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_jun
CREATE TABLE IF NOT EXISTS `inicio_jun` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_mar
CREATE TABLE IF NOT EXISTS `inicio_mar` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_nov
CREATE TABLE IF NOT EXISTS `inicio_nov` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_oct
CREATE TABLE IF NOT EXISTS `inicio_oct` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.inicio_sep
CREATE TABLE IF NOT EXISTS `inicio_sep` (
  `FILTRO_CARTERA` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `IDENTIFICACION` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` int(11) DEFAULT NULL,
  `NUMERO_TARJETA` varchar(255) DEFAULT NULL,
  `SALDO_CAPITAL_CARTERA` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` varchar(255) DEFAULT NULL,
  `VALOR_CUOTA` double DEFAULT NULL,
  `PAGO_MINIMO` double DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA` varchar(255) DEFAULT NULL,
  `FRANJA_DELTA_Brujula` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `CICLO` int(11) DEFAULT NULL,
  `PAGO_MINIMO_TOTAL` double DEFAULT NULL,
  `VALOR_CUOTA_FIJA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.marca especial
CREATE TABLE IF NOT EXISTS `marca especial` (
  `Credito` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Bloqueo_U` varchar(255) DEFAULT NULL,
  `Marca Especial` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.marcas
CREATE TABLE IF NOT EXISTS `marcas` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NroCredito` varchar(255) DEFAULT NULL,
  `Nombre` varchar(255) DEFAULT NULL,
  `TipoNegociacion` varchar(255) DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `FechaPago` date DEFAULT NULL,
  `ValorAcuerdo` double DEFAULT NULL,
  `ValorCuota` double DEFAULT NULL,
  `ValorPago` double DEFAULT NULL,
  `Plazo` int(11) DEFAULT NULL,
  `Tasa` int(11) DEFAULT NULL,
  `MedioDePago` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `DiasMora` int(11) DEFAULT NULL,
  `MotivoEspecial` varchar(255) DEFAULT NULL,
  `Validacion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.mejor gestion
CREATE TABLE IF NOT EXISTS `mejor gestion` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NUM_Obligacion` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Llave SL` varchar(255) DEFAULT NULL,
  `Ponderacion` double DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL,
  `TIP ResultadoContacto` varchar(255) DEFAULT NULL,
  `Fecha Mejor Gestion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.mejor gestion ext
CREATE TABLE IF NOT EXISTS `mejor gestion ext` (
  `Fecha Reporte` date DEFAULT NULL,
  `Fecha Llamada` date DEFAULT NULL,
  `Hora Gestion Inicial` date DEFAULT NULL,
  `Hora Gestion Final` date DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `N° Producto/Credito` varchar(255) DEFAULT NULL,
  `Numero Marcado` varchar(255) DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL,
  `Razon Mora` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `Franja` varchar(255) DEFAULT NULL,
  `Fecha de Promesa` date DEFAULT NULL,
  `Valor Promesa` double DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `Mes Asignado` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Antiguedad de la Gestion` varchar(255) DEFAULT NULL,
  `Numero de Gestiones` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.pagos
CREATE TABLE IF NOT EXISTS `pagos` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.pagos aplicados
CREATE TABLE IF NOT EXISTS `pagos aplicados` (
  `Cedula` double DEFAULT NULL,
  `VLRPago` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `TRXHomoloperaciones` varchar(255) DEFAULT NULL,
  `DescripcionTRX` varchar(255) DEFAULT NULL,
  `NumCredito` varchar(255) DEFAULT NULL,
  `FechaEfect` varchar(255) DEFAULT NULL,
  `FechaProc` varchar(255) DEFAULT NULL,
  `TotalPago` double DEFAULT NULL,
  `DiaFacturacion` int(11) DEFAULT NULL,
  `FechaProximoPago` date DEFAULT NULL,
  `CODProducto` int(11) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `SaldoCapital` double DEFAULT NULL,
  `CapitalEnMillones` double DEFAULT NULL,
  `EstadoCredito` varchar(255) DEFAULT NULL,
  `DiasMora` int(11) DEFAULT NULL,
  `FranjaMora` varchar(255) DEFAULT NULL,
  `ValorVencido` double DEFAULT NULL,
  `ValorCuotaVPG` double DEFAULT NULL,
  `FiltroCarteraOriginada` varchar(255) DEFAULT NULL,
  `FiltroCartera` varchar(255) DEFAULT NULL,
  `Llave` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `NumeroPoliza` varchar(255) DEFAULT NULL,
  `ValorPago` double DEFAULT NULL,
  `FechaPago` date DEFAULT NULL,
  `FechaProceso` date DEFAULT NULL,
  `TRXInterna` int(11) DEFAULT NULL,
  `LlavePlano` varchar(255) DEFAULT NULL,
  `LlaveSL` varchar(255) DEFAULT NULL,
  `FechaAplicacionRecaudo` date DEFAULT NULL,
  `CODEmpresa` int(11) DEFAULT NULL,
  `NIT` double DEFAULT NULL,
  `TipoRecaudo` int(11) DEFAULT NULL,
  `ConceptoRecaudo` varchar(255) DEFAULT NULL,
  `Comprobante` int(11) DEFAULT NULL,
  `ValorComprobante` double DEFAULT NULL,
  `Banco` varchar(255) DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Usuario` varchar(255) DEFAULT NULL,
  `MedioPago` varchar(255) DEFAULT NULL,
  `UnidadCredito` varchar(255) DEFAULT NULL,
  `ValorCredito` double DEFAULT NULL,
  `EntidadPropietariaCredito` varchar(255) DEFAULT NULL,
  `Concepto` varchar(255) DEFAULT NULL,
  `Valor` double DEFAULT NULL,
  `FechaAPL` date DEFAULT NULL,
  `FechaComprobante` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.pagos efecty
CREATE TABLE IF NOT EXISTS `pagos efecty` (
  `Documento` varchar(255) DEFAULT NULL,
  `Nombres` varchar(255) DEFAULT NULL,
  `Apellido1` varchar(255) DEFAULT NULL,
  `Apellido2` varchar(255) DEFAULT NULL,
  `NumeroOrden` varchar(255) DEFAULT NULL,
  `TipoDoc` varchar(255) DEFAULT NULL,
  `OficinaOrigen` varchar(255) DEFAULT NULL,
  `DESCOficinaOrigen` varchar(255) DEFAULT NULL,
  `Proyecto` varchar(255) DEFAULT NULL,
  `ValorMovilizado` double DEFAULT NULL,
  `DiasMora` varchar(255) DEFAULT NULL,
  `ValorComision` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `FechaFacturacion` datetime DEFAULT NULL,
  `OficinaDestino` varchar(255) DEFAULT NULL,
  `ValorIva` double DEFAULT NULL,
  `FechaCreps` datetime DEFAULT NULL,
  `Saldo` varchar(255) DEFAULT NULL,
  `NumCred` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.pago_minimo_c1
CREATE TABLE IF NOT EXISTS `pago_minimo_c1` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Pago_Minimo` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.pago_minimo_cp
CREATE TABLE IF NOT EXISTS `pago_minimo_cp` (
  `Pagare` varchar(7) DEFAULT NULL,
  `SumaDePago_Minimo_Total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.pago_minimo__tg
CREATE TABLE IF NOT EXISTS `pago_minimo__tg` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Pago_Minimo` decimal(10,0) DEFAULT NULL,
  `Filtro_Cartera` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.planta
CREATE TABLE IF NOT EXISTS `planta` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Nombre` varchar(255) DEFAULT NULL,
  `Ciudad` varchar(255) DEFAULT NULL,
  `Fecha Ingreso` date DEFAULT NULL,
  `Nombre Cargo` varchar(255) DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `Jefe Directo` varchar(255) DEFAULT NULL,
  `Unidad` varchar(255) DEFAULT NULL,
  `Niveles` varchar(255) DEFAULT NULL,
  `Observaciones` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.ponderacion
CREATE TABLE IF NOT EXISTS `ponderacion` (
  `Ponderacion` double DEFAULT NULL,
  `TIP ResultadoContacto` varchar(255) DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.ponderacion razon mora
CREATE TABLE IF NOT EXISTS `ponderacion razon mora` (
  `Ponderacion` double DEFAULT NULL,
  `TIP ResultadoContacto` varchar(255) DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.potencial
CREATE TABLE IF NOT EXISTS `potencial` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Identificacion_2` double DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Credito_SL` varchar(255) DEFAULT NULL,
  `Llave_SL` varchar(255) DEFAULT NULL,
  `Valor Cuota` double DEFAULT NULL,
  `Valor Pago` double DEFAULT NULL,
  `Valor Pago + GAG` double DEFAULT NULL,
  `Valor Pago + Gag Real` double DEFAULT NULL,
  `V-C Plano` double DEFAULT NULL,
  `Capital _Vigente` double DEFAULT NULL,
  `Saldo Capital` varchar(255) DEFAULT NULL,
  `Dias_Mora_Hoy` double DEFAULT NULL,
  `Proceso Juridico` varchar(255) DEFAULT NULL,
  `Estado_Credito` varchar(255) DEFAULT NULL,
  `Cantidad_Corridas` varchar(255) DEFAULT NULL,
  `Fecha_Ultima_Corrida` varchar(255) DEFAULT NULL,
  `Motivo Especial` varchar(255) DEFAULT NULL,
  `Validaciones` varchar(255) DEFAULT NULL,
  `Fecha_Desembolso` varchar(255) DEFAULT NULL,
  `COD_Producto` double DEFAULT NULL,
  `Tipo Negociacion` varchar(255) DEFAULT NULL,
  `Fecha COND-REEST` varchar(255) DEFAULT NULL,
  `asd` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.prod
CREATE TABLE IF NOT EXISTS `prod` (
  `Producto` varchar(255) DEFAULT NULL,
  `Producto_1` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.prod esc
CREATE TABLE IF NOT EXISTS `prod esc` (
  `Identificacion TXT` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Credito_2` varchar(255) DEFAULT NULL,
  `Saldo Capital` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.razon de mora
CREATE TABLE IF NOT EXISTS `razon de mora` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.recaudo
CREATE TABLE IF NOT EXISTS `recaudo` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` double DEFAULT NULL,
  `NumeroCredito` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `ValorPago` double DEFAULT NULL,
  `MaxDeFechaAplicaPago` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.recaudo c1
CREATE TABLE IF NOT EXISTS `recaudo c1` (
  `Cedula` double DEFAULT NULL,
  `NombreESP` varchar(255) DEFAULT NULL,
  `NumeroCredito` varchar(255) DEFAULT NULL,
  `VLRPago` double DEFAULT NULL,
  `FechaAplicaPago` date DEFAULT NULL,
  `FechaComprobante` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.recaudo cf
CREATE TABLE IF NOT EXISTS `recaudo cf` (
  `Producto` varchar(255) DEFAULT NULL,
  `TRXHomoloperaciones` varchar(255) DEFAULT NULL,
  `DescripcionTRX` varchar(255) DEFAULT NULL,
  `NUMCredito` varchar(255) DEFAULT NULL,
  `FechaEFECT` date DEFAULT NULL,
  `FechaPROC` date DEFAULT NULL,
  `TotalPago` double DEFAULT NULL,
  `DiaFacturacion` double DEFAULT NULL,
  `FechaProximoPago` date DEFAULT NULL,
  `CODProducto` double DEFAULT NULL,
  `Identificacion` double DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `SaldoCapital` double DEFAULT NULL,
  `CapitalEnMillones` double DEFAULT NULL,
  `EstadoCredito` varchar(255) DEFAULT NULL,
  `DiasMora` double DEFAULT NULL,
  `FranjaMora` varchar(255) DEFAULT NULL,
  `ValorVencido` double DEFAULT NULL,
  `ValorCuotaVPG` double DEFAULT NULL,
  `FiltroCarteraOriginada` varchar(255) DEFAULT NULL,
  `FiltroCartera` varchar(255) DEFAULT NULL,
  `Llave` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.recaudo cp
CREATE TABLE IF NOT EXISTS `recaudo cp` (
  `Credito` varchar(255) DEFAULT NULL,
  `Identificacion` double DEFAULT NULL,
  `NumeroPoliza` varchar(255) DEFAULT NULL,
  `ValorPago` double DEFAULT NULL,
  `FechaPago` date DEFAULT NULL,
  `FechaProceso` date DEFAULT NULL,
  `TRXInterna` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.recaudo efecty
CREATE TABLE IF NOT EXISTS `recaudo efecty` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` double DEFAULT NULL,
  `Numero_Credito` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Valor Pago` double DEFAULT NULL,
  `MaxDeFecha_Aplica_Pago` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.recaudo efecty tc letra
CREATE TABLE IF NOT EXISTS `recaudo efecty tc letra` (
  `Documento` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Valor_Movilizado` double DEFAULT NULL,
  `Fecha_Facturacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.recaudo tc
CREATE TABLE IF NOT EXISTS `recaudo tc` (
  `LlavePlano` varchar(255) DEFAULT NULL,
  `Llave` varchar(255) DEFAULT NULL,
  `LlaveSL` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `FechaAplicacionRecaudo` date DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `CODEmpresa` int(11) DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `NIT` varchar(255) DEFAULT NULL,
  `TipoRecaudo` double DEFAULT NULL,
  `ConceptoRecaudo` varchar(255) DEFAULT NULL,
  `Comprobante` double DEFAULT NULL,
  `ValorComprobante` double DEFAULT NULL,
  `Banco` varchar(255) DEFAULT NULL,
  `FechaPago` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Usuario` varchar(255) DEFAULT NULL,
  `MedioPago` varchar(255) DEFAULT NULL,
  `UnidadCredito` varchar(255) DEFAULT NULL,
  `ValorCredito` double DEFAULT NULL,
  `EntidadPropietariaCredito` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.recaudo tg
CREATE TABLE IF NOT EXISTS `recaudo tg` (
  `Concepto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Valor` double DEFAULT NULL,
  `FechaAPL` date DEFAULT NULL,
  `FechaComprobante` date DEFAULT NULL,
  `FechaProceso` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.rediferidos
CREATE TABLE IF NOT EXISTS `rediferidos` (
  `Cedula` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Autorizado` int(11) DEFAULT NULL,
  `Operativo` int(11) DEFAULT NULL,
  `Total` double DEFAULT NULL,
  `Valida` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.seg lb
CREATE TABLE IF NOT EXISTS `seg lb` (
  `Producto` varchar(255) DEFAULT NULL,
  `Segmento` varchar(255) DEFAULT NULL,
  `Nuevo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.segmento c1
CREATE TABLE IF NOT EXISTS `segmento c1` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.segmento cf
CREATE TABLE IF NOT EXISTS `segmento cf` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.segmento cp
CREATE TABLE IF NOT EXISTS `segmento cp` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.segmento tc
CREATE TABLE IF NOT EXISTS `segmento tc` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.segmento tg
CREATE TABLE IF NOT EXISTS `segmento tg` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.tasa_pago_minimo
CREATE TABLE IF NOT EXISTS `tasa_pago_minimo` (
  `Producto` varchar(255) DEFAULT NULL,
  `Pago Minimo` double DEFAULT NULL,
  `Saldo Capital` double DEFAULT NULL,
  `Tasa_PM` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.trx cp
CREATE TABLE IF NOT EXISTS `trx cp` (
  `TRX CP` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.usuarios tigo
CREATE TABLE IF NOT EXISTS `usuarios tigo` (
  `Asesor` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.usuarios unificada
CREATE TABLE IF NOT EXISTS `usuarios unificada` (
  `idUsuarios` int(11) NOT NULL AUTO_INCREMENT,
  `NombreUser` varchar(255) DEFAULT NULL,
  `Contra` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idUsuarios`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.
-- Volcando estructura para tabla unificada.ventas_cf
CREATE TABLE IF NOT EXISTS `ventas_cf` (
  `Credito` varchar(255) DEFAULT NULL,
  `Estado_Delta` varchar(255) DEFAULT NULL,
  `Fecha` varchar(255) DEFAULT NULL,
  `Valor Aplicado` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Saldo_Capital` varchar(255) DEFAULT NULL,
  `CXC Balance` varchar(255) DEFAULT NULL,
  `CXC Contingentes` varchar(255) DEFAULT NULL,
  `Saldo_Credito` varchar(255) DEFAULT NULL,
  `PROV Total` varchar(255) DEFAULT NULL,
  `PROV Estimada OCT 2017` varchar(255) DEFAULT NULL,
  `Gasto Octubre 17` varchar(255) DEFAULT NULL,
  `Cantidad_Corridas_Operativas` varchar(255) DEFAULT NULL,
  `Dias_Sistema` varchar(255) DEFAULT NULL,
  `Dia_Facturacion` varchar(255) DEFAULT NULL,
  `Fecha_Primera_Cuota` varchar(255) DEFAULT NULL,
  `Fecha_Proximo_Pago` varchar(255) DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `Convenio_Homologado_Corto` varchar(255) DEFAULT NULL,
  `Tipo_Empresa_Bizagi` varchar(255) DEFAULT NULL,
  `Crediprogreso` varchar(255) DEFAULT NULL,
  `Estado_Credito_31-10-2017` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- La exportación de datos fue deseleccionada.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
