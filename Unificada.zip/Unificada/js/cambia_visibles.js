function cambia_visibles(elemento) {
    if (elemento.value === "CF") {
        document.getElementById("importar").style.display = "inline";
        document.getElementById("titulo").style.display = "";
    } else if (elemento.value === "TC") {
        document.getElementById("importar").style.display = "inline";
        document.getElementById("titulo").style.display = "";
    } else {
        document.getElementById("importar").style.display = "none";
        document.getElementById("titulo").style.display = "none";
    }
}
