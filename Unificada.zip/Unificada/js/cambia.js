function cambia_visibles(elemento) {
    if (elemento.value === "Asignacion") {
        document.getElementById("Asig").style.display = "inline";
    } else if (elemento.value === "TC") {
        document.getElementById("importar").style.display = "inline";
    } else {
        document.getElementById("Asig").style.display = "none";
    }
}