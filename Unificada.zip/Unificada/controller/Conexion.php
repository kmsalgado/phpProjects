<?php

define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "unificada");

$conexion = mysqli_connect(DB_SERVER , DB_USER, DB_PASSWORD, DB_DATABASE);

//$conexion = mysqli_connect("localhost", "Root", "", "unificada");

/*class Conectar {

    public static function conexion() {
        $conexion = new mysqli("localhost", "root", "", "unificada");
        $conexion->query("SET NAMES 'utf8'");
        return $conexion;
    }

}*/