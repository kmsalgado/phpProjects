<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="../../library/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="../../library/metisMenu/metisMenu.min.css" rel="stylesheet">
        <link href="../../css/styles.css" rel="stylesheet">
        <link href="../../library/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">        
        <script src="../../library/jquery/jquery.min.js" defer=""></script>
        <script src="../../library/bootstrap/js/bootstrap.min.js" defer=""></script>
        <script src="../../library/metisMenu/metisMenu.min.js" defer=""></script>
        <script src="../../js/js1.js" defer=""></script>
    </head>
    <body>

    </body>
</html>