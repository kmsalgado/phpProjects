<html lang="en">
    <head>
        
    </head>
    <body>
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">                    
                <a class="navbar-brand">Cargar Unificada</a>
            </div>
            <ul class="nav navbar-top-links navbar-right">                
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-home fa-fw"></i> Inicio</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu" style="color: #000;">
                        <br/>
                        <p align="center" style="font-size: 18px; color: #337ab7;">Indice</p>
                        <li class="divider"></li>
                        <li>
                            <a href="../view/Update.php"><i class="fa fa-refresh fa-fw"></i> Actualizar</a>
                        </li>
                        <li>
                            <a href="../view/Load.php"><i class="fa fa-download fa-fw"></i> Descargar</a>
                        </li>
                        <!--<li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Charts<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="flot.html">Flot Charts</a>
                                </li>
                                <li>
                                    <a href="morris.html">Morris.js Charts</a>
                                </li>
                            </ul>
                        </li>-->
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
        </nav>
    </body>
</html>