<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require '../css/TmplHead.php'; ?>        
        <title>Descargar Unificada</title>
        <script src="../js/cambia.js" defer=""></script>
        <style>
            .table-fixed{
                width: 100%;
                background-color: #f3f3f3;
                tbody{
                    height:200px;
                    overflow-y:auto;
                    width: 100%;
                }
                thead,tbody,tr,td,th{
                    display:block;
                }
                tbody{
                    td{
                        float:left;
                    }
                }
                thead {
                    tr{
                        th{
                            float:left;
                            background-color: #f39c12;
                            border-color:#e67e22;
                        }
                    }
                }
            }
        </style>
    </head>

    <body>

        <div id="wrapper">
            <?php require '../css/TmplNabvar3.php'; ?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <br/>
                        <h1 class="page-header" align="center">Descargar Datos Unificada</h1>
                    </div>
                </div>
                <div class="row" align="center">
                    <div class="col-lg-12">
                        <form name="importa" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                            <div style="float: left;">
                                <!--<label>Tabla a Exportar</label>
                                &nbsp; &nbsp;-->
                                <select name="nombreTabla" class="form-control" style="display: inline-block; width: 180px;" required="">
                                    <!--<option selected="">Seleccione una tabla</option>
                                    <option value="Asignacion">Asignacion</option>
                                    <option value="Ciclos">Ciclos</option>
                                    <option value="Casos">Casos</option>
                                    <option value="Marcas">Marcas</option>-->
                                    <option value="Rediferidos">Rediferidos</option>
                                    <!--<option value="Condonaciones">Condonaciones</option>
                                    <option value="Efecty">Efecty</option>
                                    <option value="Recaudos">Recaudos</option>
                                    <option value="Pagos Aplicados">Pagos Aplicados</option>
                                    <option value="Pagos Efecty">Pagos Efecty</option>
                                    <option value="Gestion Interna">Gestion Interna</option>
                                    <option value="Gestion Externa">Gestion Externa</option>-->
                                </select>
                                &nbsp; &nbsp; &nbsp; &nbsp;
                                <!--<label style="display: inline-block;">Fecha</label>
                                &nbsp; &nbsp;
                                <input class="form-control" type="month" min="2017-12" max="2017-12" required="" style="display: inline-block; width: auto;"/>
                                &nbsp; &nbsp;
                                <span class="validity"></span>
                                &nbsp; &nbsp; &nbsp; &nbsp;-->
                                <label style="display: inline-block;">Producto</label>
                                &nbsp; &nbsp;
                                <select class="form-control" name="producto" required="" style="display: inline-block; width: auto;">
                                    <option selected="" value="">Seleccione un producto</option>
                                    <option value="CF">CF</option>
                                    <option value="CV">CV</option>
                                    <option value="CP">CP</option>
                                    <option value="C1">C1</option>
                                    <option value="TG">TG</option>
                                    <option value="TODOS">TODOS</option>
                                </select>

                                &nbsp; &nbsp; &nbsp; &nbsp;
                                <input type='submit' name='ver' value="Ver" style="width: 100px; display: inline-block;"/>
                                &nbsp; &nbsp; &nbsp; &nbsp;
                                <input type='submit' name='descargar' value="Descargar" style="width: 100px; display: inline-block;"/>
                            </div>
                            <!--<div style="float: right;">
                                &nbsp; &nbsp; &nbsp; &nbsp;
                                <input type='submit' name='reporte' value="Ver Reporte" style="width: 100px; display: inline-block;"/>
                            </div>-->
                            <br/> <br/> <br/> <br/>
                            <?php
                            include '../model/ProLoad.php';
                            ?>
                        </form>
                    </div>                    
                </div>
            </div>
        </div>       
    </body>
</html>