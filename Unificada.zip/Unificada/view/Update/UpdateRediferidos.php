<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require '../../css/TmplHead2.php'; ?>        
        <title>Actualizar Rediferidos</title>
    </head>

    <body>

        <div id="wrapper">
            <?php require '../../css/TmplNabvar2.php'; ?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <br/>
                        <h1 class="page-header" align="center">Rediferidos</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12" style="font-size: 16px;">
                        <p style="color: red; font-size: 20px;">NOTA: &nbsp;<a style="font-size: 17px; color: black;">Seleccione el archivo a importar.</a></p>
                        <br/><br/>
                        <form name="importa" action="../Update/UpdateRediferidos.php" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="tablasExp" style="font-size: 16px;">
                                <thead align="center">
                                    <tr class="headers">
                                        <th style="text-align: center;">Subir Archivos</th>
                                    </tr>
                                </thead>
                                <tbody align="center">                                
                                    <tr class="tables">
                                        <td>                                        
                                            <input type="file" name="excel" style="display: inline-block;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type='submit' name='enviar' value="Importar" style="display: inline-block;"/>
                                            <input type="hidden" value="upload" name="action" />
                                        </td>
                                    </tr>                                
                                </tbody>
                            </table>
                        </form>
                        <br/><br/>
                        <?php
                        /* ini_set("memory_limit", "-1"); */
                        set_time_limit(3600);
                        error_reporting(E_ALL);
                        ini_set('display_errors', TRUE);
                        ini_set('display_startup_errors', TRUE);
                        date_default_timezone_set('America/Bogota');
                        require_once '../../library/PHPExcel-1.8/Classes/PHPExcel.php';
                        require_once '../../library/PHPExcel-1.8/Classes/PHPExcel/Reader/Excel2007.php';
                        require_once '../../library/PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';
                        require '../../controller/Conexion.php';

                        $action = '';
                        extract($_POST);
                        if ($action == 'upload') {
                            $archivo = $_FILES['excel']['name'];
                            $tipo = $_FILES['excel']['type'];
                            $destino = "Arch_" . $archivo;
                            if (copy($_FILES['excel']['tmp_name'], $destino)) {
                                echo("<div class='alert alert-success' role='alert'><strong>Exito!</strong> Archivo cargado con exito.</div>");
                            } else {
                                echo "<div class='alert alert-danger' role='alert'><strong>Error!</strong> Error al cargar el archivo.</div>";
                            }
                            if (file_exists("Arch_" . $archivo)) {
                                /*$cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_phpTemp;
                                $cacheSettings = array('memoryCacheSize' => '256MB');
                                PHPExcel_Settings::setCacheStorageMethod($cacheMethod, $cacheSettings);*/
                                $objPHPExcel = PHPExcel_IOFactory::load("Arch_" . $archivo);
                                $objFecha = new PHPExcel_Shared_Date();
                                $objPHPExcel->setActiveSheetIndex(0);
                                $numRows = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();
                                for ($i = 2; $i <= $numRows; $i++) {
                                    $A = $objPHPExcel->getActiveSheet()->getCell('A' . $i)->getCalculatedValue();
                                    $B = $objPHPExcel->getActiveSheet()->getCell('B' . $i)->getCalculatedValue();
                                    $C = $objPHPExcel->getActiveSheet()->getCell('C' . $i)->getCalculatedValue();
                                    $D = $objPHPExcel->getActiveSheet()->getCell('D' . $i)->getCalculatedValue();
                                    $E = $objPHPExcel->getActiveSheet()->getCell('E' . $i)->getCalculatedValue();
                                    $F = $objPHPExcel->getActiveSheet()->getCell('F' . $i)->getCalculatedValue();
                                    $G = $objPHPExcel->getActiveSheet()->getCell('G' . $i)->getCalculatedValue();
                                    $H = $objPHPExcel->getActiveSheet()->getCell('H' . $i)->getCalculatedValue();
                                    $I = $objPHPExcel->getActiveSheet()->getCell('I' . $i)->getCalculatedValue();
                                    $J = $objPHPExcel->getActiveSheet()->getCell('J' . $i)->getCalculatedValue();
                                    $K = $objPHPExcel->getActiveSheet()->getCell('K' . $i)->getFormattedValue();
                                    $L = $objPHPExcel->getActiveSheet()->getCell('L' . $i)->getCalculatedValue();
                                    $M = $objPHPExcel->getActiveSheet()->getCell('M' . $i)->getCalculatedValue();
                                    $N = $objPHPExcel->getActiveSheet()->getCell('N' . $i)->getCalculatedValue();
                                    $O = $objPHPExcel->getActiveSheet()->getCell('O' . $i)->getCalculatedValue();
                                    $P = $objPHPExcel->getActiveSheet()->getCell('P' . $i)->getCalculatedValue();

                                    $c = ("INSERT INTO `rediferidos`(Producto,Identificacion,NroCredito_NroTarjeta,TipoCliente_ESP,Capital,"
                                            . "FranjaAlRediferir,ValorCuotaFija,NuevaTasa,NuevaCuota,NuevoPlazo,FechaEnvioOperaciones,ReportadoPor,Ciudad"
                                            . "NroTelefonoContactoClienteAlRediferir,TipoRediferido,Caracteristica) VALUES ('$A','$B','$C','$D','$E','$F',"
                                            . "'$G','$H','$I','$J','$K','$L','$M','$N','$O','$P')");
                                    $result = $conexion->query($c);
                                }
                            }
                        }
                        ?>
                    </div>                   
                </div>
            </div>
        </div>       
    </body>
</html>
