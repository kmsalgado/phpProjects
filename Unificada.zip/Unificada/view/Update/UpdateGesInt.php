<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require '../../css/TmplHead2.php'; ?>        
        <title>Actualizar Gestion Interna</title>
    </head>

    <body>

        <div id="wrapper">
            <?php require '../../css/TmplNabvar2.php'; ?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <br/>
                        <h1 class="page-header" align="center">Gestion Interna</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12" style="font-size: 16px;">
                        <p style="color: red; font-size: 20px;">NOTA: &nbsp;<a style="font-size: 17px; color: black;">Seleccione el archivo a importar.</a></p>
                        <br/><br/>
                        <form name="importa" action="../Update/UpdateGesInt.php" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="tablasExp" style="font-size: 16px;">
                                <thead align="center">
                                    <tr class="headers">
                                        <th style="text-align: center;">Subir Archivos</th>
                                    </tr>
                                </thead>
                                <tbody align="center">                                
                                    <tr class="tables">
                                        <td>                                        
                                            <input type="file" name="excel" style="display: inline-block;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type='submit' name='enviar' value="Importar" style="display: inline-block;"/>
                                            <input type="hidden" value="upload" name="action" />
                                        </td>
                                        <!--<td>
                                            <input type='submit' name="calcular" id="calcular" value="Calcular Mejor Gestion" style="display: inline-block;"/>
                                        </td>-->
                                    </tr>                                
                                </tbody>
                            </table>
                        </form>
                        <br/><br/>
                        <?php
                        set_time_limit(3600);
                        //ini_set('memory_limit', '-1');
                        error_reporting(E_ALL);
                        ini_set('display_errors', TRUE);
                        ini_set('display_startup_errors', TRUE);
                        date_default_timezone_set('America/Bogota');
                        require_once '../../library/PHPExcel-1.8/Classes/PHPExcel.php';
                        require_once '../../library/PHPExcel-1.8/Classes/PHPExcel/Reader/Excel2007.php';
                        require_once '../../library/PHPExcel-1.8/Classes/PHPExcel/IOFactory.php';
                        require '../../controller/Conexion.php';

                        $action = '';
                        extract($_POST);
                        $action = 'upload';
                        if (isset($_POST['enviar'])) {
                            $archivo = $_FILES['excel']['name'];
                            $tipo = $_FILES['excel']['type'];
                            $destino = "Arch_" . $archivo;
                            if (copy($_FILES['excel']['tmp_name'], $destino)) {
                                echo("<div class='alert alert-success' role='alert'><strong>Exito!</strong> Archivo cargado con exito.</div>");
                            } else {
                                echo "<div class='alert alert-danger' role='alert'><strong>Error!</strong> Error al cargar el archivo.</div>";
                            }
                            if (file_exists("Arch_" . $archivo)) {
                                $objPHPExcel = PHPExcel_IOFactory::load("Arch_" . $archivo);
                                $objFecha = new PHPExcel_Shared_Date();
                                $objPHPExcel->setActiveSheetIndex(0);
                                $numRows = $objPHPExcel->setActiveSheetIndex(0)->getHighestRow();
                                $numCol = $objPHPExcel->setActiveSheetIndex(0)->getHighestColumn();

                                for ($i = 2; $i <= $numRows; $i++) {
                                    $A = $objPHPExcel->getActiveSheet()->getCell('A' . $i)->getCalculatedValue();
                                    $B = $objPHPExcel->getActiveSheet()->getCell('B' . $i)->getFormattedValue();
                                    $C = $objPHPExcel->getActiveSheet()->getCell('C' . $i)->getCalculatedValue();
                                    $D = $objPHPExcel->getActiveSheet()->getCell('D' . $i)->getCalculatedValue();
                                    $E = $objPHPExcel->getActiveSheet()->getCell('E' . $i)->getCalculatedValue();
                                    $F = $objPHPExcel->getActiveSheet()->getCell('F' . $i)->getCalculatedValue();
                                    $G = $objPHPExcel->getActiveSheet()->getCell('G' . $i)->getCalculatedValue();
                                    $H = $objPHPExcel->getActiveSheet()->getCell('H' . $i)->getCalculatedValue();
                                    $I = $objPHPExcel->getActiveSheet()->getCell('I' . $i)->getCalculatedValue();
                                    $J = $objPHPExcel->getActiveSheet()->getCell('J' . $i)->getCalculatedValue();
                                    $K = $objPHPExcel->getActiveSheet()->getCell('K' . $i)->getCalculatedValue();
                                    $L = $objPHPExcel->getActiveSheet()->getCell('L' . $i)->getCalculatedValue();
                                    $M = $objPHPExcel->getActiveSheet()->getCell('M' . $i)->getCalculatedValue();
                                    $N = $objPHPExcel->getActiveSheet()->getCell('N' . $i)->getCalculatedValue();
                                    $O = $objPHPExcel->getActiveSheet()->getCell('O' . $i)->getCalculatedValue();
                                    $P = $objPHPExcel->getActiveSheet()->getCell('P' . $i)->getCalculatedValue();
                                    $Q = $objPHPExcel->getActiveSheet()->getCell('Q' . $i)->getCalculatedValue();
                                    $R = $objPHPExcel->getActiveSheet()->getCell('R' . $i)->getCalculatedValue();
                                    $S = $objPHPExcel->getActiveSheet()->getCell('S' . $i)->getCalculatedValue();
                                    $T = $objPHPExcel->getActiveSheet()->getCell('T' . $i)->getCalculatedValue();
                                    $U = $objPHPExcel->getActiveSheet()->getCell('U' . $i)->getCalculatedValue();
                                    $V = $objPHPExcel->getActiveSheet()->getCell('V' . $i)->getCalculatedValue();
                                    $W = $objPHPExcel->getActiveSheet()->getCell('W' . $i)->getCalculatedValue();
                                    $X = $objPHPExcel->getActiveSheet()->getCell('X' . $i)->getCalculatedValue();
                                    $Y = $objPHPExcel->getActiveSheet()->getCell('Y' . $i)->getCalculatedValue();
                                    $Z = $objPHPExcel->getActiveSheet()->getCell('Z' . $i)->getCalculatedValue();
                                    $AA = $objPHPExcel->getActiveSheet()->getCell('AA' . $i)->getCalculatedValue();
                                    $AB = $objPHPExcel->getActiveSheet()->getCell('AB' . $i)->getCalculatedValue();
                                    $AC = $objPHPExcel->getActiveSheet()->getCell('AC' . $i)->getCalculatedValue();
                                    $AD = $objPHPExcel->getActiveSheet()->getCell('AD' . $i)->getCalculatedValue();
                                    $AE = $objPHPExcel->getActiveSheet()->getCell('AE' . $i)->getCalculatedValue();
                                    $AF = $objPHPExcel->getActiveSheet()->getCell('AF' . $i)->getCalculatedValue();
                                    $AG = $objPHPExcel->getActiveSheet()->getCell('AG' . $i)->getCalculatedValue();
                                    $AH = $objPHPExcel->getActiveSheet()->getCell('AH' . $i)->getCalculatedValue();
                                    $AI = $objPHPExcel->getActiveSheet()->getCell('AI' . $i)->getCalculatedValue();
                                    $AJ = $objPHPExcel->getActiveSheet()->getCell('AJ' . $i)->getCalculatedValue();
                                    $AK = $objPHPExcel->getActiveSheet()->getCell('AK' . $i)->getCalculatedValue();
                                    $AL = $objPHPExcel->getActiveSheet()->getCell('AL' . $i)->getCalculatedValue();
                                    $AM = $objPHPExcel->getActiveSheet()->getCell('AM' . $i)->getCalculatedValue();
                                    $AN = $objPHPExcel->getActiveSheet()->getCell('AN' . $i)->getCalculatedValue();
                                    $AO = $objPHPExcel->getActiveSheet()->getCell('AO' . $i)->getCalculatedValue();
                                    $AP = $objPHPExcel->getActiveSheet()->getCell('AP' . $i)->getCalculatedValue();
                                    $AQ = $objPHPExcel->getActiveSheet()->getCell('AQ' . $i)->getCalculatedValue();
                                    $AR = $objPHPExcel->getActiveSheet()->getCell('AR' . $i)->getCalculatedValue();
                                    $AS = $objPHPExcel->getActiveSheet()->getCell('AS' . $i)->getCalculatedValue();
                                    $AT = $objPHPExcel->getActiveSheet()->getCell('AT' . $i)->getCalculatedValue();

                                    $c = ("INSERT INTO `gestion interna`(Login,FechaGestion,Usuario,Station,Producto,AsesorAsignado,Identificacion,"
                                            . "NUM_Obligacion,NumeroPoliza,Campana,Placa,Grupo,Corte,TIPCodigo_Accion,TIPTipo_Contacto,"
                                            . "TIPResultadoContacto,TipoRazon,TIPRazon_Mora,TIPDetalle_Gestion,FechaPromesa,ValorAcuerdo,MedioPago,"
                                            . "PAGNCuotas,ValorTotal,PAGFechaPrimerPago,TelefonoContacto,ACTDireccion,ACTCiudad,ACTDepto,ACTCelular,"
                                            . "ACTTelefono,ACTEmail,FechaVisita,NUMNIEComprometido,NombreTercero,ParentescoTercero,DepartamentoTercero,"
                                            . "CiudadTercero,TelFijoTercero,CelularTercero,Ocupacion,DESCOcupacion,Plazo,Tasa,Cuota,Negociacion) VALUES ('$A','$B','$C','$D','$E','$F','$G','$H','$I','$J',"
                                            . "'$K','$L','$M','$N','$O','$P','$Q','$R','$S','$T','$U','$V','$W','$X','$Y','$Z','$AA','$AB','$AC','$AD',"
                                            . "'$AE','$AF','$AG','$AH','$AI','$AJ','$AK','$AL','$AM','$AN','$AO','$AP','$AQ','$AR','$AS','$AT')");
                                    $result = $conexion->query($c);

                                    //echo "getHighestColumn() =  [" . $numCol . "]<br/>";
                                    //if ($maxcell == 46){
                                    //  echo 'hola';
                                    //}
                                }
                            }

                            $call = "CALL `Gestion_Solo_Externa`()";
                            $registros = $conexion->query($call);
                            if ($registros == false) {
                                echo("<div class='alert alert-danger' role='alert'><strong>Error!</strong> Al calcular mejor gestion.</div>");
                            } else {                                
                                echo "<div class='table-responsive'>";
                                echo "<table class='table table-bordered' "
                                . "data-tablesaw-mode='swipe' "
                                . "id='dataTable' "
                                . "width='100%' "
                                . "cellspacing='0' "
                                . "style='font-size: 12px;'>";
                                echo "<thead>";
                                echo "<tr>";
                                echo "<th>Fecha Llamada</th>";
                                echo "<th>Identificacion</th>";
                                echo "<th>Tipificacion Homologada</th>";
                                echo "<th>Producto</th>";
                                echo "<th>Numero de Gestiones</th>";
                                echo "<th>N° Producto/Credito</th>";
                                echo "<th>Antiguedad de la Gestion</th>";
                                echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";

                                while ($row = $registros->fetch_array()) {
                                    echo "<tr>";
                                    echo "<td>" . $row["Fecha Llamada"] . " </td>";
                                    echo "<td>" . $row["Identificacion"] . " </td>";
                                    echo "<td>" . $row["Tipificacion Homologada"] . " </td>";
                                    echo "<td>" . $row["Producto"] . " </td>";
                                    echo "<td>" . $row["Numero de Gestiones"] . " </td>";
                                    echo "<td>" . $row["Nro Producto/Credito"] . " </td>";
                                    echo "<td>" . $row["Antiguedad de la Gestion"] . " </td>";
                                }
                                echo "</table>";
                                echo "</div>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>       
    </body>
</html>
