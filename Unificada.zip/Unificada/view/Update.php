<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require '../css/TmplHead.php'; ?>        
        <title>Actualizar Unificada</title>
    </head>

    <body>

        <div id="wrapper">
            <?php require '../css/TmplNabvar.php'; ?>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header" align="center">Actualizar Datos Unificada</h1>
                    </div>
                </div>
                <div class="row" align="center">
                    <div class="col-lg-12">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="tablasExp" style="font-size: 16px;">
                            <thead align="center">
                            </thead>
                            <tbody align="center">
                                <tr class="tables">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdateAsignacion.php"--><a style="color: #337ab7;">Asignacion</a></td>
                                </tr>
                                <tr class="tables">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdateCiclos.php"--><a style="color: #337ab7;">Ciclos</a></td>
                                </tr>
                                <tr class="tables">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdateCasos.php"--><a style="color: #337ab7;">Casos</a></td>
                                </tr>
                                <tr class="tables">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdateMarcas.php"--><a style="color: #337ab7;">Marcas</a></td>
                                </tr>
                                <tr class="tables">
                                    <td><a href="../view/Update/UpdateRediferidos.php" style="color: #337ab7;">Rediferidos</a></td>
                                </tr>
                                <tr class="tables">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdateCondonaciones.php"--><a style="color: #337ab7;">Condonaciones</a></td>
                                </tr>
                                <tr class="tables">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdateEfecty.php"--><a style="color: #337ab7;">Efecty</a></td>
                                </tr>
                                <tr class="tables">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdateRecaudos.php"--><a style="color: #337ab7;">Recaudos</a></td>
                                </tr>
                                <tr class="tables1">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdatePagApli.php"--><a style="color: #337ab7;">Pagos Aplicados</a></td>
                                </tr>
                                <tr class="tables2">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdatePagEfec.php"--><a style="color: #337ab7;">Pagos Efecty</a></td>
                                </tr>
                                <tr class="tables3">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdateGesInt.php"--><a style="color: #337ab7;">Gestion Interna</a></td>
                                </tr>
                                <tr class="tables4">
                                    <td style="opacity: 0.3;"><!--href="../view/Update/UpdateGesExt.php"--><a style="color: #337ab7;">Gestion Externa</a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>                    
                </div>
            </div>
        </div>       
    </body>
</html>