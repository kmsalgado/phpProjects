<html>
    <head>
        <title>Importar Unificada</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    </head>
    <body>
        <?php
        error_reporting(E_ALL);
        ini_set('display_errors', TRUE);
        ini_set('display_startup_errors', TRUE);
        date_default_timezone_set('America/Bogota');
        require_once("./controller/Conexion.php");
        header('Location: view/Update.php');
        ?>
    </body>	
</html>