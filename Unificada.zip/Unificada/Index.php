<?php
ob_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Importar Unificada</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="library/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="library/metisMenu/metisMenu.min.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <link href="library/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <script src="library/jquery/jquery.min.js" defer=""></script>
        <script src="library/bootstrap/js/bootstrap.min.js" defer=""></script>
        <script src="library/metisMenu/metisMenu.min.js" defer=""></script>
        <script src="js/js1.js" defer=""></script>
        <script>
            function pulsar(e) {
                tecla = (document.all) ? e.keyCode : e.which;
                return (tecla !== 13);
            }
        </script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <!--<div class="col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title">Ingresar Unificada</h3>
                        </div>
                        <div class="panel-body">
                            <form role="form">
                                <fieldset>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Usuario" name="usuario" type="text" autofocus="">
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Contraseña" name="contra" type="password" value="">
                                    </div>

                                    <button href="" name="entrar" class="btn btn-lg btn-success btn-block">Entrar</button>
                                    <?ph
                                    //error_reporting(E_ALL);
                                    //ini_set('display_errors', TRUE);
                                    //ini_set('display_startup_errors', TRUE);
                                    date_default_timezone_set('America/Bogota');
                                    require("./controller/Conexion.php");

                                    if (isset($_POST['entrar'])) {
                                        error_reporting(0);
                                        $usu = $_POST['usuario'];
                                        $clave = $_POST['contra'];
                                        $proceso = "SELECT * FROM `usuarios unificada` WHERE NombreUser = '$usu' AND Contra='$clave';";

                                        if ($resultado = $conexion->query($proceso)) {
                                            while ($row = $resultado->fetch_array()) {
                                                $userok = $row["NombreUser"];
                                                $passok = $row["Contra"];
                                            }
                                        }

                                        if ($usu == $userok && $clave == $passok) {
                                            session_start();
                                            $_SESSION["u_usuario"] = 1;
                                            header("location:./view/Update.php");
                                        } else {
                                            $_SESSION["u_usuario"] = 0;
                                            echo "<div class='alert alert-danger' role='alert'><strong>Error!</strong> El usuario no existe.</div>";
                                        }
                                    }
                                    ?>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>-->
                <?php
                header("location:./view/Update.php")
                ?>
            </div>
        </div>        
    </body>	
</html>
<?php
ob_end_flush();