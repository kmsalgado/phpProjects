<?php

set_time_limit(3600);
ini_set('memory_limit', '64M');
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('America/Bogota');
require_once '../controller/Conexion.php';
require_once '../library/PHPExcel-1.8/Classes/PHPExcel.php';

/* if (isset($_POST['reporte'])) {
  $consult = "SELECT *
  FROM gestion_externa
  LIMIT 50;";
  echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0' style='font-size: 12px;'>";
  echo "<thead>";
  echo "<tr>";
  echo "<th>1</th>";
  echo "<th>2</th>";
  echo "<th>3</th>";
  echo "<th>4</th>";
  echo "<th>5</th>";
  echo "<th>6</th>";
  echo "<th>7</th>";
  echo "<th>8</th>";
  echo "<th>9</th>";
  echo "<th>10</th>";
  echo "<th>11</th>";
  echo "<th>12</th>";
  echo "<th>13</th>";
  echo "<th>14</th>";
  echo "<th>15</th>";
  echo "<th>16</th>";
  echo "<th>17</th>";
  echo "<th>18</th>";
  echo "</tr>";
  echo "</thead>";
  $matriz = mysqli_query($conexion, $consult);
  while ($fila = mysqli_fetch_row($matriz)) {
  echo "<tbody>";
  echo "<tr>";
  echo "<td>" . $fila[0] . "</td>";
  echo "<td>" . $fila[1] . "</td>";
  echo "<td>" . $fila[2] . "</td>";
  echo "<td>" . $fila[3] . "</td>";
  echo "<td>" . $fila[4] . "</td>";
  echo "<td>" . $fila[5] . "</td>";
  echo "<td>" . $fila[6] . "</td>";
  echo "<td>" . $fila[7] . "</td>";
  echo "<td>" . $fila[8] . "</td>";
  echo "<td>" . $fila[9] . "</td>";
  echo "<td>" . $fila[10] . "</td>";
  echo "<td>" . $fila[11] . "</td>";
  echo "<td>" . $fila[12] . "</td>";
  echo "<td>" . $fila[13] . "</td>";
  echo "<td>" . $fila[14] . "</td>";
  echo "<td>" . $fila[15] . "</td>";
  echo "<td>" . $fila[16] . "</td>";
  echo "<td>" . $fila[17] . "</td>";
  echo "</tr>";
  echo "</tbody>";
  }
  echo "</table>";
  } */
if (isset($_POST['ver'])) {
    $consulta1 = "SELECT * FROM rediferidos WHERE Producto = 'CF'";
    $consulta2 = "SELECT * FROM rediferidos WHERE Producto = 'CV'";
    $consulta3 = "SELECT * FROM rediferidos WHERE Producto = 'CP'";
    $consulta4 = "SELECT * FROM rediferidos WHERE Producto = 'C1'";
    $consulta5 = "SELECT * FROM rediferidos WHERE Producto = 'TG'";
    $consulta6 = "SELECT * FROM rediferidos";
    echo "<table width='100%' class='table table-fixed' id='tablasExp' style='font-size: 12px;'>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Producto</th>";
    echo "<th>Identificacion</th>";
    echo "<th>N° Credito/N° Tarjeta</th>";
    echo "<th>Tipo Cliente/ESP</th>";
    echo "<th>Capital</th>";
    echo "<th>Franja Al Rediferir</th>";
    echo "<th>Valor Cuota Fija</th>";
    echo "<th>Nueva Tasa</th>";
    echo "<th>Nueva Cuota</th>";
    echo "<th>Nuevo Plazo</th>";
    echo "<th>Fecha de Envio</th>";
    echo "<th>Reportado Por</th>";
    echo "<th>Ciudad</th>";
    echo "<th>N° Telefono del Cliente</th>";
    echo "<th>Tipo Rediferido</th>";
    echo "<th>Caracteristica</th>";
    echo "</tr>";
    echo "</thead>";
    if ($_POST['producto'] === 'CF') {
        $matriz = mysqli_query($conexion, $consulta1);
        while ($fila = mysqli_fetch_row($matriz)) {
            echo "<tbody>";
            echo "<tr>";
            echo "<td>" . $fila[0] . "</td>";
            echo "<td>" . $fila[1] . "</td>";
            echo "<td>" . $fila[2] . "</td>";
            echo "<td>" . $fila[3] . "</td>";
            echo "<td>" . $fila[4] . "</td>";
            echo "<td>" . $fila[5] . "</td>";
            echo "<td>" . $fila[6] . "</td>";
            echo "<td>" . $fila[7] . "</td>";
            echo "<td>" . $fila[8] . "</td>";
            echo "<td>" . $fila[9] . "</td>";
            echo "<td>" . $fila[10] . "</td>";
            echo "<td>" . $fila[11] . "</td>";
            echo "<td>" . $fila[12] . "</td>";
            echo "<td>" . $fila[13] . "</td>";
            echo "<td>" . $fila[14] . "</td>";
            echo "<td>" . $fila[15] . "</td>";
            echo "</tr>";
            echo "</tbody>";
        }
    } elseif ($_POST['producto'] === 'CV') {
        $matriz = mysqli_query($conexion, $consulta2);
        while ($fila = mysqli_fetch_row($matriz)) {
            echo "<tbody>";
            echo "<tr>";
            echo "<td>" . $fila[0] . "</td>";
            echo "<td>" . $fila[1] . "</td>";
            echo "<td>" . $fila[2] . "</td>";
            echo "<td>" . $fila[3] . "</td>";
            echo "<td>" . $fila[4] . "</td>";
            echo "<td>" . $fila[5] . "</td>";
            echo "<td>" . $fila[6] . "</td>";
            echo "<td>" . $fila[7] . "</td>";
            echo "<td>" . $fila[8] . "</td>";
            echo "<td>" . $fila[9] . "</td>";
            echo "<td>" . $fila[10] . "</td>";
            echo "<td>" . $fila[11] . "</td>";
            echo "<td>" . $fila[12] . "</td>";
            echo "<td>" . $fila[13] . "</td>";
            echo "<td>" . $fila[14] . "</td>";
            echo "<td>" . $fila[15] . "</td>";
            echo "</tr>";
            echo "</tbody>";
        }
    } elseif ($_POST['producto'] === 'CP') {
        $matriz = mysqli_query($conexion, $consulta3);
        while ($fila = mysqli_fetch_row($matriz)) {
            echo "<tbody>";
            echo "<tr>";
            echo "<td>" . $fila[0] . "</td>";
            echo "<td>" . $fila[1] . "</td>";
            echo "<td>" . $fila[2] . "</td>";
            echo "<td>" . $fila[3] . "</td>";
            echo "<td>" . $fila[4] . "</td>";
            echo "<td>" . $fila[5] . "</td>";
            echo "<td>" . $fila[6] . "</td>";
            echo "<td>" . $fila[7] . "</td>";
            echo "<td>" . $fila[8] . "</td>";
            echo "<td>" . $fila[9] . "</td>";
            echo "<td>" . $fila[10] . "</td>";
            echo "<td>" . $fila[11] . "</td>";
            echo "<td>" . $fila[12] . "</td>";
            echo "<td>" . $fila[13] . "</td>";
            echo "<td>" . $fila[14] . "</td>";
            echo "<td>" . $fila[15] . "</td>";
            echo "</tr>";
            echo "</tbody>";
        }
    } elseif ($_POST['producto'] === 'C1') {
        $matriz = mysqli_query($conexion, $consulta4);
        while ($fila = mysqli_fetch_row($matriz)) {
            echo "<tbody>";
            echo "<tr>";
            echo "<td>" . $fila[0] . "</td>";
            echo "<td>" . $fila[1] . "</td>";
            echo "<td>" . $fila[2] . "</td>";
            echo "<td>" . $fila[3] . "</td>";
            echo "<td>" . $fila[4] . "</td>";
            echo "<td>" . $fila[5] . "</td>";
            echo "<td>" . $fila[6] . "</td>";
            echo "<td>" . $fila[7] . "</td>";
            echo "<td>" . $fila[8] . "</td>";
            echo "<td>" . $fila[9] . "</td>";
            echo "<td>" . $fila[10] . "</td>";
            echo "<td>" . $fila[11] . "</td>";
            echo "<td>" . $fila[12] . "</td>";
            echo "<td>" . $fila[13] . "</td>";
            echo "<td>" . $fila[14] . "</td>";
            echo "<td>" . $fila[15] . "</td>";
            echo "</tr>";
            echo "</tbody>";
        }
    } elseif ($_POST['producto'] === 'TG') {
        $matriz = mysqli_query($conexion, $consulta5);
        while ($fila = mysqli_fetch_row($matriz)) {
            echo "<tbody>";
            echo "<tr>";
            echo "<td>" . $fila[0] . "</td>";
            echo "<td>" . $fila[1] . "</td>";
            echo "<td>" . $fila[2] . "</td>";
            echo "<td>" . $fila[3] . "</td>";
            echo "<td>" . $fila[4] . "</td>";
            echo "<td>" . $fila[5] . "</td>";
            echo "<td>" . $fila[6] . "</td>";
            echo "<td>" . $fila[7] . "</td>";
            echo "<td>" . $fila[8] . "</td>";
            echo "<td>" . $fila[9] . "</td>";
            echo "<td>" . $fila[10] . "</td>";
            echo "<td>" . $fila[11] . "</td>";
            echo "<td>" . $fila[12] . "</td>";
            echo "<td>" . $fila[13] . "</td>";
            echo "<td>" . $fila[14] . "</td>";
            echo "<td>" . $fila[15] . "</td>";
            echo "</tr>";
            echo "</tbody>";
        }
    } elseif ($_POST['producto'] === 'TODOS') {
        $matriz = mysqli_query($conexion, $consulta6);
        while ($fila = mysqli_fetch_row($matriz)) {
            echo "<tbody>";
            echo "<tr>";
            echo "<td>" . $fila[0] . "</td>";
            echo "<td>" . $fila[1] . "</td>";
            echo "<td>" . $fila[2] . "</td>";
            echo "<td>" . $fila[3] . "</td>";
            echo "<td>" . $fila[4] . "</td>";
            echo "<td>" . $fila[5] . "</td>";
            echo "<td>" . $fila[6] . "</td>";
            echo "<td>" . $fila[7] . "</td>";
            echo "<td>" . $fila[8] . "</td>";
            echo "<td>" . $fila[9] . "</td>";
            echo "<td>" . $fila[10] . "</td>";
            echo "<td>" . $fila[11] . "</td>";
            echo "<td>" . $fila[12] . "</td>";
            echo "<td>" . $fila[13] . "</td>";
            echo "<td>" . $fila[14] . "</td>";
            echo "<td>" . $fila[15] . "</td>";
            echo "</tr>";
            echo "</tbody>";
        }
    }
    echo "</table>";
}

if (isset($_POST['descargar'])) {
    if ($_POST['producto'] === 'CF') {
        if (PHP_SAPI == 'cli') {
            die('<div class="alert alert-danger" role="alert"><strong>Error!</strong> Solo se puede ejecutar desde un navegador.</div>');
        }
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setCreator("")
                ->setLastModifiedBy("")
                ->setTitle("Office 2010 XLSX Documento de Excel")
                ->setSubject("Office 2010 XLSX Documento de Excel")
                ->setDescription("Documento de Excel para Office 2010 XLSX.")
                ->setKeywords("office 2010 openxml php")
                ->setCategory("Archivo con resultado de Excel");

        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:P1');
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', 'REDIFERIDOS CF')
                ->setCellValue('A2', 'Producto')
                ->setCellValue('B2', 'Identificacion')
                ->setCellValue('C2', 'N° Credito/N° Tarjeta')
                ->setCellValue('D2', 'Tipo Cliente/ESP')
                ->setCellValue('E2', 'Capital')
                ->setCellValue('F2', 'Franja Al Rediferir')
                ->setCellValue('G2', 'Valor Cuota Fija')
                ->setCellValue('H2', 'Nueva Tasa')
                ->setCellValue('I2', 'Nueva Cuota')
                ->setCellValue('J2', 'Nuevo Plazo')
                ->setCellValue('K2', 'Fecha de Envio de Operaciones')
                ->setCellValue('L2', 'Reportado Por')
                ->setCellValue('M2', 'Ciudad')
                ->setCellValue('N2', 'N° Telefono de Contacto del Cliente al Rediferir')
                ->setCellValue('O2', 'Tipo Rediferido')
                ->setCellValue('P2', 'Caracteristica');

        $boldArray = array('font' => array('bold' => true,), 'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER));
        $objPHPExcel->getActiveSheet()->getStyle('A1:S2')->applyFromArray($boldArray);

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(34);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(23);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(22);

        $sql = "SELECT * FROM rediferidos WHERE Producto = 'CF'";
        $query = mysqli_query($conexion, $sql);
        $cel = 3;
        while ($row = mysqli_fetch_array($query)) {
            $A = $row['Producto'];
            $B = $row['Identificacion'];
            $C = $row['NroCredito_NroTarjeta'];
            $D = $row['TipoCliente_ESP'];
            $E = $row['Capital'];
            $F = $row['FranjaAlRediferir'];
            $G = $row['ValorCuotaFija'];
            $H = $row['NuevaTasa'];
            $I = $row['NuevaCuota'];
            $J = $row['NuevoPlazo'];
            $K = $row['FechaEnvioOperaciones'];
            $L = $row['ReportadoPor'];
            $M = $row['Ciudad'];
            $N = $row['NroTelefonoContactoClienteAlRediferir'];
            $O = $row['TipoRediferido'];
            $P = $row['Caracteristica'];

            $a = "A" . $cel;
            $b = "B" . $cel;
            $c = "C" . $cel;
            $d = "D" . $cel;
            $e = "E" . $cel;
            $f = "F" . $cel;
            $g = "G" . $cel;
            $h = "H" . $cel;
            $i = "I" . $cel;
            $j = "J" . $cel;
            $k = "K" . $cel;
            $l = "L" . $cel;
            $m = "M" . $cel;
            $n = "N" . $cel;
            $o = "O" . $cel;
            $p = "P" . $cel;

            $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue($a, $A)
                    ->setCellValue($b, $B)
                    ->setCellValue($c, $C)
                    ->setCellValue($d, $D)
                    ->setCellValue($e, $E)
                    ->setCellValue($f, $F)
                    ->setCellValue($g, $G)
                    ->setCellValue($h, $H)
                    ->setCellValue($i, $I)
                    ->setCellValue($j, $J)
                    ->setCellValue($k, $K)
                    ->setCellValue($l, $L)
                    ->setCellValue($m, $M)
                    ->setCellValue($n, $N)
                    ->setCellValue($o, $O)
                    ->setCellValue($p, $P);

            $cel += 1;
        }

        $rango = "A2:$p";
        $rango2 = "A3:$p";
        $styleArray = array('font' => array('name' => 'Calibri', 'size' => 12),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango)->applyFromArray($styleArray);
        $styleArray2 = array('font' => array('name' => 'Calibri', 'size' => 10),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango2)->applyFromArray($styleArray2);

        $objPHPExcel->getActiveSheet()->setTitle('Rediferidos CF');
        $objPHPExcel->setActiveSheetIndex(0);

        /* header('Content-Type: application/vnd.ms-excel');
          header('Content-Disposition: attachment;filename="reporte.xls"');
          header('Cache-Control: max-age=0');
          header('Cache-Control: max-age=1');

          header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
          header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
          header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
          header('Pragma: public'); // HTTP/1.0 */

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //$objWriter->save('php://output');
        $objWriter->save('C:\Users\gmartinez\Downloads\RediferidosCF.xlsx');
        exit;
    } elseif ($_POST['producto'] === 'CV') {
        if (PHP_SAPI == 'cli') {
            die('<div class="alert alert-danger" role="alert"><strong>Error!</strong> Solo se puede ejecutar desde un navegador.</div>');
        }
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setCreator("")
                ->setLastModifiedBy("")
                ->setTitle("Office 2010 XLSX Documento de Excel")
                ->setSubject("Office 2010 XLSX Documento de Excel")
                ->setDescription("Documento de Excel para Office 2010 XLSX.")
                ->setKeywords("office 2010 openxml php")
                ->setCategory("Archivo con resultado de Excel");

        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:P1');
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', 'REDIFERIDOS CV')
                ->setCellValue('A2', 'Producto')
                ->setCellValue('B2', 'Identificacion')
                ->setCellValue('C2', 'N° Credito/N° Tarjeta')
                ->setCellValue('D2', 'Tipo Cliente/ESP')
                ->setCellValue('E2', 'Capital')
                ->setCellValue('F2', 'Franja Al Rediferir')
                ->setCellValue('G2', 'Valor Cuota Fija')
                ->setCellValue('H2', 'Nueva Tasa')
                ->setCellValue('I2', 'Nueva Cuota')
                ->setCellValue('J2', 'Nuevo Plazo')
                ->setCellValue('K2', 'Fecha de Envio de Operaciones')
                ->setCellValue('L2', 'Reportado Por')
                ->setCellValue('M2', 'Ciudad')
                ->setCellValue('N2', 'N° Telefono de Contacto del Cliente al Rediferir')
                ->setCellValue('O2', 'Tipo Rediferido')
                ->setCellValue('P2', 'Caracteristica');

        $boldArray = array('font' => array('bold' => true,), 'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER));
        $objPHPExcel->getActiveSheet()->getStyle('A1:S2')->applyFromArray($boldArray);

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(34);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(22);

        $sql = "SELECT * FROM rediferidos WHERE Producto = 'CV'";
        $query = mysqli_query($conexion, $sql);
        $cel = 3;
        while ($row = mysqli_fetch_array($query)) {
            $A = $row['Producto'];
            $B = $row['Identificacion'];
            $C = $row['NroCredito_NroTarjeta'];
            $D = $row['TipoCliente_ESP'];
            $E = $row['Capital'];
            $F = $row['FranjaAlRediferir'];
            $G = $row['ValorCuotaFija'];
            $H = $row['NuevaTasa'];
            $I = $row['NuevaCuota'];
            $J = $row['NuevoPlazo'];
            $K = $row['FechaEnvioOperaciones'];
            $L = $row['ReportadoPor'];
            $M = $row['Ciudad'];
            $N = $row['NroTelefonoContactoClienteAlRediferir'];
            $O = $row['TipoRediferido'];
            $P = $row['Caracteristica'];

            $a = "A" . $cel;
            $b = "B" . $cel;
            $c = "C" . $cel;
            $d = "D" . $cel;
            $e = "E" . $cel;
            $f = "F" . $cel;
            $g = "G" . $cel;
            $h = "H" . $cel;
            $i = "I" . $cel;
            $j = "J" . $cel;
            $k = "K" . $cel;
            $l = "L" . $cel;
            $m = "M" . $cel;
            $n = "N" . $cel;
            $o = "O" . $cel;
            $p = "P" . $cel;

            $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue($a, $A)
                    ->setCellValue($b, $B)
                    ->setCellValue($c, $C)
                    ->setCellValue($d, $D)
                    ->setCellValue($e, $E)
                    ->setCellValue($f, $F)
                    ->setCellValue($g, $G)
                    ->setCellValue($h, $H)
                    ->setCellValue($i, $I)
                    ->setCellValue($j, $J)
                    ->setCellValue($k, $K)
                    ->setCellValue($l, $L)
                    ->setCellValue($m, $M)
                    ->setCellValue($n, $N)
                    ->setCellValue($o, $O)
                    ->setCellValue($p, $P);

            $cel += 1;
        }

        $rango = "A2:$p";
        $rango2 = "A3:$p";
        $styleArray = array('font' => array('name' => 'Calibri', 'size' => 12),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango)->applyFromArray($styleArray);
        $styleArray2 = array('font' => array('name' => 'Calibri', 'size' => 10),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango2)->applyFromArray($styleArray2);

        $objPHPExcel->getActiveSheet()->setTitle('Rediferidos CV');
        $objPHPExcel->setActiveSheetIndex(0);

        /* header('Content-Type: application/vnd.ms-excel');
          header('Content-Disposition: attachment;filename="reporte.xls"');
          header('Cache-Control: max-age=0');
          header('Cache-Control: max-age=1');

          header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
          header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
          header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
          header('Pragma: public'); // HTTP/1.0 */

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //$objWriter->save('php://output');
        $objWriter->save('C:\Users\gmartinez\Downloads\RediferidosCV.xlsx');
        exit;
    } elseif ($_POST['producto'] === 'CP') {
        if (PHP_SAPI == 'cli') {
            die('<div class="alert alert-danger" role="alert"><strong>Error!</strong> Solo se puede ejecutar desde un navegador.</div>');
        }
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setCreator("")
                ->setLastModifiedBy("")
                ->setTitle("Office 2010 XLSX Documento de Excel")
                ->setSubject("Office 2010 XLSX Documento de Excel")
                ->setDescription("Documento de Excel para Office 2010 XLSX.")
                ->setKeywords("office 2010 openxml php")
                ->setCategory("Archivo con resultado de Excel");

        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:P1');
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', 'REDIFERIDOS CP')
                ->setCellValue('A2', 'Producto')
                ->setCellValue('B2', 'Identificacion')
                ->setCellValue('C2', 'N° Credito/N° Tarjeta')
                ->setCellValue('D2', 'Tipo Cliente/ESP')
                ->setCellValue('E2', 'Capital')
                ->setCellValue('F2', 'Franja Al Rediferir')
                ->setCellValue('G2', 'Valor Cuota Fija')
                ->setCellValue('H2', 'Nueva Tasa')
                ->setCellValue('I2', 'Nueva Cuota')
                ->setCellValue('J2', 'Nuevo Plazo')
                ->setCellValue('K2', 'Fecha de Envio de Operaciones')
                ->setCellValue('L2', 'Reportado Por')
                ->setCellValue('M2', 'Ciudad')
                ->setCellValue('N2', 'N° Telefono de Contacto del Cliente al Rediferir')
                ->setCellValue('O2', 'Tipo Rediferido')
                ->setCellValue('P2', 'Caracteristica');

        $boldArray = array('font' => array('bold' => true,), 'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER));
        $objPHPExcel->getActiveSheet()->getStyle('A1:S2')->applyFromArray($boldArray);

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(34);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(22);

        $sql = "SELECT * FROM rediferidos WHERE Producto = 'CP'";
        $query = mysqli_query($conexion, $sql);
        $cel = 3;
        while ($row = mysqli_fetch_array($query)) {
            $A = $row['Producto'];
            $B = $row['Identificacion'];
            $C = $row['NroCredito_NroTarjeta'];
            $D = $row['TipoCliente_ESP'];
            $E = $row['Capital'];
            $F = $row['FranjaAlRediferir'];
            $G = $row['ValorCuotaFija'];
            $H = $row['NuevaTasa'];
            $I = $row['NuevaCuota'];
            $J = $row['NuevoPlazo'];
            $K = $row['FechaEnvioOperaciones'];
            $L = $row['ReportadoPor'];
            $M = $row['Ciudad'];
            $N = $row['NroTelefonoContactoClienteAlRediferir'];
            $O = $row['TipoRediferido'];
            $P = $row['Caracteristica'];

            $a = "A" . $cel;
            $b = "B" . $cel;
            $c = "C" . $cel;
            $d = "D" . $cel;
            $e = "E" . $cel;
            $f = "F" . $cel;
            $g = "G" . $cel;
            $h = "H" . $cel;
            $i = "I" . $cel;
            $j = "J" . $cel;
            $k = "K" . $cel;
            $l = "L" . $cel;
            $m = "M" . $cel;
            $n = "N" . $cel;
            $o = "O" . $cel;
            $p = "P" . $cel;

            $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue($a, $A)
                    ->setCellValue($b, $B)
                    ->setCellValue($c, $C)
                    ->setCellValue($d, $D)
                    ->setCellValue($e, $E)
                    ->setCellValue($f, $F)
                    ->setCellValue($g, $G)
                    ->setCellValue($h, $H)
                    ->setCellValue($i, $I)
                    ->setCellValue($j, $J)
                    ->setCellValue($k, $K)
                    ->setCellValue($l, $L)
                    ->setCellValue($m, $M)
                    ->setCellValue($n, $N)
                    ->setCellValue($o, $O)
                    ->setCellValue($p, $P);

            $cel += 1;
        }

        $rango = "A2:$p";
        $rango2 = "A3:$p";
        $styleArray = array('font' => array('name' => 'Calibri', 'size' => 12),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango)->applyFromArray($styleArray);
        $styleArray2 = array('font' => array('name' => 'Calibri', 'size' => 10),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango2)->applyFromArray($styleArray2);

        $objPHPExcel->getActiveSheet()->setTitle('Rediferidos CP');
        $objPHPExcel->setActiveSheetIndex(0);

        /* header('Content-Type: application/vnd.ms-excel');
          header('Content-Disposition: attachment;filename="reporte.xls"');
          header('Cache-Control: max-age=0');
          header('Cache-Control: max-age=1');

          header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
          header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
          header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
          header('Pragma: public'); // HTTP/1.0 */

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //$objWriter->save('php://output');
        $objWriter->save('C:\Users\gmartinez\Downloads\RediferidosCP.xlsx');
        exit;
    } elseif ($_POST['producto'] === 'C1') {
        if (PHP_SAPI == 'cli') {
            die('<div class="alert alert-danger" role="alert"><strong>Error!</strong> Solo se puede ejecutar desde un navegador.</div>');
        }
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setCreator("")
                ->setLastModifiedBy("")
                ->setTitle("Office 2010 XLSX Documento de Excel")
                ->setSubject("Office 2010 XLSX Documento de Excel")
                ->setDescription("Documento de Excel para Office 2010 XLSX.")
                ->setKeywords("office 2010 openxml php")
                ->setCategory("Archivo con resultado de Excel");

        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:P1');
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', 'REDIFERIDOS C1')
                ->setCellValue('A2', 'Producto')
                ->setCellValue('B2', 'Identificacion')
                ->setCellValue('C2', 'N° Credito/N° Tarjeta')
                ->setCellValue('D2', 'Tipo Cliente/ESP')
                ->setCellValue('E2', 'Capital')
                ->setCellValue('F2', 'Franja Al Rediferir')
                ->setCellValue('G2', 'Valor Cuota Fija')
                ->setCellValue('H2', 'Nueva Tasa')
                ->setCellValue('I2', 'Nueva Cuota')
                ->setCellValue('J2', 'Nuevo Plazo')
                ->setCellValue('K2', 'Fecha de Envio de Operaciones')
                ->setCellValue('L2', 'Reportado Por')
                ->setCellValue('M2', 'Ciudad')
                ->setCellValue('N2', 'N° Telefono de Contacto del Cliente al Rediferir')
                ->setCellValue('O2', 'Tipo Rediferido')
                ->setCellValue('P2', 'Caracteristica');

        $boldArray = array('font' => array('bold' => true,), 'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER));
        $objPHPExcel->getActiveSheet()->getStyle('A1:S2')->applyFromArray($boldArray);

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(34);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(22);

        $sql = "SELECT * FROM rediferidos WHERE Producto = 'C1'";
        $query = mysqli_query($conexion, $sql);
        $cel = 3;
        while ($row = mysqli_fetch_array($query)) {
            $A = $row['Producto'];
            $B = $row['Identificacion'];
            $C = $row['NroCredito_NroTarjeta'];
            $D = $row['TipoCliente_ESP'];
            $E = $row['Capital'];
            $F = $row['FranjaAlRediferir'];
            $G = $row['ValorCuotaFija'];
            $H = $row['NuevaTasa'];
            $I = $row['NuevaCuota'];
            $J = $row['NuevoPlazo'];
            $K = $row['FechaEnvioOperaciones'];
            $L = $row['ReportadoPor'];
            $M = $row['Ciudad'];
            $N = $row['NroTelefonoContactoClienteAlRediferir'];
            $O = $row['TipoRediferido'];
            $P = $row['Caracteristica'];

            $a = "A" . $cel;
            $b = "B" . $cel;
            $c = "C" . $cel;
            $d = "D" . $cel;
            $e = "E" . $cel;
            $f = "F" . $cel;
            $g = "G" . $cel;
            $h = "H" . $cel;
            $i = "I" . $cel;
            $j = "J" . $cel;
            $k = "K" . $cel;
            $l = "L" . $cel;
            $m = "M" . $cel;
            $n = "N" . $cel;
            $o = "O" . $cel;
            $p = "P" . $cel;

            $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue($a, $A)
                    ->setCellValue($b, $B)
                    ->setCellValue($c, $C)
                    ->setCellValue($d, $D)
                    ->setCellValue($e, $E)
                    ->setCellValue($f, $F)
                    ->setCellValue($g, $G)
                    ->setCellValue($h, $H)
                    ->setCellValue($i, $I)
                    ->setCellValue($j, $J)
                    ->setCellValue($k, $K)
                    ->setCellValue($l, $L)
                    ->setCellValue($m, $M)
                    ->setCellValue($n, $N)
                    ->setCellValue($o, $O)
                    ->setCellValue($p, $P);

            $cel += 1;
        }

        $rango = "A2:$p";
        $rango2 = "A3:$p";
        $styleArray = array('font' => array('name' => 'Calibri', 'size' => 12),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango)->applyFromArray($styleArray);
        $styleArray2 = array('font' => array('name' => 'Calibri', 'size' => 10),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango2)->applyFromArray($styleArray2);

        $objPHPExcel->getActiveSheet()->setTitle('Rediferidos C1');
        $objPHPExcel->setActiveSheetIndex(0);

        /* header('Content-Type: application/vnd.ms-excel');
          header('Content-Disposition: attachment;filename="reporte.xls"');
          header('Cache-Control: max-age=0');
          header('Cache-Control: max-age=1');

          header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
          header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
          header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
          header('Pragma: public'); // HTTP/1.0 */

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //$objWriter->save('php://output');
        $objWriter->save('C:\Users\gmartinez\Downloads\RediferidosC1.xlsx');
        exit;
    } elseif ($_POST['producto'] === 'TG') {
        if (PHP_SAPI == 'cli') {
            die('<div class="alert alert-danger" role="alert"><strong>Error!</strong> Solo se puede ejecutar desde un navegador.</div>');
        }
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setCreator("")
                ->setLastModifiedBy("")
                ->setTitle("Office 2010 XLSX Documento de Excel")
                ->setSubject("Office 2010 XLSX Documento de Excel")
                ->setDescription("Documento de Excel para Office 2010 XLSX.")
                ->setKeywords("office 2010 openxml php")
                ->setCategory("Archivo con resultado de Excel");

        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:P1');
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', 'REDIFERIDOS TG')
                ->setCellValue('A2', 'Producto')
                ->setCellValue('B2', 'Identificacion')
                ->setCellValue('C2', 'N° Credito/N° Tarjeta')
                ->setCellValue('D2', 'Tipo Cliente/ESP')
                ->setCellValue('E2', 'Capital')
                ->setCellValue('F2', 'Franja Al Rediferir')
                ->setCellValue('G2', 'Valor Cuota Fija')
                ->setCellValue('H2', 'Nueva Tasa')
                ->setCellValue('I2', 'Nueva Cuota')
                ->setCellValue('J2', 'Nuevo Plazo')
                ->setCellValue('K2', 'Fecha de Envio de Operaciones')
                ->setCellValue('L2', 'Reportado Por')
                ->setCellValue('M2', 'Ciudad')
                ->setCellValue('N2', 'N° Telefono de Contacto del Cliente al Rediferir')
                ->setCellValue('O2', 'Tipo Rediferido')
                ->setCellValue('P2', 'Caracteristica');

        $boldArray = array('font' => array('bold' => true,), 'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER));
        $objPHPExcel->getActiveSheet()->getStyle('A1:S2')->applyFromArray($boldArray);

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(34);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(22);

        $sql = "SELECT * FROM rediferidos WHERE Producto = 'TG'";
        $query = mysqli_query($conexion, $sql);
        $cel = 3;
        while ($row = mysqli_fetch_array($query)) {
            $A = $row['Producto'];
            $B = $row['Identificacion'];
            $C = $row['NroCredito_NroTarjeta'];
            $D = $row['TipoCliente_ESP'];
            $E = $row['Capital'];
            $F = $row['FranjaAlRediferir'];
            $G = $row['ValorCuotaFija'];
            $H = $row['NuevaTasa'];
            $I = $row['NuevaCuota'];
            $J = $row['NuevoPlazo'];
            $K = $row['FechaEnvioOperaciones'];
            $L = $row['ReportadoPor'];
            $M = $row['Ciudad'];
            $N = $row['NroTelefonoContactoClienteAlRediferir'];
            $O = $row['TipoRediferido'];
            $P = $row['Caracteristica'];

            $a = "A" . $cel;
            $b = "B" . $cel;
            $c = "C" . $cel;
            $d = "D" . $cel;
            $e = "E" . $cel;
            $f = "F" . $cel;
            $g = "G" . $cel;
            $h = "H" . $cel;
            $i = "I" . $cel;
            $j = "J" . $cel;
            $k = "K" . $cel;
            $l = "L" . $cel;
            $m = "M" . $cel;
            $n = "N" . $cel;
            $o = "O" . $cel;
            $p = "P" . $cel;

            $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue($a, $A)
                    ->setCellValue($b, $B)
                    ->setCellValue($c, $C)
                    ->setCellValue($d, $D)
                    ->setCellValue($e, $E)
                    ->setCellValue($f, $F)
                    ->setCellValue($g, $G)
                    ->setCellValue($h, $H)
                    ->setCellValue($i, $I)
                    ->setCellValue($j, $J)
                    ->setCellValue($k, $K)
                    ->setCellValue($l, $L)
                    ->setCellValue($m, $M)
                    ->setCellValue($n, $N)
                    ->setCellValue($o, $O)
                    ->setCellValue($p, $P);

            $cel += 1;
        }

        $rango = "A2:$p";
        $rango2 = "A3:$p";
        $styleArray = array('font' => array('name' => 'Calibri', 'size' => 12),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango)->applyFromArray($styleArray);
        $styleArray2 = array('font' => array('name' => 'Calibri', 'size' => 10),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango2)->applyFromArray($styleArray2);

        $objPHPExcel->getActiveSheet()->setTitle('Rediferidos TG');
        $objPHPExcel->setActiveSheetIndex(0);

        /* header('Content-Type: application/vnd.ms-excel');
          header('Content-Disposition: attachment;filename="reporte.xls"');
          header('Cache-Control: max-age=0');
          header('Cache-Control: max-age=1');

          header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
          header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
          header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
          header('Pragma: public'); // HTTP/1.0 */

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //$objWriter->save('php://output');
        $objWriter->save('C:\Users\gmartinez\Downloads\RediferidosTG.xlsx');
        exit;
    } elseif ($_POST['producto'] === 'TODOS') {
        if (PHP_SAPI == 'cli') {
            die('<div class="alert alert-danger" role="alert"><strong>Error!</strong> Solo se puede ejecutar desde un navegador.</div>');
        }
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setCreator("")
                ->setLastModifiedBy("")
                ->setTitle("Office 2010 XLSX Documento de Excel")
                ->setSubject("Office 2010 XLSX Documento de Excel")
                ->setDescription("Documento de Excel para Office 2010 XLSX.")
                ->setKeywords("office 2010 openxml php")
                ->setCategory("Archivo con resultado de Excel");

        $objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:P1');
        $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', 'REDIFERIDOS')
                ->setCellValue('A2', 'Producto')
                ->setCellValue('B2', 'Identificacion')
                ->setCellValue('C2', 'N° Credito/N° Tarjeta')
                ->setCellValue('D2', 'Tipo Cliente/ESP')
                ->setCellValue('E2', 'Capital')
                ->setCellValue('F2', 'Franja Al Rediferir')
                ->setCellValue('G2', 'Valor Cuota Fija')
                ->setCellValue('H2', 'Nueva Tasa')
                ->setCellValue('I2', 'Nueva Cuota')
                ->setCellValue('J2', 'Nuevo Plazo')
                ->setCellValue('K2', 'Fecha de Envio de Operaciones')
                ->setCellValue('L2', 'Reportado Por')
                ->setCellValue('M2', 'Ciudad')
                ->setCellValue('N2', 'N° Telefono de Contacto del Cliente al Rediferir')
                ->setCellValue('O2', 'Tipo Rediferido')
                ->setCellValue('P2', 'Caracteristica');

        $boldArray = array('font' => array('bold' => true,), 'alignment' => array('horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER));
        $objPHPExcel->getActiveSheet()->getStyle('A1:S2')->applyFromArray($boldArray);

        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
        $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(34);
        $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(50);
        $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(22);
        $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(22);

        $sql = "SELECT * FROM rediferidos";
        $query = mysqli_query($conexion, $sql);
        $cel = 3;
        while ($row = mysqli_fetch_array($query)) {
            $A = $row['Producto'];
            $B = $row['Identificacion'];
            $C = $row['NroCredito_NroTarjeta'];
            $D = $row['TipoCliente_ESP'];
            $E = $row['Capital'];
            $F = $row['FranjaAlRediferir'];
            $G = $row['ValorCuotaFija'];
            $H = $row['NuevaTasa'];
            $I = $row['NuevaCuota'];
            $J = $row['NuevoPlazo'];
            $K = $row['FechaEnvioOperaciones'];
            $L = $row['ReportadoPor'];
            $M = $row['Ciudad'];
            $N = $row['NroTelefonoContactoClienteAlRediferir'];
            $O = $row['TipoRediferido'];
            $P = $row['Caracteristica'];

            $a = "A" . $cel;
            $b = "B" . $cel;
            $c = "C" . $cel;
            $d = "D" . $cel;
            $e = "E" . $cel;
            $f = "F" . $cel;
            $g = "G" . $cel;
            $h = "H" . $cel;
            $i = "I" . $cel;
            $j = "J" . $cel;
            $k = "K" . $cel;
            $l = "L" . $cel;
            $m = "M" . $cel;
            $n = "N" . $cel;
            $o = "O" . $cel;
            $p = "P" . $cel;

            $objPHPExcel->setActiveSheetIndex(0)
                    ->setCellValue($a, $A)
                    ->setCellValue($b, $B)
                    ->setCellValue($c, $C)
                    ->setCellValue($d, $D)
                    ->setCellValue($e, $E)
                    ->setCellValue($f, $F)
                    ->setCellValue($g, $G)
                    ->setCellValue($h, $H)
                    ->setCellValue($i, $I)
                    ->setCellValue($j, $J)
                    ->setCellValue($k, $K)
                    ->setCellValue($l, $L)
                    ->setCellValue($m, $M)
                    ->setCellValue($n, $N)
                    ->setCellValue($o, $O)
                    ->setCellValue($p, $P);

            $cel += 1;
        }

        $rango = "A2:$p";
        $rango2 = "A3:$p";
        $styleArray = array('font' => array('name' => 'Calibri', 'size' => 12),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango)->applyFromArray($styleArray);
        $styleArray2 = array('font' => array('name' => 'Calibri', 'size' => 10),
            'borders' => array('allborders' => array('style' => PHPExcel_Style_Border::BORDER_THIN, 'color' => array('argb' => '000'))));
        $objPHPExcel->getActiveSheet()->getStyle($rango2)->applyFromArray($styleArray2);

        $objPHPExcel->getActiveSheet()->setTitle('Rediferidos');
        $objPHPExcel->setActiveSheetIndex(0);

        /* header('Content-Type: application/vnd.ms-excel');
          header('Content-Disposition: attachment;filename="reporte.xls"');
          header('Cache-Control: max-age=0');
          header('Cache-Control: max-age=1');

          header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
          header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
          header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
          header('Pragma: public'); // HTTP/1.0 */

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        //$objWriter->save('php://output');
        $objWriter->save('C:\Users\gmartinez\Downloads\Rediferidos.xlsx');
        exit;
    }
}