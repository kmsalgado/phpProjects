<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>

	<form method="post" class="" id="" action="login.php">
		<label for="correo">correo</label>
		<br>
		<input type="email" name="correo" value="" placeholder="correo"/>
		<br>
		<br>
		<label for="clave">clave</label>
		<br>
		<input type="password" name="clave" value="" placeholder="clave"/>
		<br>
		<br>
		<button type="btn" id="" value="" name="enviar">enviar</button>
		<br>
		<br>
	</form>

	<?php 

		require ("datosconeccion.php");//para enlasar con los datos iniciales de datosconeccion.php

		$conexion=mysqli_connect($hostBD,$usuarioBD,$contrasenaBD,$nombreBD);//esto es para hacer la coneccion con la base de datos

		$consulta1=("select correo from DATOSINGRESO");
		$consulta2=("select contrasena from DATOSINGRESO");
		$consulta3=("select user from DATOSINGRESO");

		if (mysqli_connect_errno()) {//esto es para verificar la coneccion con la base de datos
			echo "no se pudo conectar"."<br>";
		}else{
			echo "coneccion exitosa"."<br>";
		}

		$matrizresultado=mysqli_query($conexion,$consulta1);//esto es para hacer una matriz con la consulta
		$matrizresultado2=mysqli_query($conexion,$consulta2);
		$matrizresultado3=mysqli_query($conexion,$consulta3);

		//$fila=mysqli_fetch_row($matrizresultado);

		//echo $fila[0];

		while($fila=mysqli_fetch_row($matrizresultado)){//esto es para recorre la matriz y buscar el correo
			//echo $fila[0] . " ";
			//echo $fila[1] . " ";
			//echo $fila[2] . " ";
			$user[]=$fila[0];
			//echo "<br>";
		}

		while($fila=mysqli_fetch_row($matrizresultado2)){//esto es para recorre la matriz y buscar el pass
			$pas[]=$fila[0];
		}
		while($fila=mysqli_fetch_row($matrizresultado3)){//esto es para recorre la matriz y buscar el tipo de usuario
			$tipouser[]=$fila[0];
		}


		mysqli_close($conexion);//esto es para cerrar la coneccion con la base de datos



		

		if (isset($_POST["enviar"])) {
			for ($i=0; $i < count($user); $i++) { //el count es para ir hasta el ultimo reguistro que halla
				if ($_POST["correo"]==$user[$i] && $pas[$i]==$_POST["clave"] && $tipouser[$i]=="admin") {
					header ('location: CotizacionAdmin.php');
				} elseif($_POST["correo"]==$user[$i] && $pas[$i]==$_POST["clave"] && $tipouser[$i]=="normal"){
						header ('location: Cotizacion.php');
					}
				}
			}				
		
	 ?>
</body>
</html>