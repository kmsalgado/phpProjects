
	<?php 

	$hostBD="localhost";
	$nombreBD="usuarios";
	$usuarioBD="yesid";
	$contrasenaBD="8723610gomitox";

	 ?>
