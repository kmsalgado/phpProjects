-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.1.29-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win32
-- HeidiSQL Versión:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para unificada
CREATE DATABASE IF NOT EXISTS `unificada` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `unificada`;

-- Volcando estructura para tabla unificada.# de gestiones
CREATE TABLE IF NOT EXISTS `# de gestiones` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `# Gestiones` bigint(21) NOT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.# de gestiones: ~0 rows (aproximadamente)
DELETE FROM `# de gestiones`;
/*!40000 ALTER TABLE `# de gestiones` DISABLE KEYS */;
/*!40000 ALTER TABLE `# de gestiones` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.180
CREATE TABLE IF NOT EXISTS `180` (
  `Identificacion` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.180: ~0 rows (aproximadamente)
DELETE FROM `180`;
/*!40000 ALTER TABLE `180` DISABLE KEYS */;
/*!40000 ALTER TABLE `180` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.actualiza asesores
CREATE TABLE IF NOT EXISTS `actualiza asesores` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Pagare` varchar(255) DEFAULT NULL,
  `Cedula Ejecutivo` varchar(255) DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `Segmento` varchar(255) DEFAULT NULL,
  `Asignacion` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.actualiza asesores: ~0 rows (aproximadamente)
DELETE FROM `actualiza asesores`;
/*!40000 ALTER TABLE `actualiza asesores` DISABLE KEYS */;
/*!40000 ALTER TABLE `actualiza asesores` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.asignacion
CREATE TABLE IF NOT EXISTS `asignacion` (
  `Pagare` varchar(50) DEFAULT NULL,
  `NumeroCredito` double DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `CasadeCobro` varchar(255) DEFAULT NULL,
  `Ejecutivo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.asignacion: ~0 rows (aproximadamente)
DELETE FROM `asignacion`;
/*!40000 ALTER TABLE `asignacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `asignacion` ENABLE KEYS */;

-- Volcando estructura para procedimiento unificada.CalculaMejorGestionExterna
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculaMejorGestionExterna`()
BEGIN

-- 100 Anexa Gestion Externa --

INSERT INTO `gestion externa` ( `FechaReporte`, `FechaLlamada`, `HoraGestionInicial`, `HoraGestionFinal`, `Identificacion`, 
`NroProductoCredito`, `NumeroMarcado`, `Tipificacion`, `RazonMora`, `Gestion`, `Franja`, `FechaDePromesa`, `ValorPromesa`, `Asesor`, 
`MesAsignado`, `Agencia`, `Producto`, `TipoGestion`) SELECT `Fecha Reporte`, `Fecha Llamada`, `Hora Gestion Inicial`, 
`Hora Gestion Final`, `Identificacion`, `Nro ProductoCredito`, `Numero Marcado`, `Tipificacion`, `Razon Mora`, `Gestion`, `Franja`, 
`Fecha de Promesa`, `Valor Promesa`, `Asesor`, `Mes Asignado`, `Agencia`, `Producto`, "EXTERNA" AS `Tipo Gestion`
FROM `gestion casa ext`;

END//
DELIMITER ;

-- Volcando estructura para procedimiento unificada.CalculaMejorGestionInterna
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `CalculaMejorGestionInterna`()
BEGIN

-- 00 Gestion Por Fecha1

DROP TEMPORARY TABLE IF EXISTS `00 gestion por fecha1`;
CREATE TEMPORARY TABLE `00 gestion por fecha1` AS(SELECT `cmc`.`Fecha Gestion`, Left("Fecha",2) AS `Dia`, 
DATE_FORMAT(`Fecha Gestion`, '%Y-%m-%d') AS `Fecha`, DATE_FORMAT(`Fecha Gestion`,'%H:%i:%s') AS `Hora`, `cmc`.`Usuario`, `cmc`.`Station`, 
`cmc`.`Producto`, `p`.`Producto_1`, `cmc`.`Asesor Asignado`, `cmc`.`Identificacion`, `cmc`.`NUM_Obligacion`, 
CONCAT_WS("_",`NUM_Obligacion`, `Identificacion`) AS `Llave SL`, `cmc`.`Numero Poliza`, `cmc`.`Campana`, `cmc`.`Placa`, `cmc`.`Grupo`, 
`cmc`.`Corte`, `cmc`.`TIP Codigo_Accion`, `cmc`.`TIP Tipo_Contacto`, `cmc`.`TIP ResultadoContacto`, `cmc`.`TIP Razon_Mora`, 
`cmc`.`TIP Detalle_Gestion`, `cmc`.`Fecha Promesa` AS `Fecha_Promesa`, `cmc`.`Valor Acuerdo`, `cmc`.`Medio Pago`, `cmc`.`PAG NCuotas`, 
`cmc`.`Valor Total`, `cmc`.`PAG Fecha PrimerPago`, `cmc`.`Telefono Contacto`, `cmc`.`ACT Direccion`, `cmc`.`ACT Ciudad`, 
`cmc`.`ACT Depto`, `cmc`.`ACT Celular`, `cmc`.`ACT Telefono`, `cmc`.`ACT Email`, `cmc`.`Fecha Visita`, `cmc`.`NUM NIE Comprometido`, 
`cmc`.`Nombre Tercero`, `cmc`.`Parentesco Tercero`, `cmc`.`Departamento Tercero`, `cmc`.`Ciudad Tercero`, `cmc`.`TelFijo Tercero`, 
`cmc`.`Celular Tercero` FROM `cmc reporte historico gestion` AS `cmc` LEFT JOIN `prod` AS `p` ON `cmc`.PRODUCTO = `p`.PRODUCTO);

-- 00 Gestion Por Fecha --

DROP TEMPORARY TABLE IF EXISTS `00 gestion por fecha`;
CREATE TEMPORARY TABLE `00 gestion por fecha` AS(SELECT `Fecha Gestion`, `Dia`, `Fecha`, `Hora`, `Usuario`, `Station`, `Producto`, 
`Producto_1`, `Asesor Asignado`, `Identificacion`, `NUM_Obligacion`, 
IF(`Producto_1`="CP", Right(CONCAT("0000000000000000000000000000", `Numero Poliza`),17), 
Right(CONCAT("0000000000000000000000000000000000", `NUM_Obligacion`),17)) AS `Credito`, `Llave SL`, `Numero Poliza`, `Campana`, 
`Placa`, `Grupo`, `Corte`, `TIP Codigo_Accion`, `TIP Tipo_Contacto`, `TIP ResultadoContacto`, `TIP Razon_Mora`, `TIP Detalle_Gestion`, 
`Fecha_Promesa`, `Valor Acuerdo`, `Medio Pago`, `PAG NCuotas`, `Valor Total`, `PAG Fecha PrimerPago`, `Telefono Contacto`, 
`ACT Direccion`, `ACT Ciudad`, `ACT Depto`, `ACT Celular`, `ACT Telefono`, `ACT Email`, `Fecha Visita`, `NUM NIE Comprometido`, 
`Nombre Tercero`, `Parentesco Tercero`, `Departamento Tercero`, `Ciudad Tercero`, `TelFijo Tercero`, `Celular Tercero`
FROM `00 gestion por fecha1`);

-- 101 Anexa Mejor Gestion Interna

INSERT INTO `gestion interna` ( `FechaLlamada`, `HoraGestionFinal`, `Identificacion`, `Credito`, `NumeroMarcado`, `Tipificacion`, 
`RazonMora`, `Gestion`, `FechaDePromesa`, `ValorPromesa`, `Asesor`, `Producto`, `TipoGestion`) SELECT `Fecha`, `Hora`, `Identificacion`
, `Credito`, `Telefono Contacto`, `TIP ResultadoContacto`, `TIP Razon_Mora`, `TIP Detalle_Gestion`, `Fecha_Promesa`, `Valor Acuerdo`, 
`Usuario`, `Producto_1`, "INTERNA" AS `Tipo Gestion`
FROM `00 gestion por fecha`;

END//
DELIMITER ;

-- Volcando estructura para tabla unificada.casas
CREATE TABLE IF NOT EXISTS `casas` (
  `Casa de Cobro` varchar(255) DEFAULT NULL,
  `Mejor Tipificacion Final` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.casas: ~0 rows (aproximadamente)
DELETE FROM `casas`;
/*!40000 ALTER TABLE `casas` DISABLE KEYS */;
/*!40000 ALTER TABLE `casas` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.casos
CREATE TABLE IF NOT EXISTS `casos` (
  `Mes` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `CreditoSL` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Pagare` varchar(255) DEFAULT NULL,
  `Tarjeta` varchar(255) DEFAULT NULL,
  `FechaDesembolso` date DEFAULT NULL,
  `DiaDeFacturacion` int(11) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `Segmento` varchar(255) DEFAULT NULL,
  `CasaDeCobro` varchar(255) DEFAULT NULL,
  `Ejecutivo` varchar(255) DEFAULT NULL,
  `ValorCuota` double DEFAULT NULL,
  `SaldoCapital` double DEFAULT NULL,
  `CapitalEnMillones` varchar(255) DEFAULT NULL,
  `FranjaMora` varchar(255) DEFAULT NULL,
  `FranjaDelta` varchar(255) DEFAULT NULL,
  `FranjaDeltaBrujula` varchar(255) DEFAULT NULL,
  `DiasMoraHoy` int(11) DEFAULT NULL,
  `FechaUltimoPago` date DEFAULT NULL,
  `ValorRecaudo` double DEFAULT NULL,
  `TipoAplicado` varchar(255) DEFAULT NULL,
  `FechaPagoEfecty` date DEFAULT NULL,
  `ValorRecaudoEfecty` double DEFAULT NULL,
  `ValorRecaudoTotal` double DEFAULT NULL,
  `DiasMoraProy` int(11) DEFAULT NULL,
  `EstadoDelta` varchar(255) DEFAULT NULL,
  `Prioridad` varchar(255) DEFAULT NULL,
  `BloqueoU` varchar(255) DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `ConvenioHomologadoCorto` varchar(255) DEFAULT NULL,
  `ESP` varchar(255) DEFAULT NULL,
  `Medio` varchar(255) DEFAULT NULL,
  `Tipificacion` varchar(255) DEFAULT NULL,
  `Caso` varchar(255) DEFAULT NULL,
  `FechaAsesor` date DEFAULT NULL,
  `FechaEnvio` date DEFAULT NULL,
  `FechaDia` date DEFAULT NULL,
  `DiasDeEnvio` varchar(255) DEFAULT NULL,
  `Rango` varchar(255) DEFAULT NULL,
  `EscaladoA` varchar(255) DEFAULT NULL,
  `Solucion` varchar(255) DEFAULT NULL,
  `Validacion` varchar(255) DEFAULT NULL,
  `NumPQR` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.casos: ~0 rows (aproximadamente)
DELETE FROM `casos`;
/*!40000 ALTER TABLE `casos` DISABLE KEYS */;
/*!40000 ALTER TABLE `casos` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.ciclos
CREATE TABLE IF NOT EXISTS `ciclos` (
  `CicloFacturacionCore` varchar(50) DEFAULT NULL,
  `FechaLimDePago` varchar(50) DEFAULT NULL,
  `DiaFacturacion` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.ciclos: ~0 rows (aproximadamente)
DELETE FROM `ciclos`;
/*!40000 ALTER TABLE `ciclos` DISABLE KEYS */;
/*!40000 ALTER TABLE `ciclos` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.cmc reporte historico gestion
CREATE TABLE IF NOT EXISTS `cmc reporte historico gestion` (
  `Login` double DEFAULT NULL,
  `Fecha Gestion` datetime DEFAULT NULL,
  `Usuario` varchar(255) DEFAULT NULL,
  `Station` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Asesor Asignado` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NUM_Obligacion` varchar(255) DEFAULT NULL,
  `Numero Poliza` varchar(255) DEFAULT NULL,
  `Campana` varchar(255) DEFAULT NULL,
  `Placa` varchar(255) DEFAULT NULL,
  `Grupo` varchar(255) DEFAULT NULL,
  `Corte` double DEFAULT NULL,
  `TIP Codigo_Accion` varchar(255) DEFAULT NULL,
  `TIP Tipo_Contacto` varchar(255) DEFAULT NULL,
  `TIP ResultadoContacto` varchar(255) DEFAULT NULL,
  `Tipo Razon` varchar(255) DEFAULT NULL,
  `TIP Razon_Mora` varchar(255) DEFAULT NULL,
  `TIP Detalle_Gestion` varchar(255) DEFAULT NULL,
  `Fecha Promesa` date DEFAULT NULL,
  `Valor Acuerdo` varchar(255) DEFAULT NULL,
  `Medio Pago` varchar(255) DEFAULT NULL,
  `PAG NCuotas` varchar(255) DEFAULT NULL,
  `Valor Total` varchar(255) DEFAULT NULL,
  `PAG Fecha PrimerPago` varchar(255) DEFAULT NULL,
  `Telefono Contacto` varchar(255) DEFAULT NULL,
  `ACT Direccion` varchar(255) DEFAULT NULL,
  `ACT Ciudad` varchar(255) DEFAULT NULL,
  `ACT Depto` varchar(255) DEFAULT NULL,
  `ACT Celular` varchar(255) DEFAULT NULL,
  `ACT Telefono` varchar(255) DEFAULT NULL,
  `ACT Email` varchar(255) DEFAULT NULL,
  `Fecha Visita` varchar(255) DEFAULT NULL,
  `NUM NIE Comprometido` varchar(255) DEFAULT NULL,
  `Nombre Tercero` varchar(255) DEFAULT NULL,
  `Parentesco Tercero` varchar(255) DEFAULT NULL,
  `Departamento Tercero` varchar(255) DEFAULT NULL,
  `Ciudad Tercero` varchar(255) DEFAULT NULL,
  `TelFijo Tercero` varchar(255) DEFAULT NULL,
  `Celular Tercero` varchar(255) DEFAULT NULL,
  `Ocupacion` varchar(255) DEFAULT NULL,
  `DESC Ocupacion` varchar(255) DEFAULT NULL,
  `Plazo` double DEFAULT NULL,
  `Tasa` double DEFAULT NULL,
  `Cuota` double DEFAULT NULL,
  `Negociacion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.cmc reporte historico gestion: ~100 rows (aproximadamente)
DELETE FROM `cmc reporte historico gestion`;
/*!40000 ALTER TABLE `cmc reporte historico gestion` DISABLE KEYS */;
INSERT INTO `cmc reporte historico gestion` (`Login`, `Fecha Gestion`, `Usuario`, `Station`, `Producto`, `Asesor Asignado`, `Identificacion`, `NUM_Obligacion`, `Numero Poliza`, `Campana`, `Placa`, `Grupo`, `Corte`, `TIP Codigo_Accion`, `TIP Tipo_Contacto`, `TIP ResultadoContacto`, `Tipo Razon`, `TIP Razon_Mora`, `TIP Detalle_Gestion`, `Fecha Promesa`, `Valor Acuerdo`, `Medio Pago`, `PAG NCuotas`, `Valor Total`, `PAG Fecha PrimerPago`, `Telefono Contacto`, `ACT Direccion`, `ACT Ciudad`, `ACT Depto`, `ACT Celular`, `ACT Telefono`, `ACT Email`, `Fecha Visita`, `NUM NIE Comprometido`, `Nombre Tercero`, `Parentesco Tercero`, `Departamento Tercero`, `Ciudad Tercero`, `TelFijo Tercero`, `Celular Tercero`, `Ocupacion`, `DESC Ocupacion`, `Plazo`, `Tasa`, `Cuota`, `Negociacion`) VALUES
	(1195, '2017-12-19 07:50:07', 'YESENIA SANCHEZ', 4084, 'CREDIUNO', '', '86070824', '4010930000663730', '', '', '', '', 25, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '06:44 a.m. 19/12/2017 SE MARCA AL NUMERO 3102161523 NO CONTESTA SE DEJO MENSAJE DE VOZ SE MARCA AL NUMERO 3192225084  NO CONTESTA SE DEJO MENSAJE DE VOZ SE MARCA AL NUMERO 86722796  NUMERO EQUIVOCADO ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1072, '2017-12-19 07:50:07', 'Dilan avendano', 4175, 'CREDIUNO', '', '85455212', '4010930000103216', '', '', '', '', 8, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1195, '2017-12-19 07:50:07', 'YESENIA SANCHEZ', 4084, 'CREDIUNO', '', '86072479', '6365490001117513', '', '', '', '', 8, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '06:48 a.m. 19/12/2017 SE MARCA AL NUMERO 3133676225 NO CONTESTA SE DEJO MENSAJE DE VOZ SE MARCA AL NUMERO 3133673225  NO CONTESTA SE DEJO MENSAJE DE VOZ SE MARCA AL NUMERO 86677870 NUMERO ERRADO SE MARCA AL NUMERO 86699955 NO CONTESTA SE MARCA AL NUMERO 3', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1143, '2017-12-19 07:50:07', 'FLOR YANETH GOMEZ GIRALDO', 4099, 'CREDIUNO', '', '40933204', '8010100001715043', '', '', '', '', 20, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '19/12/2017 CEL  3016528926  NUMERO SIGUE EN BUZON SE DEJO MENSAJE', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1143, '2017-12-19 07:50:07', 'FLOR YANETH GOMEZ GIRALDO', 4099, 'CREDIUNO', '', '1096205317', '8010100001587871', '', '', '', '', 8, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '19/12/2017 CE4L 3015252238 numero sigue con tono ocupado , tel (7) 3264000 numero registra con tono ocupado , tel (7) 6229667 nadie contesta este numero , tel (7) 6107286 numero registra con tono ocupado , no registra servicio de cliente único \n\n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1158, '2017-12-19 07:50:07', 'VANESSA GAUCHA', 4172, 'CREDIUNO', '', '79896709', '8010100001066702', '', '', '', '', 19, 'LLAMADA ENTRANTE', 'NO CONTACTO', 'TEL. DAÑADO/FUERA DE SERVICIO', '', '', '19/12/2017 cel : 3003845051 sin conexión ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1197, '2017-12-19 07:50:07', 'Jenny Carolina Leon', 4165, 'CREDIUNO', '', '17345716', '4010930001130184', '', '', '', '', 30, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '06:58 a.m. 19/12/2017 SE MARCA N° 3132839845 EN REF A CONFIRMACIÓN DE PAGO, NO CONTESTA SE DEJA MENSAJE DE  VOZ.JL', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'CREDIFINANCIERA', '', '16856045', '30000044306', '', 'Corrida menor a 6 Meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:00 a.m. 19/12/2017 cel 3105251324 no contesta \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1195, '2017-12-19 07:50:07', 'YESENIA SANCHEZ', 4084, 'CREDIUNO', '', '17413449', '6365490001156164', '', '', '', '', 20, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '06:55 a.m. 19/12/2017 SE MARCA AL NUMERO 3214843735  NUMERO EQUIVOCADO SE MARCA AL NUMERO 3118029074 NO CONTESTA SE MARCA AL NUMERO 86644181 NO CONTESTA SE DEJO MENSAJE DE VOZ SE MARCA AL NUMERO 3124584557REF FAM WILLIAM SANCHEZ NUMERO EQUIVOCADO SE MARCA', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1109, '2017-12-19 07:50:07', 'JOSE DAVID MARTINEZ', 4092, 'CREDIFINANCIERA', '', '22425023', '30000054224', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:00 a.m. 19/12/2017 // 3004514486, SE DEJA MENSAJE DE VOZ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'TU CREDITO', '', '10291778', '30907', '', 'Corrida menor a 6 Meses', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:01 a.m. 19/12/2017 cel 3227642906 buzon lleno \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1111, '2017-12-19 07:50:07', 'NUBIA ELIZA PLAZAS CASTAÑEDA', 4191, 'CREDIFINANCIERA', '', '18128480', '30000009147', '', 'Estrategia Navidad-Rees-Cond', '', '', 20, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:01 a.m. 19/12/2017 3133187103 NO CONTESTA SE DEJA MENSAJE DE VOZ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1107, '2017-12-19 07:50:07', 'Karen Lorena Serna Zipacon', 4188, 'TU CREDITO', '', '9101642', '541900000000297', '', 'Esc Activo', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:01 a.m. 19/12/2017 3125702395 no contesta', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1242, '2017-12-19 07:50:07', 'Catalina Parra Avila', 4087, 'CREDIFINANCIERA', '', '6159089', '30000054953', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3214011241 se deje mensaje de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1109, '2017-12-19 07:50:07', 'JOSE DAVID MARTINEZ', 4092, 'CREDIFINANCIERA', '', '17192021', '30000054484', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:02 a.m. 19/12/2017 // 3167165792, SE DEJA MENSAJE DE VOZ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1069, '2017-12-19 07:50:07', 'YEIMY PAOLA PEDRAZA CASTAÑEDA', 4068, 'CREDIFINANCIERA', '', '33132650', '30000054207', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:02 a.m. 19/12/2017 3145235283 SE DEJA MENSAJ DE VOZ/ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1196, '2017-12-19 07:50:07', 'NATHALI GONZALEZ', 4110, 'CREDIUNO', '', '52782138', '4010930000425452', '', '', '', '', 8, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:02 a.m. 19/12/2017  se llama al TT al N 3103406580 no contestan. ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'TU CREDITO', '', '12532316', '802000000000032', '', 'Reestructurado', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:03 a.m. 19/12/2017 cel 3217448107 mensaje de voz \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1232, '2017-12-19 07:50:07', 'Carlos Yecid Amaya Sierra', 4219, 'CREDIFINANCIERA', '', '19189608', '30000054517', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3112581059', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1031, '2017-12-19 07:50:07', 'DAMIAN RODRIGUEZ', 4063, 'CREDIFINANCIERA', '', '21829664', '8344', '', 'Corrida menor a 6 Meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:02 a.m. 19/12/2017 se llama 3207355189 no contestan buzon de voz se dejo información.', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1232, '2017-12-19 07:50:07', 'Carlos Yecid Amaya Sierra', 4219, 'CREDIFINANCIERA', '', '19189608', '30000054517', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3112581059   Se deja msj de voz', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1107, '2017-12-19 07:50:07', 'Karen Lorena Serna Zipacon', 4188, 'CREDIFINANCIERA', '', '19156373', '30000049613', '', 'Des menor a 6 meses-Corrida menor a 6 Meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:03 a.m. 19/12/2017 3138347912 no contesta y se deja msj de voz, \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1228, '2017-12-19 07:50:07', 'CRISTIAN DAVID PRADO SUAREZ', 4195, 'CREDIUNO', '', '1128427238', '8010100001818375', '', '', '', '', 23, 'LLAMADA CELULAR', 'NO CONTACTO', 'TEL. DAÑADO/FUERA DE SERVICIO', '', '', '09/12/2017 cel: 3226115301 no sale la llamada ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1238, '2017-12-19 07:50:07', 'Yenni Catherine Agudelo', 4036, 'CREDIUNO', '', '14943875', '4010930002613600', '', '', '', '', 13, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:04 a.m. 19/12/2017 se llama al 3182707616 no contesta', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1238, '2017-12-19 07:50:07', 'Yenni Catherine Agudelo', 4036, 'CREDIUNO', '', '14943875', '4010930002613600', '', '', '', '', 13, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:04 a.m. 19/12/2017 se llama al 3182707616 no contesta', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1242, '2017-12-19 07:50:07', 'Catalina Parra Avila', 4087, 'CREDIFINANCIERA', '', '25248387', '30000028473', '', 'Al Dia', '', '267876', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3143221306 se deja mensaje de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'TU CREDITO', '', '88197429', '541600000000200', '', 'Esc Activo Sistema', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:04 a.m. 19/12/2017 cel 3107824143 no contesta \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1239, '2017-12-19 07:50:07', 'Eliana Marcela Restrepo ', 4077, 'CREDIUNO', '', '17390080', '4010930001178027', '', '', '', '', 10, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:04 a.m. 19/12/2017 3208022802 NUMERO CEL APAGADO ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1159, '2017-12-19 07:50:07', 'Yeison Camilo Urrego Linares', 4081, 'CREDIUNO', '', '94229183', '4010930000607950', '', '', '', '', 24, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', 'NA', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1109, '2017-12-19 07:50:07', 'JOSE DAVID MARTINEZ', 4092, 'CREDIFINANCIERA', '', '20483186', '30000054096', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:04 a.m. 19/12/2017 // 3103129243, SE DEJA MENSAJE DE VOZ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1031, '2017-12-19 07:50:07', 'DAMIAN RODRIGUEZ', 4063, 'TU CREDITO', '', '20240517', '24944', '', 'Corrida menor a 6 Meses', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', ' 07:04 a.m. 19/12/2017 se llama  3186323108 no contestan buzon de voz .', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1043, '2017-12-19 07:50:07', 'YURI CATERINE SANCHEZ', 4071, 'CREDIFINANCIERA', '', '43566032', '14734', '', 'Estrategia Navidad-Rees-Cond', '', '', 12, 'LLAMADA CELULAR', 'CONTACTO TITULAR', 'TITULAR SIN PROMESA', '', '', '07:01 a.m. 19/12/2017\n3234780689 ** tt  informa que  le  estan  descontando  mes  a mes  se  el  reitera  que  no la  cuota  completa  se  le reiter a estado  tt  envía   soportes   para  aplicación de este  mes   y   cancela el  excedente  por  efecty  p', '0000-00-00', '', '', '', '', '', '3234780689', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1119, '2017-12-19 07:50:07', 'DIANA MILED MORENO DIAZ', 4177, 'TU CREDITO', '', '79102163', '810200000056300', '', 'Esc Activo Sistema', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3052975307  se deja msj bz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1232, '2017-12-19 07:50:07', 'Carlos Yecid Amaya Sierra', 4219, 'CREDIFINANCIERA', '', '1046306377', '30000053357', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'TEL. DAÑADO/FUERA DE SERVICIO', '', '', '15066315   SE ENCUENTRA FDS', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1049, '2017-12-19 07:50:07', 'ANDRES CAMILO DZEKA PINZON', 4132, 'CREDIUNO', '', '32638183', '6365490000175231', '', '', '', '', 8, 'LLAMADA CELULAR', 'CONTACTO TERCERO', 'MENSAJE TERCERO', 'EMPLEADO', 'DESEMPLEADO', '3015468514 // se deja mensaje con tercero se niega  a atender la llamada  ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1069, '2017-12-19 07:50:07', 'YEIMY PAOLA PEDRAZA CASTAÑEDA', 4068, 'CREDIFINANCIERA', '', '32408924', '30000053649', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:05 a.m. 19/12/2017 3117499845 SE DEJA MENSAJE DE VOZ/ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1109, '2017-12-19 07:50:07', 'JOSE DAVID MARTINEZ', 4092, 'CREDIFINANCIERA', '', '6154433', '30000054464', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:06 a.m. 19/12/2017 // 3163544191, SE DEJA MENSAJE DE VOZ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'TU CREDITO', '', '51917113', '10200000063408', '', 'Corrida menor a 6 Meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:06 a.m. 19/12/2017 cel 3112222731 no contesta \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1219, '2017-12-19 07:50:07', 'ERICA VANESA CARDENAS ESPINOSA', 4089, 'TU CREDITO', '', '12503888', '24642', '', 'Corrida menor a 6 Meses', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3115059626 no comtesta se deja mensaje de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1043, '2017-12-19 07:50:07', 'YURI CATERINE SANCHEZ', 4071, 'TU CREDITO', '', '19222167', '10400000004103', '', 'Estrategia Navidad-Rees-Cond-Esc', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:05 a.m. 19/12/2017\n3014807699 **  no contestan   ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1029, '2017-12-19 07:50:07', 'DANIELA ALEMAN ', 4155, 'TU CREDITO', '', '1019061272', '10200000068053', '', 'Juridico', '', '', 5, 'LLAMADA CELULAR', 'CONTACTO TITULAR', 'TITULAR SIN PROMESA', '', '', '19/12  3213358929  se deja mensaje en buzón. // 3213358929   titular sin compromiso de pago, no muestra interés en cancelar. sin empleo. ', '0000-00-00', '', '', '', '', '', '3213358929', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1119, '2017-12-19 07:50:07', 'DIANA MILED MORENO DIAZ', 4177, 'CREDIFINANCIERA', '', '91287894', '30000022413', '', 'Corrida menor a 6 Meses', '', '', 12, 'LLAMADA CELULAR', 'CONTACTO TITULAR', 'PROMESA DE PAGO', 'EMPLEADO', 'DISMINUCION DE INGRESOS', '3163280095: tt informa que el dia 19/12 un valor de 790.000 esta en la espera de un dinero que le adeudan  actualiza datos   cra 37 n° 38-28 apt 302 brr el prado Bucaramanga ', '2017-12-19', '790000', 'Efecty', '', '', '', '3163280095', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'INDEPENDIENTE', '', 0, 0, 0, ''),
	(1242, '2017-12-19 07:50:07', 'Catalina Parra Avila', 4087, 'CREDIFINANCIERA', '', '85456723', '30000054499', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3177835049 se deja mensaje de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'CREDIFINANCIERA', '', '22633757', '30000045339', '', 'Corrida menor a 6 Meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:07 a.m. 19/12/2017 cel 3053578227 mensaje de voz \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1061, '2017-12-19 07:50:07', 'MARITZA NIÑO', 4140, 'CREDIUNO', '', '1098733793', '6365490001472090', '', '', '', '', 23, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:03 a.m. 19/12/2017 cel 3164746998  mensaje buzon /unico cel 3166259908 no sale llamada cel 3202639289 mensaje  buzon', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1219, '2017-12-19 07:50:07', 'ERICA VANESA CARDENAS ESPINOSA', 4089, 'CREDIFINANCIERA', '', '6817050', '30000042683', '', 'Corrida menor a 6 Meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3117284589 no contesta ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1119, '2017-12-19 07:50:07', 'DIANA MILED MORENO DIAZ', 4177, 'TU CREDITO', '', '79760250', '26667', '', 'Corrida menor a 6 Meses', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'TEL. DAÑADO/FUERA DE SERVICIO', '', '', '3218757327  sr que contesta no conoce al tt ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1069, '2017-12-19 07:50:07', 'YEIMY PAOLA PEDRAZA CASTAÑEDA', 4068, 'CREDIFINANCIERA', '', '39541364', '30000029422', '', 'Corrida menor a 6 Meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:08 a.m. 19/12/2017 3153497290 se deja mensaje de voz/\n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1109, '2017-12-19 07:50:07', 'JOSE DAVID MARTINEZ', 4092, 'CREDIFINANCIERA', '', '41614688', '30000055166', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA DOMICILIO', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:08 a.m. 19/12/2017 // 14775080, SE DEJA MENSAJE DE VOZ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1158, '2017-12-19 07:50:07', 'VANESSA GAUCHA', 4172, 'CREDIUNO', '', '79896709', '8010100001066702', '', '', '', '', 19, 'LLAMADA CELULAR', 'CONTACTO TERCERO', 'MENSAJE TERCERO', '', 'SIN MOTIVO MANIFESTADO', '19/12/2017 cel : 3003845051 sin conexión , cel : 3004502742 se deja mensaje con el hermano indica numero del titular : 7272676 , tel : 7272676 se deja mensaje con la sra. Inés indica numero del titular : 3192173085 , cel : 3192173085 se deja mensaje en el', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1111, '2017-12-19 07:50:07', 'NUBIA ELIZA PLAZAS CASTAÑEDA', 4191, 'TU CREDITO', '', '8321305', '40200000004099', '', 'Esc Activo', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:08 a.m. 19/12/2017  3208148384  NO CONTESTA SE DEJA MENSAJE DE VOZ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1219, '2017-12-19 07:50:07', 'ERICA VANESA CARDENAS ESPINOSA', 4089, 'TU CREDITO', '', '11185190', '40200000003984', '', 'Corrida menor a 6 Meses', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'TEL. DAÑADO/FUERA DE SERVICIO', '', '', '3172574686 num equivocado ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'TU CREDITO', '', '33149771', '11200000004589', '', 'Esc Activo', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:09 a.m. 19/12/2017 cel 3178421987 mensaje de voz \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1107, '2017-12-19 07:50:07', 'Karen Lorena Serna Zipacon', 4188, 'CREDIFINANCIERA', '', '3834542', '30000055050', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'CONTACTO TERCERO', 'MENSAJE CON FAMILIAR', '', '', '07:06 a.m. 19/12/2017 3128073846, contesta la sra carmelina gomez, ( familiar), manifiesta que la línea que tenia el tt ya no sirve y no tiene línea actualizada, dice que cuando el la llame le dará el msj y toma el msj ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1119, '2017-12-19 07:50:07', 'DIANA MILED MORENO DIAZ', 4177, 'TU CREDITO', '', '34943002', '11900000001308', '', 'Esc Activo', '', '', 20, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3175177376  se deja msj bz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1111, '2017-12-19 07:50:07', 'NUBIA ELIZA PLAZAS CASTAÑEDA', 4191, 'TU CREDITO', '', '92532390', '15750', '', 'Corrida menor a 6 Meses', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:10 a.m. 19/12/2017 3007798557  NO CONTESTA SE DEJA MENSAJE DE VOZ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1031, '2017-12-19 07:50:07', 'DAMIAN RODRIGUEZ', 4063, 'CREDIFINANCIERA', '', '79317479', '30000012036', '', 'Corrida menor a 6 Meses', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:10 a.m. 19/12/2017 se llama 3153941505 buzon de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1232, '2017-12-19 07:50:07', 'Carlos Yecid Amaya Sierra', 4219, 'TU CREDITO', '', '11438792', '41700000000217', '', 'Esc Activo', '', '', 5, 'LLAMADA CELULAR', 'CONTACTO TITULAR', 'YA PAGO', 'EMPLEADO', 'DISMINUCION DE INGRESOS', '3052980347   Se contacta con el tt y me indica que ya realizó el pago y el código del Boucher es 8539078352.', '0000-00-00', '', '', '', '', '', '3052980347', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1109, '2017-12-19 07:50:07', 'JOSE DAVID MARTINEZ', 4092, 'TU CREDITO', '', '88034140', '811200000000472', '', 'Reestructurado', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:10 a.m. 19/12/2017 // 3162951373, SE DEJA MENSAJE DE VOZ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1069, '2017-12-19 07:50:07', 'YEIMY PAOLA PEDRAZA CASTAÑEDA', 4068, 'CREDIFINANCIERA', '', '7425256', '30000054747', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:11 a.m. 19/12/2017 3017601874 SE DEJA MENSAJE DE VOZ/', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1043, '2017-12-19 07:50:07', 'YURI CATERINE SANCHEZ', 4071, 'TU CREDITO', '', '1097392673', '27105', '', 'Corrida menor a 6 Meses', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:10 a.m. 19/12/2017\n3133976892 **   mensaje  de  voz    ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1119, '2017-12-19 07:50:07', 'DIANA MILED MORENO DIAZ', 4177, 'TU CREDITO', '', '39032123', '11100000001418', '', 'Estrategia Navidad-Rees-Cond-Esc', '', '', 27, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3046663989  se deja msj bz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1107, '2017-12-19 07:50:07', 'Karen Lorena Serna Zipacon', 4188, 'CREDIFINANCIERA', '', '14198470', '30000054669', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '\n07:11 a.m. 19/12/2017 3114829984 no contesta', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1031, '2017-12-19 07:50:07', 'DAMIAN RODRIGUEZ', 4063, 'TU CREDITO', '', '12132146', '7827', '', 'Corrida menor a 6 Meses', '', '', 30, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:11 a.m. 19/12/2017 se llama 3138707755 no contestan buzon de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'TU CREDITO', '', '89000908', '830200000002814', '', 'Reestructurado', '', '', 5, 'LLAMADA CELULAR', 'CONTACTO TERCERO', 'MENSAJE TERCERO', '', '', '07:11 a.m. 19/12/2017 fijo 8131403 se deja mensaje con la sra elsa suegra del tt\n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1111, '2017-12-19 07:50:07', 'NUBIA ELIZA PLAZAS CASTAÑEDA', 4191, 'CREDIFINANCIERA', '', '9098600', '30000038065', '', 'Corrida menor a 6 Meses', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'TEL. DAÑADO/FUERA DE SERVICIO', '', '', '07:11 a.m. 19/12/2017 56537996  contesta sra  judith informa que la cuñada de ella  es la nuera de el ,pero ella no vive ahi y ella no  tiene contacto con el \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1233, '2017-12-19 07:50:07', 'DAYANA CATALIN LOZADA SANCHEZ', 4166, 'TU CREDITO', '', '40798036', '502200000005465', '', 'Esc Activo', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '3128765035  se deja mnjs de voz.', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1242, '2017-12-19 07:50:07', 'Catalina Parra Avila', 4087, 'CREDIFINANCIERA', '', '22780831', '30000053822', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '3163219599 se deja mensaje de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1109, '2017-12-19 07:50:07', 'JOSE DAVID MARTINEZ', 4092, 'CREDIFINANCIERA', '', '79686220', '30000051094', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:12 a.m. 19/12/2017 // 3108730404, SE DEJA MENSAJE DE VOZ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1031, '2017-12-19 07:50:07', 'DAMIAN RODRIGUEZ', 4063, 'CREDIFINANCIERA', '', '8277532', '30000025137', '', 'Estrategia Navidad-Rees-Cond', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:12 a.m. 19/12/2017 se llama 3004942709 no contestan buzon de voz . ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'TU CREDITO', '', '37822275', '10300000008902', '', 'Esc Activo', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:12 a.m. 19/12/2017 cel 3005707798 mensaje de voz \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1119, '2017-12-19 07:50:07', 'DIANA MILED MORENO DIAZ', 4177, 'TU CREDITO', '', '79540008', '41400000000118', '', 'Esc Activo', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3134121951  se deja msj bz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1069, '2017-12-19 07:50:07', 'YEIMY PAOLA PEDRAZA CASTAÑEDA', 4068, 'CREDIFINANCIERA', '', '32453492', '30000054519', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'TEL. DAÑADO/FUERA DE SERVICIO', '', '', 'Tel. Dañado: __________07:13 a.m. 19/12/2017 43170880 NO CONOCE TITULAR/ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1111, '2017-12-19 07:50:07', 'NUBIA ELIZA PLAZAS CASTAÑEDA', 4191, 'TU CREDITO', '', '27719001', '501600000001700', '', 'Estrategia Navidad-Rees-Cond-Esc', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:13 a.m. 19/12/2017 3208730167  NO CONTESTA SE DEJA MENSAJE DE VOZ \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1237, '2017-12-19 07:50:07', 'Cristian David Garzon Alfonso', 4115, 'CREDIUNO', '', '79131993', '4010930001373404', '', '', '', '', 8, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1118, '2017-12-19 07:50:07', 'DIANA ANGELICA PINEDA', 4069, 'TU CREDITO', '', '19159108', '500200000009149', '', 'Estrategia Navidad-Rees-Cond-Esc', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:13 a.m. 19/12/2017 3194839248 No contesta, se insiste y se deja mjs de voz. ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1233, '2017-12-19 07:50:07', 'DAYANA CATALIN LOZADA SANCHEZ', 4166, 'TU CREDITO', '', '8386418', '500600000001772', '', 'Estrategia Navidad-Rees-Cond-Esc', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3128765035 se deja mnjs de voz.', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1119, '2017-12-19 07:50:07', 'DIANA MILED MORENO DIAZ', 4177, 'TU CREDITO', '', '37931144', '530300000000239', '', 'Lista Negra', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3153395645  se deja msj bz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1118, '2017-12-19 07:50:07', 'DIANA ANGELICA PINEDA', 4069, 'TU CREDITO', '', '1014193776', '30500000000533', '', 'Estrategia Navidad-Rees-Cond-Esc', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:14 a.m. 19/12/2017 3225768363 No contesta, se insiste y se deja mjs de voz. ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1232, '2017-12-19 07:50:07', 'Carlos Yecid Amaya Sierra', 4219, 'TU CREDITO', '', '26740725', '11100000002779', '', 'Esc Activo', '', '', 5, 'LLAMADA CELULAR', 'CONTACTO TITULAR', 'PROMESA DE PAGO', 'EMPLEADO', 'DISMINUCION DE INGRESOS', '3016042042   Se contacta con el tt y me indica que cancelará 135.000 pesos. Datos ok', '2017-12-20', '135000', 'Efecty', '', '', '', '3016042042', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1109, '2017-12-19 07:50:07', 'JOSE DAVID MARTINEZ', 4092, 'CREDIFINANCIERA', '', '59662079', '30000054791', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:14 a.m. 19/12/2017 // 3162588656, SE DEJA MENSAJE DE VOZ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1233, '2017-12-19 07:50:07', 'DAYANA CATALIN LOZADA SANCHEZ', 4166, 'CREDIFINANCIERA', '', '43504456', '10600000002545', '', 'k+i', '', '', 20, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3136620404 se deja mnjs de voz..', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1031, '2017-12-19 07:50:07', 'DAMIAN RODRIGUEZ', 4063, 'TU CREDITO', '', '19250808', '10200000063259', '', 'Lista Negra', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:14 a.m. 19/12/2017 se llama 3143495294 no contestan buzon de voz \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1119, '2017-12-19 07:50:07', 'DIANA MILED MORENO DIAZ', 4177, 'TU CREDITO', '', '41907386', '500500000000107', '', 'Estrategia Navidad-Rees-Cond-Esc', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3137759529   se deja msj bz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1118, '2017-12-19 07:50:07', 'DIANA ANGELICA PINEDA', 4069, 'TU CREDITO', '', '22428573', '10400000006115', '', 'Estrategia Navidad-Rees-Cond-Esc', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:15 a.m. 19/12/2017 3024491516  No contesta, se insiste y se deja mjs de voz. ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1111, '2017-12-19 07:50:07', 'NUBIA ELIZA PLAZAS CASTAÑEDA', 4191, 'TU CREDITO', '', '41777198', '810200000051355', '', 'Lista Negra', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:15 a.m. 19/12/2017 3008340001  NO CONTESTA SE DEJA MENSAJE DE VOZ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'TU CREDITO', '', '25706774', '10200000039401', '', 'Lista Negra', '', '', 5, 'LLAMADA CELULAR', 'CONTACTO TITULAR', 'CLIENTE CUELGA', '', '', '07:15 a.m. 19/12/2017 cel 3127216993 la tt identifica la llamada y queda en silencio\n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1069, '2017-12-19 07:50:07', 'YEIMY PAOLA PEDRAZA CASTAÑEDA', 4068, 'TU CREDITO', '', '80037383', '28267', '', 'Al Dia', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:15 a.m. 19/12/2017 3208080224 SE DEJA MENSAJE DE VOZ/ \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1233, '2017-12-19 07:50:07', 'DAYANA CATALIN LOZADA SANCHEZ', 4166, 'TU CREDITO', '', '16284779', '10100000041364', '', 'Lista Negra', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3184198664 se deja mnjs de voz.', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1232, '2017-12-19 07:50:07', 'Carlos Yecid Amaya Sierra', 4219, 'CREDIFINANCIERA', '', '13829321', '30000055199', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3227321977   Se deja msj de voz', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1219, '2017-12-19 07:50:07', 'ERICA VANESA CARDENAS ESPINOSA', 4089, 'TU CREDITO', '', '12624828', '811100000001379', '', 'Reestructurado', '', '', 20, 'LLAMADA CELULAR', 'CONTACTO TITULAR', 'TITULAR SIN PROMESA', 'EMPLEADO', 'RENUENTE', '3205285384 tt no deja hablar dice que somos unos mala gente por haberlo reportado a  centrales de riesgo no deja hablar y llegar acuerdo de pago ', '0000-00-00', '', '', '', '', '', '3205285384', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1111, '2017-12-19 07:50:07', 'NUBIA ELIZA PLAZAS CASTAÑEDA', 4191, 'TU CREDITO', '', '41777198', '810200000051355', '', 'Lista Negra', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:16 a.m. 19/12/2017 3103091261   NO CONTESTA SE DEJA MENSAJE DE VOZ ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1228, '2017-12-19 07:50:07', 'CRISTIAN DAVID PRADO SUAREZ', 4195, 'CREDIUNO', '', '1128427238', '8010100001818375', '', '', '', '', 23, 'LLAMADA CELULAR', 'CONTACTO TITULAR', 'PROMESA DE PAGO', '', 'ILIQUIDEZ TRANSITORIA', '19/12/2017 cel: 3003022886 se habla con el titular, se genera promesa de pago para el dia 23/12/2017 por un valor de $ 25.000 como pago para poder financiar la deuda a 6 meses con cuotas aproximadas de $ 46.000 , mora: iliquidez , datos correctos. ', '2017-12-23', '25000', 'Efecty', '', '', '', '3003022886', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1227, '2017-12-19 07:50:07', 'XIMENA RODRIGUEZ', 4093, 'CREDIFINANCIERA', '', '1121299584', '30000016110', '', 'Estrategia Navidad-Rees-Cond', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '07:16 a.m. 19/12/2017 cel 3126383202 no contesta \n', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1031, '2017-12-19 07:50:07', 'DAMIAN RODRIGUEZ', 4063, 'TU CREDITO', '', '63342872', '810300000006912', '', 'Lista Negra', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '07:16 a.m. 19/12/2017 se llama 3153485385 no contestan buzon de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1233, '2017-12-19 07:50:07', 'DAYANA CATALIN LOZADA SANCHEZ', 4166, 'TU CREDITO', '', '79600734', '30200000002897', '', 'Lista Negra', '', '', 5, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3136541964 se deja mnsj de voz....', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1242, '2017-12-19 07:50:07', 'Catalina Parra Avila', 4087, 'CREDIFINANCIERA', '', '17626660', '30000054448', '', 'Des menor a 6 meses', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3163219599 se deja mensaje de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1119, '2017-12-19 07:50:07', 'DIANA MILED MORENO DIAZ', 4177, 'CREDIFINANCIERA', '', '1144055898', '30000027982', '', 'Estrategia Navidad-Rees-Cond', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'NO CONTESTA', '', '', '3004289165  contestan cortan la llamada ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1003, '2017-12-19 07:50:07', 'TERESA GARZON', 4078, 'CREDIFINANCIERA', '', '37822714', '30000049219', '', 'Des menor a 6 meses-Corrida menor a 6 Meses', '', '', 12, 'LLAMADA CELULAR', 'CONTACTO TITULAR', 'TITULAR SIN PROMESA', 'OPERACIONES', 'CLIENTE MANIFIESTA CAPACIDAD SIN DESCUENTO', '07:13 a.m. 19/12/2017  3172585618 contesta indica que ha tenido inconvenientes con la libranza y que necesita el documento para recoger la obligación, ya que no tiene como pagar la cuota, se le indica que se le enviara y se le llamara  3017397605    confi', '0000-00-00', '', '', '', '', '', '3172585618', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, ''),
	(1219, '2017-12-19 07:50:07', 'ERICA VANESA CARDENAS ESPINOSA', 4089, 'TU CREDITO', '', '41691682', '9442', '', 'Estrategia Navidad-Rees-Cond-Esc', '', '', 12, 'LLAMADA CELULAR', 'NO CONTACTO', 'MENSAJE EN BUZÓN', '', '', '3184522598 no contesta se deja mensaje de voz ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0, '');
/*!40000 ALTER TABLE `cmc reporte historico gestion` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.condonaciones
CREATE TABLE IF NOT EXISTS `condonaciones` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.condonaciones: ~0 rows (aproximadamente)
DELETE FROM `condonaciones`;
/*!40000 ALTER TABLE `condonaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `condonaciones` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.consolida efecty
CREATE TABLE IF NOT EXISTS `consolida efecty` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` double DEFAULT NULL,
  `Numero_Credito` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `VLR_Pago` double DEFAULT NULL,
  `Fecha_Aplica_Pago` date DEFAULT NULL,
  `TRX` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.consolida efecty: ~0 rows (aproximadamente)
DELETE FROM `consolida efecty`;
/*!40000 ALTER TABLE `consolida efecty` DISABLE KEYS */;
/*!40000 ALTER TABLE `consolida efecty` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.consolida recaudo
CREATE TABLE IF NOT EXISTS `consolida recaudo` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` double DEFAULT NULL,
  `Numero_Credito` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `VLR_Pago` double DEFAULT NULL,
  `Fecha_Aplica_Pago` date DEFAULT NULL,
  `TRX` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.consolida recaudo: ~0 rows (aproximadamente)
DELETE FROM `consolida recaudo`;
/*!40000 ALTER TABLE `consolida recaudo` DISABLE KEYS */;
/*!40000 ALTER TABLE `consolida recaudo` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.consolidado_recaudo_tg
CREATE TABLE IF NOT EXISTS `consolidado_recaudo_tg` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Tarjeta` varchar(255) DEFAULT NULL,
  `Recaudo` double DEFAULT NULL,
  `Capital` double DEFAULT NULL,
  `Franja Mora` varchar(255) DEFAULT NULL,
  `Franja_Mora_Bu` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Mes` varchar(255) DEFAULT NULL,
  `Bloqueo_U` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.consolidado_recaudo_tg: ~0 rows (aproximadamente)
DELETE FROM `consolidado_recaudo_tg`;
/*!40000 ALTER TABLE `consolidado_recaudo_tg` DISABLE KEYS */;
/*!40000 ALTER TABLE `consolidado_recaudo_tg` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.consulta3
CREATE TABLE IF NOT EXISTS `consulta3` (
  `Fecha Llamada` date DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `ANT` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.consulta3: ~0 rows (aproximadamente)
DELETE FROM `consulta3`;
/*!40000 ALTER TABLE `consulta3` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta3` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.cruce
CREATE TABLE IF NOT EXISTS `cruce` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Casa` varchar(255) DEFAULT NULL,
  `Ejecutivo` varchar(255) DEFAULT NULL,
  `CC` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.cruce: ~0 rows (aproximadamente)
DELETE FROM `cruce`;
/*!40000 ALTER TABLE `cruce` DISABLE KEYS */;
/*!40000 ALTER TABLE `cruce` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.cruce segmento
CREATE TABLE IF NOT EXISTS `cruce segmento` (
  `FILTRO CARTERA` varchar(255) DEFAULT NULL,
  `FILTRO CARTERA MODF` varchar(255) DEFAULT NULL,
  `FILTRO CARTERA HOY` varchar(255) DEFAULT NULL,
  `GRUPO` varchar(255) DEFAULT NULL,
  `PRODUCTO` varchar(255) DEFAULT NULL,
  `UNIDAD` varchar(255) DEFAULT NULL,
  `PRODUCTO_HOMOL` varchar(255) DEFAULT NULL,
  `CREDITO` varchar(255) DEFAULT NULL,
  `PAGARE` varchar(255) DEFAULT NULL,
  `TARJETA` varchar(255) DEFAULT NULL,
  `NUMERO_CREDITO` varchar(255) DEFAULT NULL,
  `CREDITO SL` varchar(255) DEFAULT NULL,
  `LLAVE` varchar(255) DEFAULT NULL,
  `LLAVE_TC` varchar(255) DEFAULT NULL,
  `LLAVE SL` varchar(255) DEFAULT NULL,
  `FECHA_DESEMBOLSO` varchar(255) DEFAULT NULL,
  `FECHA_PRIMERA_CUOTA` varchar(255) DEFAULT NULL,
  `FECHA_PROXIMO_PAGO` varchar(255) DEFAULT NULL,
  `FECHA_VENCIMIENTO_CREDITO` varchar(255) DEFAULT NULL,
  `FECHA_ULTIMA_PARADA` varchar(255) DEFAULT NULL,
  `FECHA_ULTIMA_CORRIDA` varchar(255) DEFAULT NULL,
  `ESTADO_ESCINDIDO` varchar(255) DEFAULT NULL,
  `COD_PRODUCTO` double DEFAULT NULL,
  `DIA DE FACTURACION` double DEFAULT NULL,
  `IDENTIFICACION` double DEFAULT NULL,
  `IDENTIFICACION TXT` varchar(255) DEFAULT NULL,
  `NOMBRE_COMPLETO` varchar(255) DEFAULT NULL,
  `PROM PAGO 3M` double DEFAULT NULL,
  `SEGMENTO X PAGO` varchar(255) DEFAULT NULL,
  `SEGMENTO ESPECIAL` varchar(255) DEFAULT NULL,
  `SEGMENTO` varchar(255) DEFAULT NULL,
  `SEGMENTO 2` varchar(255) DEFAULT NULL,
  `SEGMENTO_OPERATIVO` varchar(255) DEFAULT NULL,
  `SEGMENTO_RIESGOS` varchar(255) DEFAULT NULL,
  `SEGMENTO_MARCA` varchar(255) DEFAULT NULL,
  `CASA DE COBRO` varchar(255) DEFAULT NULL,
  `CASA DE COBRO 2` varchar(255) DEFAULT NULL,
  `EJECUTIVO` varchar(255) DEFAULT NULL,
  `CC EJECUTIVO` varchar(255) DEFAULT NULL,
  `PAGO MINIMO HOY` double DEFAULT NULL,
  `PAGO MINIMO` double DEFAULT NULL,
  `VALOR CUOTA` double DEFAULT NULL,
  `SALDO CAPITAL` double DEFAULT NULL,
  `CAPITAL_EN_MILLONES` double DEFAULT NULL,
  `PAGO TOTAL` double DEFAULT NULL,
  `CAPITAL_PENDIENTE` int(11) DEFAULT NULL,
  `SALDO_CREDITO` int(11) DEFAULT NULL,
  `CAPITAL_VIGENTE` int(11) DEFAULT NULL,
  `INTERES_Y_OTROS_TOTALES` double DEFAULT NULL,
  `INTERES_Y_OTROS_PENDIENTES` double DEFAULT NULL,
  `INTERES_PENDIENTE` int(11) DEFAULT NULL,
  `INTERES_PROYECTADO` int(11) DEFAULT NULL,
  `MORA_PENDIENTE` int(11) DEFAULT NULL,
  `MORA_PROYECTADA` int(11) DEFAULT NULL,
  `CARGOS_FIJOS_PROYECTADOS` int(11) DEFAULT NULL,
  `CARGOS_FIJOS_PENDIENTES` int(11) DEFAULT NULL,
  `CAPITAL_PROYECTADO` int(11) DEFAULT NULL,
  `DIAS MORA` double DEFAULT NULL,
  `FRANJA MORA` varchar(255) DEFAULT NULL,
  `PERFIL_RIESGO` varchar(255) DEFAULT NULL,
  `VALOR VENCIDO` double DEFAULT NULL,
  `EMPRESA` varchar(255) DEFAULT NULL,
  `CONVENIO_HOMOLOGADO` varchar(255) DEFAULT NULL,
  `CONVENIO_HOMOLOGADO_CORTO` varchar(255) DEFAULT NULL,
  `CONVENIO_ASEGURADORA` varchar(255) DEFAULT NULL,
  `ESP` varchar(255) DEFAULT NULL,
  `ESTADO_EMPRESA` varchar(255) DEFAULT NULL,
  `ULTIMO_MOTIVO_DE_NO_PAGO` varchar(255) DEFAULT NULL,
  `ULTIMO_MOTIVO_DE_NO_PAGO_HOMOLOGADO` varchar(255) DEFAULT NULL,
  `FECHA_ULTIMO_MOTIVO_DE_NO_PAGO` varchar(255) DEFAULT NULL,
  `DESTINO_ECONOMICO` varchar(255) DEFAULT NULL,
  `DESTINO_ECONOMICO_HOY` varchar(255) DEFAULT NULL,
  `CIUDAD_AGENCIA` varchar(255) DEFAULT NULL,
  `CIUDAD` varchar(255) DEFAULT NULL,
  `CIUDAD_DIRECCION` varchar(255) DEFAULT NULL,
  `DIRECCION` varchar(255) DEFAULT NULL,
  `TELEFONO` varchar(255) DEFAULT NULL,
  `CELULAR` varchar(255) DEFAULT NULL,
  `CIUDAD_CREDITO` varchar(255) DEFAULT NULL,
  `FRANJA DELTA` varchar(255) DEFAULT NULL,
  `FRANJA DELTA BRUJULA` varchar(255) DEFAULT NULL,
  `ULTIMA TIPIFICACION` varchar(255) DEFAULT NULL,
  `FECHA ULTIMA GESTION` date DEFAULT NULL,
  `CUENTA TOTAL TIPIFICACIONES` varchar(255) DEFAULT NULL,
  `ANTIGUEDAD ULTIMA TIPF` varchar(255) DEFAULT NULL,
  `FECHA MEJOR GESTION` date DEFAULT NULL,
  `FECHA MEJOR GESTION EXT` date DEFAULT NULL,
  `MEJOR TIPIFICACION` varchar(255) DEFAULT NULL,
  `MEJOR TIPIFICACION EXT` varchar(255) DEFAULT NULL,
  `ESTADO PROMESA` varchar(255) DEFAULT NULL,
  `MEJOR TIPIFICACION FINAL` varchar(255) DEFAULT NULL,
  `MEJOR TIPIFICACION FINAL EXT` varchar(255) DEFAULT NULL,
  `MEJOR TIPIF FINAL MES ANT` varchar(255) DEFAULT NULL,
  `CUENTA MEJOR TIPF` varchar(255) DEFAULT NULL,
  `FECHA PROMESA` date DEFAULT NULL,
  `VALOR ACUERDO` varchar(255) DEFAULT NULL,
  `FECHA MEJOR RAZON MORA` date DEFAULT NULL,
  `MEJOR RAZON MORA` varchar(255) DEFAULT NULL,
  `CUENTA MEJOR RAZON MORA` varchar(255) DEFAULT NULL,
  `ANTIGUEDAD HOMOLOGADA` varchar(255) DEFAULT NULL,
  `CUENTA TIPF HOMOLOGADA` varchar(255) DEFAULT NULL,
  `FRANJA DELTA HOY` varchar(255) DEFAULT NULL,
  `FRANJA DELTA MES ANT` varchar(255) DEFAULT NULL,
  `FRANJA_MORA_HOY` varchar(255) DEFAULT NULL,
  `DIAS_MORA_HOY` double DEFAULT NULL,
  `FECHA ULTIMO PAGO` varchar(255) DEFAULT NULL,
  `VALOR RECAUDO` double DEFAULT NULL,
  `TIPO APLICADO` varchar(255) DEFAULT NULL,
  `FECHA_PAGO EFECTY` date DEFAULT NULL,
  `VALOR RECAUDO EFECTY` double DEFAULT NULL,
  `VALOR RECAUDO TOTAL` double DEFAULT NULL,
  `VALOR RECAUDO EXTERNO` double DEFAULT NULL,
  `VALOR RECAUDO TOTAL_MES ANTERIOR` int(11) DEFAULT NULL,
  `DIAS PAR EL CORTE` int(11) DEFAULT NULL,
  `DIAS MORA PROY` int(11) DEFAULT NULL,
  `FRANJA MORA PROY` varchar(255) DEFAULT NULL,
  `FRANJA DELTA PROY` varchar(255) DEFAULT NULL,
  `ESTADO_CREDITO` varchar(255) DEFAULT NULL,
  `ESTADO GERENCIAL` varchar(255) DEFAULT NULL,
  `ESTADO DELTA` varchar(255) DEFAULT NULL,
  `ESTADO DELTA 30` varchar(255) DEFAULT NULL,
  `ESTADO DELTA 90` varchar(255) DEFAULT NULL,
  `ESTADO DELTA CICLO 5` varchar(255) DEFAULT NULL,
  `ESTADO DELTA SIN RED - FGA` varchar(255) DEFAULT NULL,
  `ESTADO DELTA MES ANT` varchar(255) DEFAULT NULL,
  `ESTADO DELTA MES ANT RED - FGA` varchar(255) DEFAULT NULL,
  `VALOR MÍNIMO` double DEFAULT NULL,
  `ESTADO GERENCIAL PAGOS` varchar(255) DEFAULT NULL,
  `ESTADO DELTA PAGOS` varchar(255) DEFAULT NULL,
  `ESTADO GERENCIAL SIN NORM` varchar(255) DEFAULT NULL,
  `ESTADO DELTA SIN NORM` varchar(255) DEFAULT NULL,
  `TIPIFICACION` varchar(255) DEFAULT NULL,
  `% PAGO VS CUOTA` double DEFAULT NULL,
  `RECAUDO_NOMINA_NUMERO` int(11) DEFAULT NULL,
  `RECAUDO_NOMINA_MES_ACTUAL` int(11) DEFAULT NULL,
  `GAG_APLICADO_MES` int(11) DEFAULT NULL,
  `RECAUDO_NOMINA_SIN_GAG` int(11) DEFAULT NULL,
  `RECAUDO_NOMINA_VS_CUOTA` double DEFAULT NULL,
  `RECUADO_NOMINA_TOTAL_VS_CUOTA` double DEFAULT NULL,
  `TASA NMV` varchar(255) DEFAULT NULL,
  `VALOR DESEMBOLSO` varchar(255) DEFAULT NULL,
  `NOMBRES` varchar(255) DEFAULT NULL,
  `APELLIDOS` varchar(255) DEFAULT NULL,
  `UNIDAD DEL CREDITO` varchar(255) DEFAULT NULL,
  `RECAUDO NOMINA MESES 1` double DEFAULT NULL,
  `RECAUDO NOMINA MESES 2` double DEFAULT NULL,
  `NIT CONVENIO` varchar(255) DEFAULT NULL,
  `CODIGO EMPRESA` varchar(255) DEFAULT NULL,
  `ENTIDAD_PROPIETARIA_CREDITO` varchar(255) DEFAULT NULL,
  `PLAZO` varchar(255) DEFAULT NULL,
  `CUOTAS PAGAS` varchar(255) DEFAULT NULL,
  `BLOQUEO_U` varchar(255) DEFAULT NULL,
  `MARCA ESPECIAL` varchar(255) DEFAULT NULL,
  `REDIFERIDO` varchar(255) DEFAULT NULL,
  `ZONA` varchar(255) DEFAULT NULL,
  `ASESOR` varchar(255) DEFAULT NULL,
  `REGIONAL` varchar(255) DEFAULT NULL,
  `ORIGINACION_CARTERA` varchar(255) DEFAULT NULL,
  `FECHA_INICIO_VIGENCIA` date DEFAULT NULL,
  `FECHA_FIN_VIGENCIA` date DEFAULT NULL,
  `ESTADO DE MARCAS` varchar(255) DEFAULT NULL,
  `TIPO CASOS` varchar(255) DEFAULT NULL,
  `SOLUCION CASOS` varchar(255) DEFAULT NULL,
  `Ciudad_Origen` varchar(255) DEFAULT NULL,
  `Ciudad_Ubicacion_Cliente` varchar(255) DEFAULT NULL,
  `POTENCIAL` varchar(255) DEFAULT NULL,
  `aseguradora_bizagi` varchar(255) DEFAULT NULL,
  `NOMBRE_CONVENIO_BIZAGI` varchar(255) DEFAULT NULL,
  `FECHA_LIMITE_PAGO_ESP` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.cruce segmento: ~0 rows (aproximadamente)
DELETE FROM `cruce segmento`;
/*!40000 ALTER TABLE `cruce segmento` DISABLE KEYS */;
/*!40000 ALTER TABLE `cruce segmento` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.efecty cf
CREATE TABLE IF NOT EXISTS `efecty cf` (
  `NumeroOrden` varchar(255) DEFAULT NULL,
  `OficinaOrigen` varchar(255) DEFAULT NULL,
  `DESCOficinaOrigen` varchar(255) DEFAULT NULL,
  `Proyecto` varchar(255) DEFAULT NULL,
  `ValorMovilizado` double DEFAULT NULL,
  `ValorComision` double DEFAULT NULL,
  `FechaFacturacion` datetime DEFAULT NULL,
  `OficinaDestino` varchar(255) DEFAULT NULL,
  `ValorIVA` double DEFAULT NULL,
  `FechaCreps` datetime DEFAULT NULL,
  `Documento` varchar(255) DEFAULT NULL,
  `TipoDoc` varchar(255) DEFAULT NULL,
  `Nombres` varchar(255) DEFAULT NULL,
  `Apellido1` varchar(255) DEFAULT NULL,
  `Apellido2` varchar(255) DEFAULT NULL,
  `Saldo` varchar(255) DEFAULT NULL,
  `NumCred` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.efecty cf: ~0 rows (aproximadamente)
DELETE FROM `efecty cf`;
/*!40000 ALTER TABLE `efecty cf` DISABLE KEYS */;
/*!40000 ALTER TABLE `efecty cf` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.efecty tc
CREATE TABLE IF NOT EXISTS `efecty tc` (
  `Documento` varchar(255) DEFAULT NULL,
  `NumeroOrden` varchar(255) DEFAULT NULL,
  `TipoDoc` varchar(255) DEFAULT NULL,
  `OficinaOrigen` varchar(255) DEFAULT NULL,
  `DESCOficinaOrigen` varchar(255) DEFAULT NULL,
  `Nombres` varchar(255) DEFAULT NULL,
  `Apellido1` varchar(255) DEFAULT NULL,
  `Proyecto` varchar(255) DEFAULT NULL,
  `ValorMovilizado` double DEFAULT NULL,
  `Apellido2` varchar(255) DEFAULT NULL,
  `DiasMora` varchar(255) DEFAULT NULL,
  `ValorComision` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `FechaFacturacion` datetime DEFAULT NULL,
  `OficinaDestino` varchar(255) DEFAULT NULL,
  `ValorIVA` double DEFAULT NULL,
  `FechaCreps` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.efecty tc: ~0 rows (aproximadamente)
DELETE FROM `efecty tc`;
/*!40000 ALTER TABLE `efecty tc` DISABLE KEYS */;
/*!40000 ALTER TABLE `efecty tc` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.estado pp por dia
CREATE TABLE IF NOT EXISTS `estado pp por dia` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Fecha_Promesa` date DEFAULT NULL,
  `Fecha_Para_Calificar` date DEFAULT NULL,
  `Valor Acuerdo` double DEFAULT NULL,
  `Valor Recaudo Total` double DEFAULT NULL,
  `Estado PP` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.estado pp por dia: ~0 rows (aproximadamente)
DELETE FROM `estado pp por dia`;
/*!40000 ALTER TABLE `estado pp por dia` DISABLE KEYS */;
/*!40000 ALTER TABLE `estado pp por dia` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.estado pp por dia12
CREATE TABLE IF NOT EXISTS `estado pp por dia12` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NUM_Obligacion` varchar(255) DEFAULT NULL,
  `Llave SL` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Fecha_Promesa` date DEFAULT NULL,
  `Fecha_Para_Calificar` date DEFAULT NULL,
  `Valor Acuerdo` double DEFAULT NULL,
  `Valor Recaudo Total` double DEFAULT NULL,
  `Estado PP` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.estado pp por dia12: ~0 rows (aproximadamente)
DELETE FROM `estado pp por dia12`;
/*!40000 ALTER TABLE `estado pp por dia12` DISABLE KEYS */;
/*!40000 ALTER TABLE `estado pp por dia12` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.franjamorafoto_c1
CREATE TABLE IF NOT EXISTS `franjamorafoto_c1` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` double DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Franja_Mora` varchar(255) DEFAULT NULL,
  `Franja_Delta_Brujula` varchar(255) DEFAULT NULL,
  `Franja_Delta` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.franjamorafoto_c1: ~0 rows (aproximadamente)
DELETE FROM `franjamorafoto_c1`;
/*!40000 ALTER TABLE `franjamorafoto_c1` DISABLE KEYS */;
/*!40000 ALTER TABLE `franjamorafoto_c1` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.gestion
CREATE TABLE IF NOT EXISTS `gestion` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.gestion: ~0 rows (aproximadamente)
DELETE FROM `gestion`;
/*!40000 ALTER TABLE `gestion` DISABLE KEYS */;
/*!40000 ALTER TABLE `gestion` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.gestion casa ext
CREATE TABLE IF NOT EXISTS `gestion casa ext` (
  `Fecha Reporte` date DEFAULT NULL,
  `Fecha Llamada` date DEFAULT NULL,
  `Hora Gestion Inicial` time DEFAULT NULL,
  `Hora gestion Final` time DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Nro ProductoCredito` varchar(255) DEFAULT NULL,
  `Numero Marcado` double DEFAULT NULL,
  `Tipificacion` varchar(255) DEFAULT NULL,
  `Razon Mora` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `Franja` double DEFAULT NULL,
  `Fecha de Promesa` date DEFAULT NULL,
  `Valor Promesa` double DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `Mes Asignado` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Caso` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.gestion casa ext: ~101 rows (aproximadamente)
DELETE FROM `gestion casa ext`;
/*!40000 ALTER TABLE `gestion casa ext` DISABLE KEYS */;
INSERT INTO `gestion casa ext` (`Fecha Reporte`, `Fecha Llamada`, `Hora Gestion Inicial`, `Hora gestion Final`, `Identificacion`, `Nro ProductoCredito`, `Numero Marcado`, `Tipificacion`, `Razon Mora`, `Gestion`, `Franja`, `Fecha de Promesa`, `Valor Promesa`, `Asesor`, `Mes Asignado`, `Agencia`, `Producto`, `Caso`) VALUES
	('2017-12-18', '2017-12-18', '20:23:52', '01:01:01', '66882559', '1411999', 3103890618, 'MENSAJE EN BUZON', '', '3103890618; MENSAJE DE VOZ', 0, '0000-00-00', 0, 'diana.rojas015', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:25:39', '01:02:02', '94411728', '1031580', 3176517977, 'MENSAJE EN BUZON', '', '3176517977; SE DEJA MSJ DE VOZ.', 0, '0000-00-00', 0, 'diana.caballero594', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:30:39', '01:03:03', '34515897', '570828', 3122387891, 'MENSAJE EN BUZON', '', '3122387891; SE DEJA MSJ DE VOZ.', 0, '0000-00-00', 0, 'diana.caballero594', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:30:50', '01:04:04', '14676425', '1599661', 3173745389, 'MENSAJE EN BUZON', '', '3173745389; SE DEJA MSJ DE VOZ.', 0, '0000-00-00', 0, 'diana.caballero594', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:32:51', '01:05:05', '16647735', '1070871', 3152053323, 'MENSAJE EN BUZON', '', '3152053323; SE DEJA MSJ DE VOZ .,', 0, '0000-00-00', 0, 'diana.caballero594', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:36:51', '01:06:06', '16462148', '91280208', 3162376235, 'MENSAJE EN BUZON', '', '3162376235; SE DEJA MSJ DE VOZ.', 0, '0000-00-00', 0, 'diana.caballero594', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:37:57', '01:07:07', '16462148', '91280208', 3113579748, 'MENSAJE EN BUZON', '', '3113579748; SE DEJA MSJ DE VOZ.', 0, '0000-00-00', 0, 'diana.caballero594', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:15', '01:08:08', '87246299', '46446937', 3136405469, 'MENSAJE EN BUZON', '', '3136405469; SE DEJA MSJ DE VOZ', 0, '0000-00-00', 0, 'diana.caballero594', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:16', '01:09:09', '87246299', '46446937', 3122903931, 'MENSAJE EN BUZON', '', '3122903931; SE DEJA MSJ DE VOZ .', 0, '0000-00-00', 0, 'diana.caballero594', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:17', '01:10:10', '31842408', '340208', 3103842084, 'MENSAJE EN BUZON', '', '3103842084; SE DEJA MSJ DE VOZ .', 0, '0000-00-00', 0, 'diana.caballero594', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:18', '01:11:11', '40188968', '258264131', 3124816794, 'MENSAJE EN BUZON', '', '3124816794; SE DEJA MENSAJE DE VOZ', 0, '0000-00-00', 0, 'ruben.velasco104', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:19', '01:12:12', '48615628', '2866102', 3108316751, 'MENSAJE EN BUZON', '', '3108316751; MENSAJE DE VOZ ..', 0, '0000-00-00', 0, 'xatly.rodriguez099', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:20', '01:13:13', '16355939', '2627583', 3174197135, 'MENSAJE EN BUZON', '', '3174197135; MENSAJE DE VOZ', 0, '0000-00-00', 0, 'angie.correa801', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:21', '01:14:14', '1116232210', '2919469', 3107582606, 'MENSAJE EN BUZON', '', '3107582606; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:22', '01:15:15', '42028572', '42028572', 3188351121, 'MENSAJE EN BUZON', '', '3188351121; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:23', '01:16:16', '63337265', '8409', 3186412403, 'MENSAJE EN BUZON', '', '3186412403; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:24', '01:17:17', '28332646', '172317', 3153761719, 'MENSAJE EN BUZON', '', '3153761719; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:25', '01:18:18', '1113525312', '2927002', 3122405327, 'MENSAJE EN BUZON', '', '3122405327; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:26', '01:19:19', '28224851', '29910', 3138537814, 'MENSAJE EN BUZON', '', '3138537814; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:27', '01:20:20', '22651996', '27299', 3007210901, 'MENSAJE EN BUZON', '', '3007210901; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:28', '01:21:21', '27258348', '1588633', 3146208394, 'MENSAJE EN BUZON', '', '3146208394; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:29', '01:22:22', '66753575', '2827706', 3168193143, 'MENSAJE EN BUZON', '', '3168193143; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:30', '01:23:23', '66943149', '46448312', 3177102368, 'MENSAJE EN BUZON', '', '3177102368; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:31', '01:24:24', '1130628900', '1266209', 3122486953, 'MENSAJE EN BUZON', '', '3122486953; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:32', '01:25:25', '10375131', '573281', 3148039167, 'MENSAJE EN BUZON', '', '3148039167; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:33', '01:26:26', '22624032', '411855038', 3015868238, 'MENSAJE EN BUZON', '', '3015868238; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:34', '01:27:27', '1143969221', '46584482', 3178287597, 'MENSAJE EN BUZON', '', '3178287597; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:35', '01:28:28', '1130657854', '1032037', 3154364572, 'MENSAJE EN BUZON', '', '3154364572; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:36', '01:29:29', '63509684', '190526', 3184054119, 'MENSAJE EN BUZON', '', '3184054119; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:37', '01:30:30', '29875629', '2627810', 3172607607, 'MENSAJE EN BUZON', '', '3172607607; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:38', '01:31:31', '1098644004', '21016', 3103012743, 'MENSAJE EN BUZON', '', '3103012743; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:39', '01:32:32', '16505648', '1362331', 3193506882, 'MENSAJE EN BUZON', '', '3193506882; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:40', '01:33:33', '93367800', '1007416', 3207272664, 'MENSAJE EN BUZON', '', '3207272664; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:41', '01:34:34', '23778544', '14346', 3123029595, 'MENSAJE EN BUZON', '', '3123029595; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:42', '01:35:35', '43715851', '46483829', 3153244621, 'MENSAJE EN BUZON', '', '3153244621; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:43', '01:36:36', '79183021', '1607579', 3104964460, 'MENSAJE EN BUZON', '', '3104964460; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:44', '01:37:37', '31877994', '31877994', 3175279871, 'MENSAJE EN BUZON', '', '3175279871; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:45', '01:38:38', '29661112', '1472585', 3022438842, 'MENSAJE EN BUZON', '', '3022438842; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:46', '01:39:39', '1098643786', '1857', 3132381150, 'MENSAJE EN BUZON', '', '3132381150; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:47', '01:40:40', '1144062066', '966503', 3103954905, 'MENSAJE EN BUZON', '', '3103954905; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:48', '01:41:41', '66992750', '46413112', 3117698426, 'MENSAJE EN BUZON', '', '3117698426; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:49', '01:42:42', '1112473339', '1318233', 3155126075, 'MENSAJE EN BUZON', '', '3155126075; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:50', '01:43:43', '1121861307', '1121861307', 3015009248, 'MENSAJE EN BUZON', '', '3015009248; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:51', '01:44:44', '31858264', '1609924', 3104574570, 'MENSAJE EN BUZON', '', '3104574570; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:52', '01:45:45', '9760651', '213529198', 3133413012, 'MENSAJE EN BUZON', '', '3133413012; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:53', '01:46:46', '14466479', '1027402', 3106345039, 'MENSAJE EN BUZON', '', '3106345039; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:54', '01:47:47', '12197354', '46446382', 3136078035, 'MENSAJE EN BUZON', '', '3136078035; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:55', '01:48:48', '1122135893', '346527561', 3108528470, 'MENSAJE EN BUZON', '', '3108528470; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:56', '01:49:49', '1122647495', '256690970', 3212690063, 'MENSAJE EN BUZON', '', '3212690063; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:57', '01:50:50', '9790322', '916695050', 3108778374, 'MENSAJE EN BUZON', '', '3108778374; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:58', '01:51:51', '1116256046', '2635820', 3177620378, 'MENSAJE EN BUZON', '', '3177620378; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '02:44:59', '01:52:52', '94390304', '94390304', 3123048657, 'MENSAJE EN BUZON', '', '3123048657; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '00:00:00', '01:53:53', '29157319', '1608486', 3122310121, 'MENSAJE EN BUZON', '', '3122310121; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:44:01', '01:54:54', '63500189', '63500189', 3156347271, 'MENSAJE EN BUZON', '', '3156347271; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:45:02', '01:55:55', '31385086', '1428330', 3166420989, 'MENSAJE EN BUZON', '', '3166420989; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:46:03', '01:56:56', '38867531', '2878006', 3155235199, 'MENSAJE EN BUZON', '', '3155235199; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:47:04', '01:57:57', '7224625', '7224625', 3114671029, 'MENSAJE EN BUZON', '', '3114671029; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:48:05', '01:58:58', '31163570', '1413180', 3122572069, 'MENSAJE EN BUZON', '', '3122572069; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:49:06', '01:59:59', '1113652493', '1427582', 3146522258, 'MENSAJE EN BUZON', '', '3146522258; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:50:07', '00:00:00', '63493937', '8691', 3144024550, 'MENSAJE EN BUZON', '', '3144024550; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:51:08', '02:01:01', '91517107', '229976', 3187666545, 'MENSAJE EN BUZON', '', '3187666545; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:52:09', '02:02:02', '1049617026', '1049617026', 3125403291, 'MENSAJE EN BUZON', '', '3125403291; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:53:10', '02:03:03', '2571470', '1151126', 3113321880, 'MENSAJE EN BUZON', '', '3113321880; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:54:11', '02:04:04', '41793780', '8311', 3204359872, 'MENSAJE EN BUZON', '', '3204359872; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:55:12', '02:05:05', '94154484', '2628800', 3122576591, 'MENSAJE EN BUZON', '', '3122576591; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:56:13', '02:06:06', '51572826', '51572826', 3208810375, 'MENSAJE EN BUZON', '', '3208810375; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:57:14', '02:07:07', '79265550', '79265550', 3142792369, 'MENSAJE EN BUZON', '', '3142792369; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:58:15', '02:08:08', '31912777', '1611887', 3137068857, 'MENSAJE EN BUZON', '', '3137068857; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '03:59:16', '02:09:09', '66776047', '1450881', 3154086407, 'MENSAJE EN BUZON', '', '3154086407; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '00:00:00', '02:10:10', '66822374', '91280356', 3178039998, 'MENSAJE EN BUZON', '', '3178039998; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:01:00', '02:11:11', '1112462228', '2901396', 3108226161, 'MENSAJE EN BUZON', '', '3108226161; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:02:01', '02:12:12', '94150012', '2632945', 3175874050, 'MENSAJE EN BUZON', '', '3175874050; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:03:02', '02:13:13', '29177912', '1077473', 3156502540, 'MENSAJE EN BUZON', '', '3156502540; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:04:03', '02:14:14', '6319708', '1266723', 3206825975, 'MENSAJE EN BUZON', '', '3206825975; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:05:04', '02:15:15', '479377', '479377', 3188140586, 'MENSAJE EN BUZON', '', '3188140586; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:06:05', '02:16:16', '38553875', '1268535', 3136775614, 'MENSAJE EN BUZON', '', '3136775614; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:07:06', '02:17:17', '27500045', '1022719', 3103005344, 'MENSAJE EN BUZON', '', '3103005344; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:08:07', '02:18:18', '31448096', '1265539', 3117460726, 'MENSAJE EN BUZON', '', '3117460726; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:09:08', '02:19:19', '76043960', '1591716', 3168205039, 'MENSAJE EN BUZON', '', '3168205039; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:10:09', '02:20:20', '22433357', '786380', 3044963465, 'MENSAJE EN BUZON', '', '3044963465; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:11:10', '02:21:21', '9736513', '1353871', 3178403847, 'MENSAJE EN BUZON', '', '3178403847; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:12:11', '02:22:22', '67004713', '1586563', 3107311664, 'MENSAJE EN BUZON', '', '3107311664; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:13:12', '02:23:23', '4696336', '46729223', 3233626026, 'MENSAJE EN BUZON', '', '3233626026; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:14:13', '02:24:24', '91267063', '19963', 3108703138, 'MENSAJE EN BUZON', '', '3108703138; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:15:14', '02:25:25', '1120572767', '433418137', 3214887609, 'MENSAJE EN BUZON', '', '3214887609; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:16:15', '02:26:26', '67022190', '67022190', 3122651881, 'MENSAJE EN BUZON', '', '3122651881; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:17:16', '02:27:27', '19285455', '31194', 3178229910, 'MENSAJE EN BUZON', '', '3178229910; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:18:17', '02:28:28', '31966788', '572914', 3108778374, 'MENSAJE EN BUZON', '', '3108778374; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:19:18', '02:29:29', '1151944672', '1612112', 3162822560, 'MENSAJE EN BUZON', '', '3162822560; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:20:19', '02:30:30', '98497681', '2637025', 3188769023, 'MENSAJE EN BUZON', '', '3188769023; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:21:20', '02:31:31', '79893464', '79893464', 3103344874, 'MENSAJE EN BUZON', '', '3103344874; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:22:21', '02:32:32', '94320499', '94320499', 3172297952, 'MENSAJE EN BUZON', '', '3172297952; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:23:22', '02:33:33', '16751448', '575302', 3154619122, 'MENSAJE EN BUZON', '', '3154619122; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:24:23', '02:34:34', '1144057648', '1144057648', 3157110622, 'MENSAJE EN BUZON', '', '3157110622; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:25:24', '02:35:35', '5273854', '1028814', 3153443229, 'MENSAJE EN BUZON', '', '3153443229; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:26:25', '02:36:36', '1144146108', '1026226', 3184912517, 'MENSAJE EN BUZON', '', '3184912517; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:27:26', '02:37:37', '57465138', '46616291', 3156367649, 'MENSAJE EN BUZON', '', '3156367649; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:28:27', '02:38:38', '63509684', '190526', 3184054119, 'MENSAJE EN BUZON', '', '3184054119; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:29:28', '02:39:39', '1130628900', '1266209', 3122486953, 'MENSAJE EN BUZON', '', '3122486953; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '04:30:29', '02:40:40', '8192371', '8192371', 3123435592, 'MENSAJE EN BUZON', '', '3123435592; NO CONTESTAN', 0, '0000-00-00', 0, 'predictivo', '2017-12-15', 'Aecsa', 'C1', 0),
	('2017-12-18', '2017-12-18', '08:53:52', '08:56:58', '94322379', '1467533', 3103729061, 'PROMESAS DE PAGO', 'AUMENTO DE GASTOS', '3103729061; SE LE INF AL TT QUE EL DIA 22 DE DICIEMBRE DEBE REALIZAR EL PAGO DE LA CUOTA POR UN VALOR DE$252.000,POR MEDIO DE EFECTY..', 0, '2017-12-22', 252000, 'angelica.reyes279', '2017-12-15', 'Aecsa', 'C1', 0);
/*!40000 ALTER TABLE `gestion casa ext` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.gestion externa
CREATE TABLE IF NOT EXISTS `gestion externa` (
  `FechaReporte` date DEFAULT NULL,
  `FechaLlamada` date DEFAULT NULL,
  `HoraGestionInicial` time DEFAULT NULL,
  `HoraGestionFinal` time DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `NroProductoCredito` varchar(255) DEFAULT NULL,
  `NumeroMarcado` double DEFAULT NULL,
  `Tipificacion` varchar(255) DEFAULT NULL,
  `RazonMora` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `Franja` double DEFAULT NULL,
  `FechaDePromesa` date DEFAULT NULL,
  `ValorPromesa` double DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `MesAsignado` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `TipoGestion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.gestion externa: ~0 rows (aproximadamente)
DELETE FROM `gestion externa`;
/*!40000 ALTER TABLE `gestion externa` DISABLE KEYS */;
/*!40000 ALTER TABLE `gestion externa` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.gestion interna
CREATE TABLE IF NOT EXISTS `gestion interna` (
  `FechaReporte` date DEFAULT NULL,
  `FechaLlamada` date DEFAULT NULL,
  `HoraGestionInicial` time DEFAULT NULL,
  `HoraGestionFinal` time DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `NroProductoCredito` varchar(255) DEFAULT NULL,
  `NumeroMarcado` double DEFAULT NULL,
  `Tipificacion` varchar(255) DEFAULT NULL,
  `RazonMora` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `Franja` double DEFAULT NULL,
  `FechadePromesa` date DEFAULT NULL,
  `ValorPromesa` double DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `MesAsignado` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `TipoGestion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.gestion interna: ~0 rows (aproximadamente)
DELETE FROM `gestion interna`;
/*!40000 ALTER TABLE `gestion interna` DISABLE KEYS */;
/*!40000 ALTER TABLE `gestion interna` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.hoja1
CREATE TABLE IF NOT EXISTS `hoja1` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.hoja1: ~0 rows (aproximadamente)
DELETE FROM `hoja1`;
/*!40000 ALTER TABLE `hoja1` DISABLE KEYS */;
/*!40000 ALTER TABLE `hoja1` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.marca especial
CREATE TABLE IF NOT EXISTS `marca especial` (
  `Credito` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Bloqueo_U` varchar(255) DEFAULT NULL,
  `Marca Especial` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.marca especial: ~0 rows (aproximadamente)
DELETE FROM `marca especial`;
/*!40000 ALTER TABLE `marca especial` DISABLE KEYS */;
/*!40000 ALTER TABLE `marca especial` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.marcas
CREATE TABLE IF NOT EXISTS `marcas` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NroCredito` varchar(255) DEFAULT NULL,
  `Nombre` varchar(255) DEFAULT NULL,
  `TipoNegociacion` varchar(255) DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `FechaPago` date DEFAULT NULL,
  `ValorAcuerdo` double DEFAULT NULL,
  `ValorCuota` double DEFAULT NULL,
  `ValorPago` double DEFAULT NULL,
  `Plazo` int(11) DEFAULT NULL,
  `Tasa` int(11) DEFAULT NULL,
  `MedioDePago` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `DiasMora` int(11) DEFAULT NULL,
  `MotivoEspecial` varchar(255) DEFAULT NULL,
  `Validacion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.marcas: ~0 rows (aproximadamente)
DELETE FROM `marcas`;
/*!40000 ALTER TABLE `marcas` DISABLE KEYS */;
/*!40000 ALTER TABLE `marcas` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.mejor gestion
CREATE TABLE IF NOT EXISTS `mejor gestion` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `NUM_Obligacion` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Llave SL` varchar(255) DEFAULT NULL,
  `Ponderacion` double DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL,
  `TIP ResultadoContacto` varchar(255) DEFAULT NULL,
  `Fecha Mejor Gestion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.mejor gestion: ~0 rows (aproximadamente)
DELETE FROM `mejor gestion`;
/*!40000 ALTER TABLE `mejor gestion` DISABLE KEYS */;
/*!40000 ALTER TABLE `mejor gestion` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.mejor gestion ext
CREATE TABLE IF NOT EXISTS `mejor gestion ext` (
  `Fecha Reporte` date DEFAULT NULL,
  `Fecha Llamada` date DEFAULT NULL,
  `Hora Gestion Inicial` date DEFAULT NULL,
  `Hora Gestion Final` date DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `N° Producto/Credito` varchar(255) DEFAULT NULL,
  `Numero Marcado` varchar(255) DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL,
  `Razon Mora` varchar(255) DEFAULT NULL,
  `Gestion` varchar(255) DEFAULT NULL,
  `Franja` varchar(255) DEFAULT NULL,
  `Fecha de Promesa` date DEFAULT NULL,
  `Valor Promesa` double DEFAULT NULL,
  `Asesor` varchar(255) DEFAULT NULL,
  `Mes Asignado` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Antiguedad de la Gestion` varchar(255) DEFAULT NULL,
  `Numero de Gestiones` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.mejor gestion ext: ~0 rows (aproximadamente)
DELETE FROM `mejor gestion ext`;
/*!40000 ALTER TABLE `mejor gestion ext` DISABLE KEYS */;
/*!40000 ALTER TABLE `mejor gestion ext` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.pagos
CREATE TABLE IF NOT EXISTS `pagos` (
  `Columna 1` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.pagos: ~0 rows (aproximadamente)
DELETE FROM `pagos`;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.pagos aplicados
CREATE TABLE IF NOT EXISTS `pagos aplicados` (
  `Cedula` double DEFAULT NULL,
  `VLRPago` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `TRXHomoloperaciones` varchar(255) DEFAULT NULL,
  `DescripcionTRX` varchar(255) DEFAULT NULL,
  `NumCredito` varchar(255) DEFAULT NULL,
  `FechaEfect` varchar(255) DEFAULT NULL,
  `FechaProc` varchar(255) DEFAULT NULL,
  `TotalPago` double DEFAULT NULL,
  `DiaFacturacion` int(11) DEFAULT NULL,
  `FechaProximoPago` date DEFAULT NULL,
  `CODProducto` int(11) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `SaldoCapital` double DEFAULT NULL,
  `CapitalEnMillones` double DEFAULT NULL,
  `EstadoCredito` varchar(255) DEFAULT NULL,
  `DiasMora` int(11) DEFAULT NULL,
  `FranjaMora` varchar(255) DEFAULT NULL,
  `ValorVencido` double DEFAULT NULL,
  `ValorCuotaVPG` double DEFAULT NULL,
  `FiltroCarteraOriginada` varchar(255) DEFAULT NULL,
  `FiltroCartera` varchar(255) DEFAULT NULL,
  `Llave` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `NumeroPoliza` varchar(255) DEFAULT NULL,
  `ValorPago` double DEFAULT NULL,
  `FechaPago` date DEFAULT NULL,
  `FechaProceso` date DEFAULT NULL,
  `TRXInterna` int(11) DEFAULT NULL,
  `LlavePlano` varchar(255) DEFAULT NULL,
  `LlaveSL` varchar(255) DEFAULT NULL,
  `FechaAplicacionRecaudo` date DEFAULT NULL,
  `CODEmpresa` int(11) DEFAULT NULL,
  `NIT` double DEFAULT NULL,
  `TipoRecaudo` int(11) DEFAULT NULL,
  `ConceptoRecaudo` varchar(255) DEFAULT NULL,
  `Comprobante` int(11) DEFAULT NULL,
  `ValorComprobante` double DEFAULT NULL,
  `Banco` varchar(255) DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Usuario` varchar(255) DEFAULT NULL,
  `MedioPago` varchar(255) DEFAULT NULL,
  `UnidadCredito` varchar(255) DEFAULT NULL,
  `ValorCredito` double DEFAULT NULL,
  `EntidadPropietariaCredito` varchar(255) DEFAULT NULL,
  `Concepto` varchar(255) DEFAULT NULL,
  `Valor` double DEFAULT NULL,
  `FechaAPL` date DEFAULT NULL,
  `FechaComprobante` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.pagos aplicados: ~0 rows (aproximadamente)
DELETE FROM `pagos aplicados`;
/*!40000 ALTER TABLE `pagos aplicados` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos aplicados` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.pagos efecty
CREATE TABLE IF NOT EXISTS `pagos efecty` (
  `Documento` varchar(255) DEFAULT NULL,
  `Nombres` varchar(255) DEFAULT NULL,
  `Apellido1` varchar(255) DEFAULT NULL,
  `Apellido2` varchar(255) DEFAULT NULL,
  `NumeroOrden` varchar(255) DEFAULT NULL,
  `TipoDoc` varchar(255) DEFAULT NULL,
  `OficinaOrigen` varchar(255) DEFAULT NULL,
  `DESCOficinaOrigen` varchar(255) DEFAULT NULL,
  `Proyecto` varchar(255) DEFAULT NULL,
  `ValorMovilizado` double DEFAULT NULL,
  `DiasMora` varchar(255) DEFAULT NULL,
  `ValorComision` double DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `FechaFacturacion` datetime DEFAULT NULL,
  `OficinaDestino` varchar(255) DEFAULT NULL,
  `ValorIva` double DEFAULT NULL,
  `FechaCreps` datetime DEFAULT NULL,
  `Saldo` varchar(255) DEFAULT NULL,
  `NumCred` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.pagos efecty: ~0 rows (aproximadamente)
DELETE FROM `pagos efecty`;
/*!40000 ALTER TABLE `pagos efecty` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos efecty` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.pago_minimo_c1
CREATE TABLE IF NOT EXISTS `pago_minimo_c1` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Pago_Minimo` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.pago_minimo_c1: ~0 rows (aproximadamente)
DELETE FROM `pago_minimo_c1`;
/*!40000 ALTER TABLE `pago_minimo_c1` DISABLE KEYS */;
/*!40000 ALTER TABLE `pago_minimo_c1` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.pago_minimo_cp
CREATE TABLE IF NOT EXISTS `pago_minimo_cp` (
  `Pagare` varchar(7) DEFAULT NULL,
  `SumaDePago_Minimo_Total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.pago_minimo_cp: ~0 rows (aproximadamente)
DELETE FROM `pago_minimo_cp`;
/*!40000 ALTER TABLE `pago_minimo_cp` DISABLE KEYS */;
/*!40000 ALTER TABLE `pago_minimo_cp` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.pago_minimo__tg
CREATE TABLE IF NOT EXISTS `pago_minimo__tg` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Pago_Minimo` decimal(10,0) DEFAULT NULL,
  `Filtro_Cartera` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.pago_minimo__tg: ~0 rows (aproximadamente)
DELETE FROM `pago_minimo__tg`;
/*!40000 ALTER TABLE `pago_minimo__tg` DISABLE KEYS */;
/*!40000 ALTER TABLE `pago_minimo__tg` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.ponderacion
CREATE TABLE IF NOT EXISTS `ponderacion` (
  `Ponderacion` double DEFAULT NULL,
  `TIP ResultadoContacto` varchar(255) DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.ponderacion: ~0 rows (aproximadamente)
DELETE FROM `ponderacion`;
/*!40000 ALTER TABLE `ponderacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `ponderacion` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.ponderacion razon mora
CREATE TABLE IF NOT EXISTS `ponderacion razon mora` (
  `Ponderacion` double DEFAULT NULL,
  `TIP ResultadoContacto` varchar(255) DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.ponderacion razon mora: ~0 rows (aproximadamente)
DELETE FROM `ponderacion razon mora`;
/*!40000 ALTER TABLE `ponderacion razon mora` DISABLE KEYS */;
/*!40000 ALTER TABLE `ponderacion razon mora` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.potencial
CREATE TABLE IF NOT EXISTS `potencial` (
  `Producto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Identificacion_2` double DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Credito_SL` varchar(255) DEFAULT NULL,
  `Llave_SL` varchar(255) DEFAULT NULL,
  `Valor Cuota` double DEFAULT NULL,
  `Valor Pago` double DEFAULT NULL,
  `Valor Pago + GAG` double DEFAULT NULL,
  `Valor Pago + Gag Real` double DEFAULT NULL,
  `V-C Plano` double DEFAULT NULL,
  `Capital _Vigente` double DEFAULT NULL,
  `Saldo Capital` varchar(255) DEFAULT NULL,
  `Dias_Mora_Hoy` double DEFAULT NULL,
  `Proceso Juridico` varchar(255) DEFAULT NULL,
  `Estado_Credito` varchar(255) DEFAULT NULL,
  `Cantidad_Corridas` varchar(255) DEFAULT NULL,
  `Fecha_Ultima_Corrida` varchar(255) DEFAULT NULL,
  `Motivo Especial` varchar(255) DEFAULT NULL,
  `Validaciones` varchar(255) DEFAULT NULL,
  `Fecha_Desembolso` varchar(255) DEFAULT NULL,
  `COD_Producto` double DEFAULT NULL,
  `Tipo Negociacion` varchar(255) DEFAULT NULL,
  `Fecha COND-REEST` varchar(255) DEFAULT NULL,
  `asd` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.potencial: ~0 rows (aproximadamente)
DELETE FROM `potencial`;
/*!40000 ALTER TABLE `potencial` DISABLE KEYS */;
/*!40000 ALTER TABLE `potencial` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.prod
CREATE TABLE IF NOT EXISTS `prod` (
  `Producto` varchar(255) DEFAULT NULL,
  `Producto_1` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.prod: ~4 rows (aproximadamente)
DELETE FROM `prod`;
/*!40000 ALTER TABLE `prod` DISABLE KEYS */;
INSERT INTO `prod` (`Producto`, `Producto_1`) VALUES
	('CREDIFINANCIERA', 'CF'),
	('CREDIPOLIZA', 'CP'),
	('CREDIUNO', 'C1'),
	('TU CREDITO', 'TC');
/*!40000 ALTER TABLE `prod` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.prod esc
CREATE TABLE IF NOT EXISTS `prod esc` (
  `Identificacion TXT` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Credito_2` varchar(255) DEFAULT NULL,
  `Saldo Capital` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.prod esc: ~0 rows (aproximadamente)
DELETE FROM `prod esc`;
/*!40000 ALTER TABLE `prod esc` DISABLE KEYS */;
/*!40000 ALTER TABLE `prod esc` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.razon de mora
CREATE TABLE IF NOT EXISTS `razon de mora` (
  `Identificacion` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Tipificacion Homologada` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.razon de mora: ~0 rows (aproximadamente)
DELETE FROM `razon de mora`;
/*!40000 ALTER TABLE `razon de mora` DISABLE KEYS */;
/*!40000 ALTER TABLE `razon de mora` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.recaudo
CREATE TABLE IF NOT EXISTS `recaudo` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` double DEFAULT NULL,
  `NumeroCredito` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `ValorPago` double DEFAULT NULL,
  `MaxDeFechaAplicaPago` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.recaudo: ~0 rows (aproximadamente)
DELETE FROM `recaudo`;
/*!40000 ALTER TABLE `recaudo` DISABLE KEYS */;
/*!40000 ALTER TABLE `recaudo` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.recaudo c1
CREATE TABLE IF NOT EXISTS `recaudo c1` (
  `Cedula` double DEFAULT NULL,
  `NombreESP` varchar(255) DEFAULT NULL,
  `NumeroCredito` varchar(255) DEFAULT NULL,
  `VLRPago` double DEFAULT NULL,
  `FechaAplicaPago` date DEFAULT NULL,
  `FechaComprobante` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.recaudo c1: ~0 rows (aproximadamente)
DELETE FROM `recaudo c1`;
/*!40000 ALTER TABLE `recaudo c1` DISABLE KEYS */;
/*!40000 ALTER TABLE `recaudo c1` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.recaudo cf
CREATE TABLE IF NOT EXISTS `recaudo cf` (
  `Producto` varchar(255) DEFAULT NULL,
  `TRXHomoloperaciones` varchar(255) DEFAULT NULL,
  `DescripcionTRX` varchar(255) DEFAULT NULL,
  `NUMCredito` varchar(255) DEFAULT NULL,
  `FechaEFECT` date DEFAULT NULL,
  `FechaPROC` date DEFAULT NULL,
  `TotalPago` double DEFAULT NULL,
  `DiaFacturacion` double DEFAULT NULL,
  `FechaProximoPago` date DEFAULT NULL,
  `CODProducto` double DEFAULT NULL,
  `Identificacion` double DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `SaldoCapital` double DEFAULT NULL,
  `CapitalEnMillones` double DEFAULT NULL,
  `EstadoCredito` varchar(255) DEFAULT NULL,
  `DiasMora` double DEFAULT NULL,
  `FranjaMora` varchar(255) DEFAULT NULL,
  `ValorVencido` double DEFAULT NULL,
  `ValorCuotaVPG` double DEFAULT NULL,
  `FiltroCarteraOriginada` varchar(255) DEFAULT NULL,
  `FiltroCartera` varchar(255) DEFAULT NULL,
  `Llave` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.recaudo cf: ~0 rows (aproximadamente)
DELETE FROM `recaudo cf`;
/*!40000 ALTER TABLE `recaudo cf` DISABLE KEYS */;
/*!40000 ALTER TABLE `recaudo cf` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.recaudo cp
CREATE TABLE IF NOT EXISTS `recaudo cp` (
  `Credito` varchar(255) DEFAULT NULL,
  `Identificacion` double DEFAULT NULL,
  `NumeroPoliza` varchar(255) DEFAULT NULL,
  `ValorPago` double DEFAULT NULL,
  `FechaPago` date DEFAULT NULL,
  `FechaProceso` date DEFAULT NULL,
  `TRXInterna` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.recaudo cp: ~0 rows (aproximadamente)
DELETE FROM `recaudo cp`;
/*!40000 ALTER TABLE `recaudo cp` DISABLE KEYS */;
/*!40000 ALTER TABLE `recaudo cp` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.recaudo efecty
CREATE TABLE IF NOT EXISTS `recaudo efecty` (
  `Producto` varchar(255) DEFAULT NULL,
  `Cedula` double DEFAULT NULL,
  `Numero_Credito` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Valor Pago` double DEFAULT NULL,
  `MaxDeFecha_Aplica_Pago` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.recaudo efecty: ~0 rows (aproximadamente)
DELETE FROM `recaudo efecty`;
/*!40000 ALTER TABLE `recaudo efecty` DISABLE KEYS */;
/*!40000 ALTER TABLE `recaudo efecty` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.recaudo efecty tc letra
CREATE TABLE IF NOT EXISTS `recaudo efecty tc letra` (
  `Documento` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Valor_Movilizado` double DEFAULT NULL,
  `Fecha_Facturacion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.recaudo efecty tc letra: ~0 rows (aproximadamente)
DELETE FROM `recaudo efecty tc letra`;
/*!40000 ALTER TABLE `recaudo efecty tc letra` DISABLE KEYS */;
/*!40000 ALTER TABLE `recaudo efecty tc letra` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.recaudo tc
CREATE TABLE IF NOT EXISTS `recaudo tc` (
  `LlavePlano` varchar(255) DEFAULT NULL,
  `Llave` varchar(255) DEFAULT NULL,
  `LlaveSL` varchar(255) DEFAULT NULL,
  `Credito` varchar(255) DEFAULT NULL,
  `FechaAplicacionRecaudo` date DEFAULT NULL,
  `NombreCompleto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `CODEmpresa` int(11) DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `NIT` varchar(255) DEFAULT NULL,
  `TipoRecaudo` double DEFAULT NULL,
  `ConceptoRecaudo` varchar(255) DEFAULT NULL,
  `Comprobante` double DEFAULT NULL,
  `ValorComprobante` double DEFAULT NULL,
  `Banco` varchar(255) DEFAULT NULL,
  `FechaPago` date DEFAULT NULL,
  `Agencia` varchar(255) DEFAULT NULL,
  `Usuario` varchar(255) DEFAULT NULL,
  `MedioPago` varchar(255) DEFAULT NULL,
  `UnidadCredito` varchar(255) DEFAULT NULL,
  `ValorCredito` double DEFAULT NULL,
  `EntidadPropietariaCredito` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.recaudo tc: ~0 rows (aproximadamente)
DELETE FROM `recaudo tc`;
/*!40000 ALTER TABLE `recaudo tc` DISABLE KEYS */;
/*!40000 ALTER TABLE `recaudo tc` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.recaudo tg
CREATE TABLE IF NOT EXISTS `recaudo tg` (
  `Concepto` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Valor` double DEFAULT NULL,
  `FechaAPL` date DEFAULT NULL,
  `FechaComprobante` date DEFAULT NULL,
  `FechaProceso` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.recaudo tg: ~0 rows (aproximadamente)
DELETE FROM `recaudo tg`;
/*!40000 ALTER TABLE `recaudo tg` DISABLE KEYS */;
/*!40000 ALTER TABLE `recaudo tg` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.rediferidos
CREATE TABLE IF NOT EXISTS `rediferidos` (
  `Cedula` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL,
  `Autorizado` int(11) DEFAULT NULL,
  `Operativo` int(11) DEFAULT NULL,
  `Total` double DEFAULT NULL,
  `Valida` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.rediferidos: ~0 rows (aproximadamente)
DELETE FROM `rediferidos`;
/*!40000 ALTER TABLE `rediferidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `rediferidos` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.seg lb
CREATE TABLE IF NOT EXISTS `seg lb` (
  `Producto` varchar(255) DEFAULT NULL,
  `Segmento` varchar(255) DEFAULT NULL,
  `Nuevo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.seg lb: ~0 rows (aproximadamente)
DELETE FROM `seg lb`;
/*!40000 ALTER TABLE `seg lb` DISABLE KEYS */;
/*!40000 ALTER TABLE `seg lb` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.tasa_pago_minimo
CREATE TABLE IF NOT EXISTS `tasa_pago_minimo` (
  `Producto` varchar(255) DEFAULT NULL,
  `Pago Minimo` double DEFAULT NULL,
  `Saldo Capital` double DEFAULT NULL,
  `Tasa_PM` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.tasa_pago_minimo: ~0 rows (aproximadamente)
DELETE FROM `tasa_pago_minimo`;
/*!40000 ALTER TABLE `tasa_pago_minimo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasa_pago_minimo` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.trx cp
CREATE TABLE IF NOT EXISTS `trx cp` (
  `TRX CP` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.trx cp: ~0 rows (aproximadamente)
DELETE FROM `trx cp`;
/*!40000 ALTER TABLE `trx cp` DISABLE KEYS */;
/*!40000 ALTER TABLE `trx cp` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.usuarios tigo
CREATE TABLE IF NOT EXISTS `usuarios tigo` (
  `Asesor` varchar(255) DEFAULT NULL,
  `Producto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.usuarios tigo: ~0 rows (aproximadamente)
DELETE FROM `usuarios tigo`;
/*!40000 ALTER TABLE `usuarios tigo` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuarios tigo` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.usuarios unificada
CREATE TABLE IF NOT EXISTS `usuarios unificada` (
  `idUsuarios` int(11) NOT NULL AUTO_INCREMENT,
  `NombreUser` varchar(255) DEFAULT NULL,
  `Contra` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idUsuarios`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla unificada.usuarios unificada: ~0 rows (aproximadamente)
DELETE FROM `usuarios unificada`;
/*!40000 ALTER TABLE `usuarios unificada` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuarios unificada` ENABLE KEYS */;

-- Volcando estructura para tabla unificada.ventas_cf
CREATE TABLE IF NOT EXISTS `ventas_cf` (
  `Credito` varchar(255) DEFAULT NULL,
  `Estado_Delta` varchar(255) DEFAULT NULL,
  `Fecha` varchar(255) DEFAULT NULL,
  `Valor Aplicado` varchar(255) DEFAULT NULL,
  `Identificacion` varchar(255) DEFAULT NULL,
  `Saldo_Capital` varchar(255) DEFAULT NULL,
  `CXC Balance` varchar(255) DEFAULT NULL,
  `CXC Contingentes` varchar(255) DEFAULT NULL,
  `Saldo_Credito` varchar(255) DEFAULT NULL,
  `PROV Total` varchar(255) DEFAULT NULL,
  `PROV Estimada OCT 2017` varchar(255) DEFAULT NULL,
  `Gasto Octubre 17` varchar(255) DEFAULT NULL,
  `Cantidad_Corridas_Operativas` varchar(255) DEFAULT NULL,
  `Dias_Sistema` varchar(255) DEFAULT NULL,
  `Dia_Facturacion` varchar(255) DEFAULT NULL,
  `Fecha_Primera_Cuota` varchar(255) DEFAULT NULL,
  `Fecha_Proximo_Pago` varchar(255) DEFAULT NULL,
  `Empresa` varchar(255) DEFAULT NULL,
  `Convenio_Homologado_Corto` varchar(255) DEFAULT NULL,
  `Tipo_Empresa_Bizagi` varchar(255) DEFAULT NULL,
  `Crediprogreso` varchar(255) DEFAULT NULL,
  `Estado_Credito_31-10-2017` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Volcando datos para la tabla unificada.ventas_cf: ~0 rows (aproximadamente)
DELETE FROM `ventas_cf`;
/*!40000 ALTER TABLE `ventas_cf` DISABLE KEYS */;
/*!40000 ALTER TABLE `ventas_cf` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
